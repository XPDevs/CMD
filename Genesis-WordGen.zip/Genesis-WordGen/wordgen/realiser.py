"""Grounded rule-based response planning and British English realisation.

This component deliberately avoids inventing facts. It uses current meaning and
explicit user-provided propositions in dialogue context; unsupported questions
receive a clear uncertainty response.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any
import re

from .lexicon import Lexicon
from .knowledge import KnowledgeBase

@dataclass
class RealisedUtterance:
    text: str
    confidence: float = 0.5
    features: dict[str, Any] = field(default_factory=dict)

class Realiser:
    def __init__(self, lexicon: Lexicon | None = None, knowledge_base: KnowledgeBase | None = None):
        self.lexicon = lexicon or Lexicon()
        self.knowledge_base = knowledge_base or KnowledgeBase()

    def realise(self, plan, context=None, meaning=None, intent=None) -> RealisedUtterance:
        action = getattr(plan, "action", "")
        name = getattr(intent, "name", "") if intent else ""
        tokens = [str(t).lower() for t in (getattr(intent, "slots", {}) or {}).get("tokens", [])]
        raw = (getattr(meaning, "source_text", "") or "").strip()
        lower = re.sub(r"[^a-z0-9' ]", "", raw.lower()).strip()

        # Query the loaded knowledge file before falling back to dialogue-only
        # behaviour. This is a general query interpreter: concepts and facts are
        # data records, while the reusable rules live in KnowledgeBase.
        if name in {"wh_question", "yes_no_question"} or raw.rstrip().endswith("?"):
            knowledge_answer = self.knowledge_base.answer(raw, context)
            if knowledge_answer:
                query_trace = getattr(self.knowledge_base, "last_query_trace", [])
                supported = any("supported knowledge/query procedure produced" in item for item in query_trace)
                return RealisedUtterance(knowledge_answer, .9 if supported else .55, {
                    "grounded": supported,
                    "source": "genesis-knowledge.jsonl" if supported else "knowledge uncertainty policy",
                    "knowledge_trace": query_trace,
                })

        # Summarise only explicit facts extracted from this session.
        if re.search(r"\bwhat do you know about me\b|\bwhat have i told you\b|\bwhat do you remember about me\b", lower):
            facts = getattr(getattr(context, "knowledge", None), "facts", []) if context else []
            if not facts:
                return RealisedUtterance(self.knowledge_base.reply("no_user_facts"), .9, {"grounded": True})
            summaries = []
            for fact in facts[-12:]:
                if fact.relation == "has_measurement":
                    summaries.append(f"{fact.subject} has {fact.value} of {fact.property}")
                else:
                    summaries.append(f"{fact.subject} {fact.relation.replace('_', ' ')} {fact.value}")
            return RealisedUtterance(self.knowledge_base.reply("fact_list", facts="; ".join(summaries)), .9, {"grounded": True})

        # Resolve general user-centred relations (preferences, purchases, study,
        # work and location) from dialogue facts rather than fixed answers.
        if name == "wh_question" and context and getattr(context, "knowledge", None):
            relation_fact = context.knowledge.answer_relation(raw)
            if relation_fact:
                statement = context.knowledge.relation_labels.get(relation_fact.relation, relation_fact.relation.replace("_", " "))
                return RealisedUtterance(
                    self.knowledge_base.reply("relation_recall", statement=statement, value=relation_fact.value),
                    .88, {"grounded": True, "source": relation_fact.source_text, "fact": relation_fact.to_dict()})

        if name == "social":
            if any(t in tokens for t in self.knowledge_base.cues("gratitude")):
                return RealisedUtterance(self.knowledge_base.reply("thanks"), .95)
            if any(t in tokens for t in self.knowledge_base.cues("apology")):
                return RealisedUtterance(self.knowledge_base.reply("apology_received"), .9)
            return RealisedUtterance(self.knowledge_base.reply("greeting"), .95)
        if lower in self.knowledge_base.cues("greetings"):
            return RealisedUtterance(self.knowledge_base.reply("greeting"), .95)
        if name == "command" or action == "acknowledge_command":
            return RealisedUtterance(self.knowledge_base.reply("command_unavailable"), .95)
        if name == "request" or action == "consider_request":
            return RealisedUtterance(self.knowledge_base.reply("request_clarify"), .8)
        if name == "yes_no_question" or action == "answer_yes_no":
            # Do not claim human preferences or experiences.
            if re.search(r"\b(do|does|did|are|is|am|can|could|have|has|will|would) you\b", lower):
                preference_cues = self.knowledge_base.cues("personal_preference")
                if preference_cues and re.search(r"\b(?:" + "|".join(re.escape(x) for x in sorted(preference_cues, key=len, reverse=True)) + r")\b", lower):
                    return RealisedUtterance(self.knowledge_base.reply("personal_preference"), .98)
            current = (getattr(meaning, "propositions", []) or [])
            if current and context:
                q = current[0]
                for fact in reversed(getattr(context, "user_facts", [])):
                    if self._same_proposition(q, fact):
                        answer = "Yes" if fact.polarity else "No"
                        return RealisedUtterance(self.knowledge_base.reply("yes_evidence", answer=answer), .9)
            return RealisedUtterance(self.knowledge_base.reply("yes_no_unknown"), .95)
        if name == "wh_question" or action == "answer_question":
            slots = getattr(intent, "slots", {}) or {}
            wh = slots.get("wh_word", "")
            props = getattr(meaning, "propositions", []) or []
            # Answer measurements and properties from explicit dialogue facts.
            # The query term is derived from the question, not a stored response.
            if context and getattr(context, "knowledge", None):
                words = list(tokens)
                ignored = {"how", "much", "many", "what", "which", "is", "are", "was", "were", "do", "does", "did", "can", "could", "would", "will", "has", "have", "had", "the", "a", "an", "of", "for", "in", "on", "it", "this", "that", "my", "your", "i", "you", "we", "they", "he", "she"}
                query_terms = [w for w in words if w not in ignored and not w.isdigit()]
                query_property = " ".join(query_terms)
                knowledge = context.knowledge
                fact = knowledge.find_property(query_property)
                if fact is None and not query_property:
                    measurements = [f for f in knowledge.facts if f.relation == "has_measurement"]
                    if len(measurements) == 1:
                        fact = measurements[0]
                if fact is not None:
                    if fact.relation == "has_measurement":
                        property_name = fact.property or "that measurement"
                        return RealisedUtterance(
                            self.knowledge_base.reply("measurement_recall", subject=fact.subject, value=fact.value, property=property_name),
                            .92, {"grounded": True, "source": fact.source_text, "fact": fact.to_dict()})
                    return RealisedUtterance(
                        self.knowledge_base.reply("property_recall", subject=fact.subject, value=fact.value), .82,
                        {"grounded": True, "source": fact.source_text, "fact": fact.to_dict()})
            # Existing proposition-level retrieval handles event questions.
            predicate = self._normalise_predicate(props[0].predicate) if props else ""
            if context and predicate:
                matches = [f for f in getattr(context, "user_facts", []) if self._normalise_predicate(f.predicate) == predicate and f.polarity]
                if matches:
                    fact = matches[-1]
                    if wh == "who" and fact.arguments.get("agent"):
                        return RealisedUtterance(self.knowledge_base.reply("bare_answer", answer=fact.arguments["agent"]), .85, {"grounded": True})
                    if wh in {"what", "which"} and fact.arguments.get("patient"):
                        return RealisedUtterance(self.knowledge_base.reply("bare_answer", answer=fact.arguments["patient"]), .8, {"grounded": True})
                    if wh == "where" and fact.arguments.get("location"):
                        return RealisedUtterance(self.knowledge_base.reply("bare_answer", answer=fact.arguments["location"]), .8, {"grounded": True})
            return RealisedUtterance(self.knowledge_base.reply("wh_unknown"), .95)
        if name == "assertion_opinion":
            return RealisedUtterance(self.knowledge_base.reply("opinion_acknowledgement"), .8)
        if name == "statement":
            positive_cues = self.knowledge_base.cues("positive_emotion")
            difficult_cues = self.knowledge_base.cues("difficult_emotion")
            want_cues = self.knowledge_base.cues("want_or_need")
            if positive_cues and re.search(r"\b(?:i am|i'm)\s+(?:" + "|".join(re.escape(x) for x in sorted(positive_cues, key=len, reverse=True)) + r")\b", lower):
                return RealisedUtterance(self.knowledge_base.reply("positive_emotion"), .85)
            if difficult_cues and re.search(r"\b(?:i am|i'm)\s+(?:" + "|".join(re.escape(x) for x in sorted(difficult_cues, key=len, reverse=True)) + r")\b", lower):
                return RealisedUtterance(self.knowledge_base.reply("difficult_emotion"), .85)
            if want_cues and re.search(r"\b(?:i )?(?:" + "|".join(re.escape(x) for x in sorted(want_cues, key=len, reverse=True)) + r")\b", lower):
                return RealisedUtterance(self.knowledge_base.reply("want_or_need"), .8)
            if not props_or_meaning(meaning):
                learned = getattr(getattr(context, "knowledge", None), "facts", []) if context else []
                measurement_facts = [fact for fact in learned if fact.relation == "has_measurement"]
                if measurement_facts:
                    fact = measurement_facts[-1]
                    return RealisedUtterance(
                        self.knowledge_base.reply("measurement_intro", subject=fact.subject, value=fact.value, property=fact.property),
                        .88, {"grounded": True, "fact": fact.to_dict()})
                return RealisedUtterance(self.knowledge_base.reply("unknown_statement"), .8)
            learned = getattr(getattr(context, "knowledge", None), "facts", []) if context else []
            measurement_facts = [fact for fact in learned if fact.relation == "has_measurement" and fact.source_text == raw]
            if measurement_facts:
                fact = measurement_facts[-1]
                return RealisedUtterance(
                    self.knowledge_base.reply("measurement_intro", subject=fact.subject, value=fact.value, property=fact.property),
                    .88, {"grounded": True, "fact": fact.to_dict()})
            relation_facts = [fact for fact in learned if fact.source_text == raw and fact.relation in context.knowledge.relation_labels] if context and getattr(context, "knowledge", None) else []
            if relation_facts:
                fact = relation_facts[-1]
                statement = context.knowledge.relation_labels.get(fact.relation, fact.relation.replace("_", " "))
                return RealisedUtterance(self.knowledge_base.reply("relation_intro", statement=statement, value=fact.value), .86, {"grounded": True, "fact": fact.to_dict()})
            return RealisedUtterance(self.knowledge_base.reply("statement_acknowledgement"), .8)
        return RealisedUtterance(self.knowledge_base.reply("unknown_statement"), .65)

    @staticmethod
    def _normalise_predicate(value: str) -> str:
        word = (value or "").lower().strip()
        irregular = {"came": "come", "come": "come", "went": "go", "gone": "go", "saw": "see", "seen": "see", "was": "be", "were": "be", "is": "be", "are": "be", "has": "have", "had": "have", "did": "do", "done": "do", "chased": "chase", "liked": "like", "likes": "like", "rained": "rain", "rains": "rain", "read": "read"}
        if word in irregular:
            return irregular[word]
        if word.endswith("ied") and len(word) > 3:
            return word[:-3] + "y"
        if word.endswith("ed") and len(word) > 3:
            stem = word[:-2]
            return stem[:-1] if len(stem) > 2 and stem[-1] == stem[-2] else stem
        if word.endswith("s") and not word.endswith("ss") and len(word) > 3:
            return word[:-1]
        return word

    def _same_proposition(self, a, b) -> bool:
        return (self._normalise_predicate(a.predicate) == self._normalise_predicate(b.predicate)
                and {k: self._norm(v) for k, v in a.arguments.items()} == {k: self._norm(v) for k, v in b.arguments.items()})

    @staticmethod
    def _norm(value):
        return re.sub(r"^(the|a|an)\s+", "", str(value).strip().lower())

def props_or_meaning(meaning):
    return meaning is not None and bool(getattr(meaning, "propositions", []))
