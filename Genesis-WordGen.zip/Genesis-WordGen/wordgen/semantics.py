"""Semantics for the British English language engine.

Provides compositional meaning construction from parse trees, without
using LLMs, neural networks, or pretrained models.  All meanings are
rule-based representations.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .grammar import Sign, first_node, clause_nodes


@dataclass
class SemanticRole:
    role: str
    entity: str
    features: dict[str, Any] = field(default_factory=dict)


@dataclass
class Proposition:
    predicate: str
    arguments: dict[str, str] = field(default_factory=dict)
    roles: list[SemanticRole] = field(default_factory=list)
    tense: str = "present"
    aspect: str = "simple"
    voice: str = "active"
    polarity: bool = True
    modality: str | None = None
    features: dict[str, Any] = field(default_factory=dict)
    confidence: float = 0.5

    def to_dict(self) -> dict[str, Any]:
        return {
            "predicate": self.predicate,
            "arguments": dict(self.arguments),
            "roles": [{"role": r.role, "entity": r.entity, "features": r.features} for r in self.roles],
            "tense": self.tense,
            "aspect": self.aspect,
            "voice": self.voice,
            "polarity": self.polarity,
            "modality": self.modality,
            "features": dict(self.features),
            "confidence": self.confidence,
        }


@dataclass
class MeaningRepresentation:
    propositions: list[Proposition] = field(default_factory=list)
    entities: dict[str, dict[str, Any]] = field(default_factory=dict)
    relations: list[dict[str, Any]] = field(default_factory=list)
    discourse: dict[str, Any] = field(default_factory=dict)
    sentence_type: str = "declarative"
    source_text: str = ""
    confidence: float = 0.5
    analysis: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "propositions": [p.to_dict() for p in self.propositions],
            "entities": dict(self.entities),
            "relations": list(self.relations),
            "discourse": dict(self.discourse),
            "sentence_type": self.sentence_type,
            "source_text": self.source_text,
            "confidence": self.confidence,
            "analysis": dict(self.analysis),
        }


class SemanticEngine:
    def __init__(self, lexicon=None):
        self.lexicon = lexicon

    def interpret(self, parse, text: str = "") -> MeaningRepresentation:
        root = getattr(parse, "root", None)
        mr = MeaningRepresentation(source_text=text or getattr(parse, "text", ""))
        if root is None:
            return mr
        mr.sentence_type = root.features.get("sentence_type") or root.features.get("clause_type") or "declarative"
        clauses = clause_nodes(root)
        if not clauses and root.cat == "Clause":
            clauses = [root]
        for clause in clauses:
            prop = self._clause_to_prop(clause)
            if prop:
                mr.propositions.append(prop)
        for prop in mr.propositions:
            mr.entities.update(prop.arguments)
        mr.confidence = min((p.confidence for p in mr.propositions), default=0.4)
        mr.analysis["clause_count"] = len(mr.propositions)
        return mr

    def _clause_to_prop(self, clause: Sign) -> Proposition | None:
        sub = clause.features.get("subject") or ""
        aux_chain = []
        verb = None
        obj = None
        prep = None
        adj = None
        clause_type = clause.features.get("clause_type", "declarative")
        for node in clause.walk():
            if node.cat in {"AUX", "MODAL"} and node.text:
                aux_chain.append(node.text)
            if node.cat == "V" and verb is None and not aux_chain and node.form in {"base", "past", "third"}:
                verb = node.text
            elif node.cat == "V" and node.form == "participle" and clause_type == "declarative":
                if verb is None:
                    verb = node.text
        if verb is None:
            for node in clause.walk():
                if node.cat == "V":
                    verb = node.text
                    break
        for node in clause.walk():
            if node.cat == "NP" and node.text and node.text != sub and obj is None:
                obj = node.text
            if node.cat == "PP" and prep is None:
                prep = node.text
            if node.cat == "ADJ" and adj is None:
                adj = node.text
        tense = "past" if any("was" in a or "had" in a or "did" in a for a in aux_chain) else "future" if "will" in aux_chain or "shall" in aux_chain else "present"
        aspect = "perfect" if "have" in aux_chain or "had" in aux_chain else "progressive" if "be" in aux_chain else "simple"
        voice = "passive" if clause_type == "passive" or (aux_chain and "was" in aux_chain and "by" in (prep or "")) else "active"
        polarity = not any(a == "not" for a in aux_chain)
        modality = next((a for a in aux_chain if a in {"can", "could", "may", "might", "must", "should", "would", "shall", "will", "ought"}), None)
        args = {}
        if sub:
            args["agent"] = sub
        if obj:
            args["patient"] = obj
        elif prep:
            args["location"] = prep
        elif adj:
            args["attribute"] = adj
        roles = []
        if sub:
            roles.append(SemanticRole("agent", sub))
        if obj:
            roles.append(SemanticRole("patient", obj))
        if prep:
            roles.append(SemanticRole("location", prep))
        if adj:
            roles.append(SemanticRole("attribute", adj))
        # Copular clauses (e.g. "She is happy") express a property even
        # though the grammar represents the copula as AUX rather than V.
        if verb is None and adj and aux_chain:
            verb = "be"
        if verb is None:
            return None
        return Proposition(
            predicate=verb,
            arguments=args,
            roles=roles,
            tense=tense,
            aspect=aspect,
            voice=voice,
            polarity=polarity,
            modality=modality,
            features={"clause_type": clause_type, "aux_chain": aux_chain},
            confidence=0.6,
        )
