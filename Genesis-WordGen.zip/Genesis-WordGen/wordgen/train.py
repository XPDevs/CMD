"""Training and validation for the British English language engine."""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

from .lexicon import Lexicon
from .grammar import Grammar, Parser
from .engine import Engine
from .knowledge import KnowledgeBase


ROOT = Path(__file__).resolve().parents[1]


def _load_knowledge() -> dict:
    lexicon = Lexicon()
    grammar = Grammar.default()
    knowledge = KnowledgeBase()
    return {
        "words_file": str(ROOT / "british-words.txt"),
        "grammar_source": "how-sentences-are-formed",
        "inventory_size": len(lexicon.inventory),
        "entries": len(lexicon),
        "rules": len(grammar.rules),
        "knowledge_file": str(knowledge.path),
        "knowledge_records": knowledge.stats()["records"],
        "concepts": knowledge.stats()["concepts"],
        "response_policies": knowledge.stats()["response_policies"],
        "dialogue_lexicon_file": str(ROOT / "genesis-dialogue-lexicon.jsonl"),
        "dialogue_lexicon_records": sum(1 for line in (ROOT / "genesis-dialogue-lexicon.jsonl").read_text(encoding="utf-8").splitlines() if line.strip()),
        "identity": knowledge.identity.get("name", "not configured"),
        "creator": knowledge.identity.get("creator", "not configured"),
        "knowledge_issues": knowledge.issues,
    }


def train(*, smoke: bool = False) -> dict:
    info = _load_knowledge()
    results = {"knowledge": info, "started_at": time.time(), "ok": not bool(info.get("knowledge_issues")), "tests": []}

    if smoke:
        engine = Engine()
        samples = [
            "The dog chased the cat.",
            "She is happy.",
            "Who came?",
            "Do you like tea?",
            "If it rains, we will stay at home.",
            "Close the door.",
            "I want to go home.",
        ]
        for s in samples:
            try:
                r = engine.process(s)
                results["tests"].append({"input": s, "parsed": bool(r.parse and r.parse.root and not r.parse.shallow), "intent": r.intent.name if r.intent else None, "response": r.response[:60]})
            except Exception as exc:
                results["tests"].append({"input": s, "error": str(exc)})
                results["ok"] = False
        # Exercise file-backed knowledge and general procedures as part of the
        # build, rather than only checking that the grammar parser starts.
        knowledge_checks = [
            ("Who are you?", "Genesis-SPT-7.0"),
            ("Who made you?", "XPDevs"),
            ("What is a computer?", "processes data"),
            ("What is a compiler?", "translates source code"),
            ("What is a knowledge graph?", "relationships between them"),
            ("What is the difference between RAM and storage?", "Storage:"),
            ("Is a dog a living thing?", "Yes"),
            ("What is 19 plus 23?", "42."),
        ]
        results["knowledge_checks"] = []
        for prompt, expected in knowledge_checks:
            try:
                check_engine = Engine()
                response = check_engine.process(prompt).response
                passed = expected.casefold() in response.casefold()
                results["knowledge_checks"].append({"input": prompt, "passed": passed, "response": response})
                if not passed:
                    results["ok"] = False
            except Exception as exc:
                results["knowledge_checks"].append({"input": prompt, "passed": False, "error": str(exc)})
                results["ok"] = False
        results["dialogue_checks"] = []
        try:
            dialogue_engine = Engine()
            first = dialogue_engine.process("I like tea.").response
            second = dialogue_engine.process("What do I like?").response
            passed = "tea" in first.casefold() and "tea" in second.casefold()
            results["dialogue_checks"].append({"inputs": ["I like tea.", "What do I like?"], "passed": passed, "responses": [first, second]})
            if not passed:
                results["ok"] = False
        except Exception as exc:
            results["dialogue_checks"].append({"passed": False, "error": str(exc)})
            results["ok"] = False
    else:
        lexicon = Lexicon()
        grammar = Grammar.default()
        parser = Parser(grammar, lexicon)
        for s in ["The dog chased the cat.", "She is happy.", "Who came?", "Do you like tea?"]:
            pr = parser.parse(s)
            if not pr.root or pr.shallow:
                results["ok"] = False
            results["tests"].append({"input": s, "parsed": bool(pr.root and not pr.shallow), "items": parser.last_item_count})

    results["elapsed"] = round(time.time() - results["started_at"], 3)
    return results


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Train/validate the British English language engine")
    parser.add_argument("--smoke", action="store_true", help="Run a smoke test through the engine")
    parser.add_argument("--json", action="store_true", help="Output JSON")
    args = parser.parse_args(argv)

    results = train(smoke=args.smoke)
    if args.json:
        print(json.dumps(results, indent=2))
        return 0 if results["ok"] else 1

    print("== British English language engine ==")
    print(f"Words: {results['knowledge']['words_file']} (inventory {results['knowledge']['inventory_size']})")
    print(f"Grammar source: {results['knowledge']['grammar_source']} ({results['knowledge']['rules']} rules)")
    print(f"Lexicon entries: {results['knowledge']['entries']}")
    print(f"Knowledge file: {results['knowledge']['knowledge_file']}")
    print(f"Knowledge records: {results['knowledge']['knowledge_records']} ({results['knowledge']['concepts']} concepts)")
    print(f"Conversation response policies: {results['knowledge']['response_policies']}")
    print(f"Dialogue relation/query lexicon records: {results['knowledge']['dialogue_lexicon_records']}")
    print(f"Identity: {results['knowledge']['identity']} by {results['knowledge']['creator']}")
    if results['knowledge']['knowledge_issues']:
        for issue in results['knowledge']['knowledge_issues']:
            print(f"Knowledge warning: {issue}")
        results['ok'] = False
    print(f"Elapsed: {results['elapsed']}s")
    print()
    for t in results["tests"]:
        if "error" in t:
            print(f"FAIL {t['input']}: {t['error']}")
        elif args.smoke:
            print(f"OK   {t['input']} -> intent={t['intent']} parsed={t['parsed']} response={t['response']}")
        else:
            print(f"OK   {t['input']} parsed={t['parsed']} items={t.get('items')}")
    if args.smoke:
        print("Knowledge checks:")
        for check in results.get("knowledge_checks", []):
            status = "OK  " if check.get("passed") else "FAIL"
            print(f"{status} {check['input']} -> {check.get('response', check.get('error', 'no response'))}")
        for check in results.get("dialogue_checks", []):
            status = "OK  " if check.get("passed") else "FAIL"
            print(f"{status} dialogue {check.get('inputs', [])} -> {' / '.join(check.get('responses', [])) or check.get('error', 'no response')}")
    print()
    if results["ok"]:
        print("All checks passed.")
        return 0
    print("Some checks failed.")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
