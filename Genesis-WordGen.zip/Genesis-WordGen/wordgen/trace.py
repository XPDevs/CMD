"""Auditable decision trace for the symbolic language engine.

This is an explanation of observable processing stages, retrieved evidence and
rules applied. It is not a dump of private free-form chain-of-thought.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any


@dataclass
class TraceStep:
    stage: str
    result: str
    evidence: str = ""
    confidence: float | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def build_trace(*, text: str, parse: Any, meaning: Any, intent: Any,
                reasoning: Any, plan: Any, realisation: Any,
                generated_validation: Any, knowledge_stats: dict[str, Any],
                dialogue_summary: dict[str, Any], knowledge_trace: list[str] | None = None) -> list[TraceStep]:
    """Create a compact trace from actual component outputs."""
    steps: list[TraceStep] = []
    root = getattr(parse, "root", None)
    parsed = bool(root)
    steps.append(TraceStep(
        "input", "Received user text", f"{len(text)} characters; input was not rewritten", 1.0))
    steps.append(TraceStep(
        "syntax", "Parsed with grammar rules" if parsed else "Used parser fallback / partial analysis",
        f"root={'present' if parsed else 'absent'}; notes={'; '.join(getattr(parse, 'notes', [])[:3]) or 'none'}",
        0.9 if parsed else 0.45))
    intent_name = getattr(intent, "name", "unknown")
    intent_conf = getattr(intent, "confidence", None)
    steps.append(TraceStep("intent", f"Classified turn as {intent_name}",
                           "Derived from the intent classifier's current output", intent_conf))
    props = getattr(meaning, "propositions", []) or []
    if props:
        summaries = []
        for p in props[:4]:
            args = getattr(p, "arguments", {}) or {}
            parts = [f"predicate={getattr(p, 'predicate', '?')}"]
            if args:
                parts.append("roles=" + ", ".join(f"{k}:{v}" for k, v in args.items()))
            if getattr(p, "polarity", None) is False:
                parts.append("negated")
            summaries.append("; ".join(parts))
        steps.append(TraceStep("semantics", "Built a structured meaning representation", " | ".join(summaries), 0.75))
    else:
        steps.append(TraceStep("semantics", "No complete proposition was extracted",
                               "The system should avoid treating a weak parse as certain meaning", 0.35))
    for note in (knowledge_trace or [])[:5]:
        steps.append(TraceStep("knowledge retrieval", note, "KnowledgeBase query trace", 0.9))
    for inf in getattr(reasoning, "inferences", [])[:8]:
        steps.append(TraceStep("inference", inf.conclusion,
                               f"rule={inf.rule}; premises={'; '.join(inf.premises)}", inf.confidence))
    for explanation in getattr(reasoning, "explanations", [])[:4]:
        steps.append(TraceStep("reasoning note", explanation, "From the symbolic reasoner", getattr(reasoning, "confidence", None)))
    steps.append(TraceStep(
        "memory", "Consulted session context",
        f"dialogue facts={dialogue_summary.get('explicit_dialogue_facts', 0)}; propositions={dialogue_summary.get('known_user_propositions', 0)}; focus={dialogue_summary.get('focus_entity') or 'none'}",
        0.9))
    features = getattr(realisation, "features", {}) or {}
    source = features.get("source") or ("dialogue memory" if features.get("fact") else "general conversation policy")
    evidence_parts = []
    if features.get("grounded"):
        evidence_parts.append("grounded=true")
    if features.get("fact"):
        fact = features["fact"]
        evidence_parts.append("fact=" + ", ".join(f"{k}={v}" for k, v in fact.items() if k in {"subject", "relation", "value", "property", "source_text"}))
    if features.get("knowledge_trace"):
        evidence_parts.append("query trace=" + " | ".join(features["knowledge_trace"][:3]))
    if features.get("source_text"):
        evidence_parts.append(f"source text={features['source_text']}")
    steps.append(TraceStep(
        "response selection", f"Selected plan={getattr(plan, 'action', 'unknown')}; response source={source}",
        "; ".join(evidence_parts) or "No specific supporting fact was attached to the response", getattr(realisation, "confidence", None)))
    valid = getattr(generated_validation, "valid", None)
    validation_detail = getattr(generated_validation, "issues", [])
    steps.append(TraceStep(
        "output validation", "Generated response passed validation" if valid else "Generated response has validation issues" if valid is False else "Generated response validation unavailable",
        "; ".join(map(str, validation_detail[:5])) if validation_detail else "No validator issues reported",
        1.0 if valid else 0.4 if valid is False else None))
    steps.append(TraceStep(
        "knowledge resources", "Loaded file-backed knowledge resources",
        "; ".join(f"{key}={value}" for key, value in knowledge_stats.items()), 1.0))
    return steps
