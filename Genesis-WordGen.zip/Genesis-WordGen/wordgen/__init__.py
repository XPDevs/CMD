"""British English language engine package.

A rule-based language engine built from the project's existing knowledge:
- british-words.txt (word inventory)
- how-sentences-are-formed (grammar specification)

No LLMs, neural networks, or external AI APIs are used.
"""

__version__ = "1.2.0"
__author__ = "Genesis"

from .lexicon import Lexicon, LexicalEntry, LexicalMatch
from .grammar import Grammar, Parser, ParseResult, Sign
from .tokeniser import tokenise, Token
from .morphology import Morphology
from .semantics import SemanticEngine, MeaningRepresentation
from .context import DialogueState, Utterance
from .intent import IntentClassifier, Intent
from .reasoning import Reasoner, ReasoningResult
from .planner import Planner, ResponsePlan
from .realiser import Realiser, RealisedUtterance
from .validator import Validator, ValidationResult
from .engine import Engine, EngineResult
from .knowledge import KnowledgeBase

__all__ = [
    "Lexicon",
    "LexicalEntry",
    "LexicalMatch",
    "Grammar",
    "Parser",
    "ParseResult",
    "Sign",
    "tokenise",
    "Token",
    "Morphology",
    "SemanticEngine",
    "MeaningRepresentation",
    "DialogueState",
    "Utterance",
    "IntentClassifier",
    "Intent",
    "Reasoner",
    "ReasoningResult",
    "Planner",
    "ResponsePlan",
    "Realiser",
    "RealisedUtterance",
    "Validator",
    "ValidationResult",
    "Engine",
    "EngineResult",
    "KnowledgeBase",
]
