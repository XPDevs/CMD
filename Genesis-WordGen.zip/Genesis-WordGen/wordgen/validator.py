"""Validation for generated and parsed sentences.

Ensures outputs conform to the grammar rules and British English
constraints derived from the project knowledge sources.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class ValidationIssue:
    severity: str
    message: str
    location: str = ""


@dataclass
class ValidationResult:
    valid: bool
    issues: list[ValidationIssue] = field(default_factory=list)
    features: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "valid": self.valid,
            "issues": [{"severity": i.severity, "message": i.message, "location": i.location} for i in self.issues],
            "features": dict(self.features),
        }


class Validator:
    def __init__(self, lexicon=None, grammar=None):
        self.lexicon = lexicon
        self.grammar = grammar

    def validate_parse(self, parse) -> ValidationResult:
        issues: list[ValidationIssue] = []
        if parse is None:
            issues.append(ValidationIssue("error", "no parse provided"))
            return ValidationResult(False, issues)
        if getattr(parse, "shallow", False):
            issues.append(ValidationIssue("warning", "only shallow analysis available"))
        if not getattr(parse, "root", None):
            issues.append(ValidationIssue("error", "no parse tree"))
            return ValidationResult(False, issues)
        root = parse.root
        if root.cat not in {"S", "Clause"}:
            issues.append(ValidationIssue("warning", f"unexpected root category {root.cat}"))
        text = getattr(parse, "text", "")
        if text and text[:1].islower() and not text[:1].isdigit():
            issues.append(ValidationIssue("warning", "sentence does not start with a capital letter"))
        if text and text.rstrip() and text.rstrip()[-1] not in {".", "!", "?", "\"", "'"}:
            issues.append(ValidationIssue("warning", "sentence missing terminal punctuation"))
        features = {"root": root.cat, "rule": root.rule_name, "shallow": getattr(parse, "shallow", False)}
        return ValidationResult(len([i for i in issues if i.severity == "error"]) == 0, issues, features)

    def validate_generated(self, text: str) -> ValidationResult:
        issues: list[ValidationIssue] = []
        if not text or not text.strip():
            issues.append(ValidationIssue("error", "empty output"))
            return ValidationResult(False, issues)
        stripped = text.strip()
        if stripped[:1].islower():
            issues.append(ValidationIssue("warning", "output should start with a capital letter"))
        if stripped[-1] not in {".", "!", "?"}:
            issues.append(ValidationIssue("warning", "output should end with punctuation"))
        return ValidationResult(True, issues, {"length": len(stripped)})
