"""Feature-lite Earley chart parser and grammar knowledge loader.

The grammar is read from ``grammar-rules.json``.  The parser deliberately keeps
syntactic analysis separate from semantic interpretation: it produces every
constituent analysis it can justify (up to a safety limit), then later modules
interpret tense, voice, roles and agreement.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, Iterator

from .lexicon import LexicalEntry, LexicalMatch, Lexicon
from .tokeniser import Token, classify_punctuation, tokenise

NONTERMINALS = {
    "S", "Clause", "VP", "VBar", "AuxP", "NP", "Nom", "PP", "AdjP", "AdvP",
    "WHP", "RelClause",
}

TERMINAL_CATEGORIES = {
    "N", "PN", "V", "GER", "ADJ", "ADV", "ADV_WH", "DET", "DET_WH", "PRON",
    "PRON_WH", "PREP", "CONJ", "SUB", "AUX", "MODAL", "NUM", "NEG", "POSS",
    "INF", "INT", "COMMA", "SEMICOLON", "COLON", "DASH", "QUOTE",
}

# The operational grammar is embedded here because the project deliberately
# uses the existing how-sentences-are-formed specification as its human-readable
# source of grammatical knowledge.  These rules are general constituent
# patterns, not stored sentences or prompt-response templates.
_DEFAULT_RULE_SPECS = [
    ("sentence", "S", ("Clause",)),
    ("coordination", "S", ("Clause", "CONJ", "Clause")),
    ("coordination-comma", "S", ("Clause", "COMMA", "CONJ", "Clause")),
    ("subordinate-initial", "S", ("SUB", "Clause", "COMMA", "Clause")),
    ("subordinate-final", "S", ("Clause", "COMMA", "SUB", "Clause")),
    ("subordinate-initial-no-comma", "S", ("SUB", "Clause", "Clause")),
    ("semicolon-coordination", "S", ("Clause", "SEMICOLON", "Clause")),
    ("declarative", "Clause", ("NP", "VP")),
    ("imperative", "Clause", ("VP",)),
    ("yes-no-question", "Clause", ("AUX", "NP", "VP")),
    ("yes-no-question-negated", "Clause", ("AUX", "NEG", "NP", "VP")),
    ("modal-question", "Clause", ("MODAL", "NP", "VP")),
    ("wh-question-aux", "Clause", ("WHP", "AUX", "NP", "VP")),
    ("wh-question-modal", "Clause", ("WHP", "MODAL", "NP", "VP")),
    ("wh-question-aux-negated", "Clause", ("WHP", "AUX", "NEG", "NP", "VP")),
    ("wh-question-aux-no-subject", "Clause", ("WHP", "AUX", "NP")),
    ("wh-question-aux-predicate", "Clause", ("WHP", "AUX", "PP")),
    ("wh-subject-question", "Clause", ("WHP", "VP")),
    ("wh-clause", "Clause", ("WHP", "Clause")),
    ("content-clause", "Clause", ("SUB", "Clause")),
    ("content-that", "Clause", ("SUB", "NP", "VP")),
    ("non-finite-clause", "Clause", ("INF", "VP")),
    ("non-finite-clause-subject", "Clause", ("INF", "NP", "VP")),
    ("exclamative-np", "Clause", ("WHP", "Nom")),
    ("vp-bare", "VP", ("VBar",)),
    ("vp-aux", "VP", ("AuxP", "VBar")),
    ("vp-aux-neg", "VP", ("AuxP", "NEG", "VBar")),
    ("vp-aux-complement-np", "VP", ("AUX", "NP")),
    ("vp-aux-complement-adj", "VP", ("AUX", "ADJ")),
    ("vp-aux-complement-pp", "VP", ("AUX", "PP")),
    ("vp-aux-complement-adv", "VP", ("AUX", "ADV")),
    ("vp-aux-neg-complement-np", "VP", ("AUX", "NEG", "NP")),
    ("vp-aux-neg-complement-adj", "VP", ("AUX", "NEG", "ADJ")),
    ("vp-aux-neg-complement-pp", "VP", ("AUX", "NEG", "PP")),
    ("vp-aux-perfect", "VP", ("AUX", "VP")),
    ("vp-aux-perfect-neg", "VP", ("AUX", "NEG", "VP")),
    ("vp-coordination", "VP", ("VP", "CONJ", "VP")),
    ("vp-complement-only-np", "VP", ("NP",)),
    ("vp-complement-only-adj", "VP", ("ADJ",)),
    ("vp-complement-only-pp", "VP", ("PP",)),
    ("vp-complement-only-adv", "VP", ("ADV",)),
    ("auxp-primary", "AuxP", ("AUX",)),
    ("auxp-modal", "AuxP", ("MODAL",)),
    ("auxp-recursive", "AuxP", ("AUX", "AuxP")),
    ("auxp-modal-recursive", "AuxP", ("MODAL", "AuxP")),
    ("vbar-intransitive", "VBar", ("V",)),
    ("vbar-transitive", "VBar", ("V", "NP")),
    ("vbar-ditransitive", "VBar", ("V", "NP", "NP")),
    ("vbar-prep-object", "VBar", ("V", "PP")),
    ("vbar-object-pp", "VBar", ("V", "NP", "PP")),
    ("vbar-pp-pp", "VBar", ("V", "PP", "PP")),
    ("vbar-copular-adj", "VBar", ("V", "AdjP")),
    ("vbar-object-adj", "VBar", ("V", "NP", "AdjP")),
    ("vbar-clausal", "VBar", ("V", "Clause")),
    ("vbar-object-clause", "VBar", ("V", "NP", "Clause")),
    ("vbar-adv", "VBar", ("V", "AdvP")),
    ("vbar-object-adv", "VBar", ("V", "NP", "AdvP")),
    ("vbar-pp-adv", "VBar", ("V", "PP", "AdvP")),
    ("vbar-infinitive", "VBar", ("V", "INF", "VP")),
    ("vbar-object-infinitive", "VBar", ("V", "NP", "INF", "VP")),
    ("vbar-catenative", "VBar", ("V", "V")),
    ("vbar-verb-particle", "VBar", ("V", "ADV")),
    ("vbar-verb-object-particle", "VBar", ("V", "NP", "ADV")),
    ("vbar-coordination", "VBar", ("VBar", "CONJ", "VBar")),
    ("np-pronoun", "NP", ("PRON",)),
    ("np-proper", "NP", ("PN",)),
    ("np-determiner", "NP", ("DET", "Nom")),
    ("np-determiner-pp", "NP", ("DET", "Nom", "PP")),
    ("np-determiner-pp-pp", "NP", ("DET", "Nom", "PP", "PP")),
    ("np-determiner-relative", "NP", ("DET", "Nom", "RelClause")),
    ("np-determiner-pp-relative", "NP", ("DET", "Nom", "PP", "RelClause")),
    ("np-numeral", "NP", ("NUM", "Nom")),
    ("np-bare", "NP", ("Nom",)),
    ("np-coordination", "NP", ("NP", "CONJ", "NP")),
    ("np-coordination-comma", "NP", ("NP", "COMMA", "CONJ", "NP")),
    ("np-possessive-noun", "NP", ("NP", "POSS", "Nom")),
    ("np-gerund", "NP", ("GER",)),
    ("np-gerund-object", "NP", ("GER", "NP")),
    ("np-numeral-bare", "NP", ("NUM",)),
    ("nom-noun", "Nom", ("N",)),
    ("nom-adjective", "Nom", ("ADJ", "Nom")),
    ("nom-adjp", "Nom", ("AdjP", "Nom")),
    ("nom-compound", "Nom", ("N", "Nom")),
    ("nom-pp", "Nom", ("N", "PP")),
    ("nom-pp-pp", "Nom", ("N", "PP", "PP")),
    ("nom-coordination", "Nom", ("Nom", "CONJ", "Nom")),
    ("pp-preposition-np", "PP", ("PREP", "NP")),
    ("pp-preposition-adv", "PP", ("PREP", "ADV")),
    ("pp-preposition-pp", "PP", ("PREP", "PP")),
    ("pp-coordination", "PP", ("PP", "CONJ", "PP")),
    ("adjp-adjective", "AdjP", ("ADJ",)),
    ("adjp-adverb", "AdjP", ("ADV", "ADJ")),
    ("adjp-pp", "AdjP", ("ADJ", "PP")),
    ("adjp-coordination", "AdjP", ("AdjP", "CONJ", "AdjP")),
    ("advp-adverb", "AdvP", ("ADV",)),
    ("advp-degree", "AdvP", ("ADV", "ADV")),
    ("advp-pp", "AdvP", ("ADV", "PP")),
    ("advp-coordination", "AdvP", ("AdvP", "CONJ", "AdvP")),
    ("whp-pronoun", "WHP", ("PRON_WH",)),
    ("whp-determiner", "WHP", ("DET_WH", "Nom")),
    ("whp-determiner-bare", "WHP", ("DET_WH",)),
    ("whp-adverb", "WHP", ("ADV_WH",)),
    ("whp-preposition", "WHP", ("PREP", "PRON_WH")),
    ("rel-pronoun", "RelClause", ("PRON_WH", "VP")),
    ("rel-pronoun-subject", "RelClause", ("PRON_WH", "NP", "VP")),
    ("rel-that", "RelClause", ("SUB", "Clause")),
    ("rel-wh-clause", "RelClause", ("PRON_WH", "Clause")),
    ("rel-whose", "RelClause", ("DET_WH", "Nom", "VP")),
]



class GrammarError(ValueError):
    pass


@dataclass(frozen=True)
class GrammarRule:
    name: str
    lhs: str
    rhs: tuple[str, ...]


@dataclass(frozen=True)
class Grammar:
    rules: tuple[GrammarRule, ...]
    metadata: dict[str, Any] = field(default_factory=dict)
    path: str = ""

    @classmethod
    def from_specs(cls, specs: list[tuple[str, str, tuple[str, ...]]], *, metadata: dict[str, Any] | None = None) -> "Grammar":
        rules: list[GrammarRule] = []
        for index, (name, lhs, rhs) in enumerate(specs):
            rule = GrammarRule(name=name, lhs=lhs, rhs=tuple(rhs))
            if rule.lhs not in NONTERMINALS:
                raise GrammarError(f"rule {rule.name}: unknown nonterminal {rule.lhs}")
            for symbol in rule.rhs:
                if symbol not in NONTERMINALS and symbol not in TERMINAL_CATEGORIES:
                    raise GrammarError(f"rule {rule.name}: unknown category {symbol}")
            rules.append(rule)
        if not rules:
            raise GrammarError("grammar has no rules")
        return cls(rules=tuple(rules), metadata=dict(metadata or {}), path="")

    @classmethod
    def default(cls) -> "Grammar":
        """Return the operational grammar derived from how-sentences-are-formed."""
        return cls.from_specs(
            _DEFAULT_RULE_SPECS,
            metadata={
                "source": "how-sentences-are-formed",
                "kind": "operational feature-lite phrase-structure grammar",
                "notes": [
                    "Rules describe general constituent patterns, not stored sentences.",
                    "The grammar overgenerates some structures; the validator decides acceptability.",
                ],
            },
        )

    @classmethod
    def from_file(cls, path: str | Path) -> "Grammar":
        """Optional extension point for a user-supplied rule file."""
        path = Path(path)
        if not path.exists():
            raise GrammarError(f"grammar file not found: {path}")
        with path.open(encoding="utf-8") as handle:
            data = json.load(handle)
        specs = []
        for index, raw in enumerate(data.get("rules", [])):
            try:
                specs.append((str(raw["name"]), str(raw["lhs"]), tuple(str(x) for x in raw["rhs"])))
            except (KeyError, TypeError) as exc:
                raise GrammarError(f"rule {index} malformed: {raw!r}") from exc
        return cls.from_specs(specs, metadata=dict(data.get("_meta", {})))

    def rules_for(self, lhs: str) -> list[GrammarRule]:
        return [r for r in self.rules if r.lhs == lhs]

    @property
    def by_lhs(self) -> dict[str, list[GrammarRule]]:
        result: dict[str, list[GrammarRule]] = {}
        for rule in self.rules:
            result.setdefault(rule.lhs, []).append(rule)
        return result


_sign_counter = 0


@dataclass(eq=False)
class Sign:
    cat: str
    start: int
    end: int
    children: tuple["Sign", ...] = ()
    token: Token | None = None
    entry: LexicalEntry | None = None
    form: str | None = None
    text: str = ""
    features: dict[str, Any] = field(default_factory=dict)
    rule_name: str = ""
    confidence: float = 1.0
    _id: int = field(default=0)

    def __post_init__(self) -> None:
        global _sign_counter
        if self._id == 0:
            _sign_counter += 1
            self._id = _sign_counter
        if not self.text:
            self.text = " ".join(self.leaves()) if self.children else (self.token.text if self.token else "")

    @property
    def id(self) -> int:
        return self._id

    def leaves(self) -> list[str]:
        if self.token is not None:
            return [self.token.text]
        result: list[str] = []
        for child in self.children:
            result.extend(child.leaves())
        return result

    def tokens(self) -> list[Token]:
        if self.token is not None:
            return [self.token]
        result: list[Token] = []
        for child in self.children:
            result.extend(child.tokens())
        return result

    def walk(self) -> Iterator["Sign"]:
        yield self
        for child in self.children:
            yield from child.walk()

    def find(self, category: str) -> list["Sign"]:
        return [node for node in self.walk() if node.cat == category]

    def direct(self, category: str) -> list["Sign"]:
        return [child for child in self.children if child.cat == category]

    def head(self) -> "Sign":
        for child in self.children:
            if child.cat in {
                "N", "PN", "PRON", "GER", "V", "VBar", "NP", "Nom",
                "ADJ", "ADV", "PREP", "AUX", "MODAL",
            }:
                return child.head()
        return self

    def pretty(self, indent: int = 0) -> str:
        line = f"{'  ' * indent}{self.cat}"
        if self.rule_name:
            line += f" [{self.rule_name}]"
        if self.token is not None:
            line += f" {self.token.text!r}"
        lines = [line]
        for child in self.children:
            lines.append(child.pretty(indent + 1))
        return "\n".join(lines)


@dataclass(frozen=True)
class Item:
    rule_index: int
    dot: int
    start: int
    children: tuple[Sign, ...]

    @property
    def base_key(self) -> tuple[Any, ...]:
        return (self.rule_index, self.dot, self.start)

    @property
    def key(self) -> tuple[Any, ...]:
        return (
            self.rule_index,
            self.dot,
            self.start,
            tuple(c.id for c in self.children),
        )


@dataclass
class ParseResult:
    text: str
    tokens: list[Token]
    root: Sign | None
    alternatives: list[Sign] = field(default_factory=list)
    shallow: bool = False
    uncertain: bool = False
    notes: list[str] = field(default_factory=list)
    score: float = 0.0

    @property
    def parsed(self) -> bool:
        return self.root is not None

    def all_roots(self) -> list[Sign]:
        return self.alternatives or ([self.root] if self.root else [])


# ---------------------------------------------------------------------------
# Lexical category assignment
# ---------------------------------------------------------------------------

def categories_for(match: LexicalMatch) -> list[str]:
    """Map a lexical property to the parser's syntactic category labels."""
    entry = match.entry
    pos = entry.pos
    form = match.form
    features = entry.features
    cats: list[str] = []
    if pos == "noun":
        cats.append("N")
    elif pos == "proper_noun":
        cats.append("PN")
    elif pos in {"verb", "auxiliary"}:
        cats.append("V" if pos == "verb" else "AUX")
        if form in {"gerund", "present_participle"} and pos == "verb":
            cats.append("GER")
    elif pos == "modal":
        cats.append("MODAL")
    elif pos == "adjective":
        cats.append("ADJ")
    elif pos == "adverb":
        if features.get("negation") or match.surface.lower() in {"not", "never"}:
            cats.append("NEG")
        cats.append("ADV")
        if features.get("wh"):
            cats.append("ADV_WH")
    elif pos == "determiner":
        cats.append("DET")
        if features.get("wh"):
            cats.append("DET_WH")
    elif pos == "pronoun":
        cats.append("PRON")
        if features.get("wh"):
            cats.append("PRON_WH")
    elif pos == "preposition":
        cats.append("PREP")
        if match.surface.lower() == "to":
            cats.append("INF")
    elif pos == "conjunction":
        if features.get("conjunction_type") == "subordinating":
            cats.append("SUB")
        else:
            cats.append("CONJ")
        if entry.lemma.lower() == "that":
            cats.append("SUB")
    elif pos == "number":
        cats.append("NUM")
    elif pos == "interjection":
        cats.append("INT")
    return cats


def token_categories(
    token: Token,
    lexicon: Lexicon,
    *,
    include_unknown: bool = True,
) -> list[tuple[str, LexicalMatch | None]]:
    if token.kind == "punctuation":
        return [(classify_punctuation(token), None)]
    if token.kind == "quote":
        return [("QUOTE", None)]
    if token.kind == "number":
        cats: list[tuple[str, LexicalMatch | None]] = [("NUM", None)]
        return cats
    result: list[tuple[str, LexicalMatch | None]] = []
    matches = lexicon.matches(token.text, include_unknown=include_unknown)
    for match in matches:
        for cat in categories_for(match):
            result.append((cat, match))
    # A number word such as "one" may be both a number and a determiner/noun;
    # its lexical entries decide.  If nothing is known, retain a noun reading
    # so that unknown-word handling can proceed.
    if not result:
        for entry in lexicon.guess(token.text):
            fake = LexicalMatch(entry, token.text, "base", entry.confidence, "unknown-word-handler")
            for cat in categories_for(fake):
                result.append((cat, fake))
    return _dedupe_categories(result)


def _dedupe_categories(
    items: Iterable[tuple[str, LexicalMatch | None]],
) -> list[tuple[str, LexicalMatch | None]]:
    seen: set[tuple[str, int]] = set()
    result: list[tuple[str, LexicalMatch | None]] = []
    for cat, match in items:
        key = (cat, id(match.entry) if match else -1)
        if key in seen:
            continue
        seen.add(key)
        result.append((cat, match))
    return result


def lexical_signs(
    tokens: list[Token],
    lexicon: Lexicon,
    *,
    include_unknown: bool = True,
) -> list[list[Sign]]:
    result: list[list[Sign]] = []
    for index, token in enumerate(tokens):
        signs: list[Sign] = []
        seen: set[tuple[str, str, str]] = set()
        for cat, match in token_categories(token, lexicon, include_unknown=include_unknown):
            if cat not in TERMINAL_CATEGORIES:
                continue
            key = (cat, match.entry.lemma if match else token.text, match.form if match else "base")
            if key in seen:
                continue
            seen.add(key)
            features: dict[str, Any] = {}
            if match:
                features = dict(match.entry.features)
                features["form"] = match.form
                features["pos"] = match.entry.pos
                features["lemma"] = match.entry.lemma
                features["confidence"] = match.confidence
                features["source"] = match.provenance
                if match.entry.pos in {"noun", "proper_noun"}:
                    if match.form == "plural":
                        features["number"] = "plural"
                    else:
                        features["number"] = "singular"
                    features.setdefault("person", 3)
                elif match.entry.pos == "pronoun":
                    features.setdefault("person", 3)
                    features.setdefault("number", "singular")
            signs.append(
                Sign(
                    cat=cat,
                    start=index,
                    end=index + 1,
                    token=token,
                    entry=match.entry if match else None,
                    form=match.form if match else None,
                    text=token.text,
                    features=features,
                    confidence=match.confidence if match else 0.2,
                )
            )
        result.append(signs)
    return result


# ---------------------------------------------------------------------------
# Feature aggregation
# ---------------------------------------------------------------------------

def aggregate_features(cat: str, children: tuple[Sign, ...], rule_name: str = "") -> dict[str, Any]:
    features: dict[str, Any] = {"rule": rule_name}
    if cat == "NP":
        head = _find_np_head(children)
        if head:
            features.update(head.features)
            features["np_head"] = head.text
            features["np_known"] = head.confidence >= 0.5
        # Coordination is plural even when each conjunct is singular.
        if any(c.cat == "CONJ" for c in children):
            features["number"] = "plural"
            features["coordination"] = True
    elif cat == "Nom":
        nouns = [c for c in children if c.cat in {"N", "PN", "GER"}]
        if nouns:
            features.update(nouns[-1].features)
            features["head"] = nouns[-1].text
    elif cat == "Clause":
        subject = next((c for c in children if c.cat == "NP"), None)
        if subject:
            features["subject"] = subject.text
            features["subject_number"] = subject.features.get("number", "unknown")
            features["subject_person"] = subject.features.get("person", 3)
        if any(c.cat == "AUX" for c in children):
            features["finite"] = True
            features["clause_type"] = "interrogative" if children and children[0].cat in {"AUX", "MODAL", "WHP"} else "declarative"
        elif children and children[0].cat == "VP":
            features["clause_type"] = "imperative"
            features["finite"] = False
        elif children and children[0].cat == "WHP":
            features["clause_type"] = "interrogative"
        elif children and children[0].cat == "SUB":
            features["clause_type"] = "subordinate"
            features["finite"] = True
        elif children and children[0].cat == "INF":
            features["clause_type"] = "non-finite"
            features["finite"] = False
        else:
            features["clause_type"] = "declarative"
    elif cat == "VP":
        auxes = [c for c in children if c.cat in {"AUX", "MODAL"} or c.cat == "AuxP"]
        features["has_aux"] = bool(auxes) or any(
            c.cat == "AUX" for c in children
        )
        if auxes:
            features["aux_chain"] = _aux_chain(children)
    elif cat == "S":
        clauses = [c for c in children if c.cat == "Clause"]
        if clauses:
            features["clause_type"] = clauses[-1].features.get("clause_type")
            features["sentence_type"] = "compound" if len(clauses) > 1 else "simple"
    for child in children:
        if child.cat in {"AUX", "MODAL", "V"} and child.features:
            features.setdefault("verb_form", child.features.get("form"))
    return features


def _find_np_head(children: tuple[Sign, ...]) -> Sign | None:
    for child in children:
        if child.cat == "PRON":
            return child
        if child.cat == "PN":
            return child
        if child.cat == "Nom":
            return child.head()
        if child.cat == "NP":
            return child.head()
    return children[-1] if children else None


def _aux_chain(children: tuple[Sign, ...]) -> list[str]:
    chain: list[str] = []
    for child in children:
        if child.cat in {"AUX", "MODAL"}:
            chain.append(child.text)
        elif child.cat == "AuxP":
            chain.extend(
                c.text for c in child.walk() if c.cat in {"AUX", "MODAL"}
            )
    return chain


# ---------------------------------------------------------------------------
# Parser
# ---------------------------------------------------------------------------

class Parser:
    """A general chart parser for the loaded grammar."""

    def __init__(self, grammar: Grammar, lexicon: Lexicon, *, max_items: int = 18000, max_alternatives: int = 4) -> None:
        self.grammar = grammar
        self.lexicon = lexicon
        self.max_items = max_items
        self.max_alternatives = max_alternatives
        self._rules_by_lhs = grammar.by_lhs
        self.last_item_count = 0

    def parse(self, text: str) -> ParseResult:
        tokens = tokenise(text)
        # Terminal punctuation is represented by the clause type and is not a
        # constituent.  Keep internal commas, semicolons and dashes.
        kept = [
            t for t in tokens
            if not (t.kind == "punct" and False)
        ]
        kept = [
            t for t in kept
            if not (
                t.kind == "punctuation"
                and t.text in {".", "!", "?"}
                and (t is kept[-1] if kept else True)
            )
        ]
        # Remove final question/bang/period even if followed by a quote.
        while kept and kept[-1].kind == "quote":
            kept.pop()
        if kept and kept[-1].kind == "punctuation" and kept[-1].text in {".", "!", "?"}:
            kept.pop()
        kept = [t for t in kept if t.kind != "quote"]
        if not kept:
            return ParseResult(text=text, tokens=[], root=None, notes=["empty input"])

        lex = lexical_signs(kept, self.lexicon)
        self.last_item_count = 0
        try:
            roots = self._earley(kept, lex)
        except _ChartOverflow as exc:
            return self._shallow(text, kept, [str(exc)])

        if not roots:
            return self._shallow(text, kept, ["no complete grammatical analysis found"])

        scored = sorted(roots, key=lambda r: self._score(r, text), reverse=True)
        best = scored[0]
        uncertain = len(scored) > 1 and abs(self._score(scored[0], text) - self._score(scored[1], text)) < 0.3
        notes: list[str] = []
        if uncertain:
            notes.append("more than one grammatical analysis is possible")
        return ParseResult(
            text=text,
            tokens=kept,
            root=best,
            alternatives=scored[: self.max_alternatives],
            uncertain=uncertain,
            notes=notes,
            score=self._score(best, text),
        )

    # -- Earley implementation -------------------------------------------
    def _earley(self, tokens: list[Token], lex: list[list[Sign]]) -> list[Sign]:
        n = len(tokens)
        chart: list[list[Item]] = [[] for _ in range(n + 1)]
        # Beam-packed chart: for each (rule, dot, start) keep at most
        # ``self.max_alternatives`` distinct derivations.  This preserves
        # genuine structural ambiguity while preventing an exponential parse
        # forest.
        keys: list[dict[tuple[Any, ...], set[tuple[int, ...]]]] = [
            {} for _ in range(n + 1)
        ]
        completed: list[list[Sign]] = [[] for _ in range(n + 1)]
        completed_keys: list[set[tuple[Any, ...]]] = [set() for _ in range(n + 1)]
        roots: list[Sign] = []
        self._rule_index = {id(rule): i for i, rule in enumerate(self.grammar.rules)}

        def add(position: int, item: Item) -> None:
            variants = keys[position].setdefault(item.base_key, set())
            child_key = tuple(c.id for c in item.children)
            if child_key in variants:
                return
            if len(variants) >= self.max_alternatives:
                return
            variants.add(child_key)
            chart[position].append(item)
            self.last_item_count += 1
            if self.last_item_count > self.max_items:
                raise _ChartOverflow(
                    f"grammar search exceeded the safety limit of {self.max_items} items"
                )

        def completed_sign(item: Item) -> Sign:
            rule = self.grammar.rules[item.rule_index]
            children = item.children
            features = aggregate_features(rule.lhs, children, rule.name)
            confidence = min([c.confidence for c in children], default=1.0)
            return Sign(
                cat=rule.lhs,
                start=item.start,
                end=item.end if hasattr(item, "end") else 0,
                children=children,
                features=features,
                rule_name=rule.name,
                confidence=confidence,
            )

        # Seed with all S rules.
        for rule in self._rules_by_lhs.get("S", []):
            index = self._rule_index[id(rule)]
            add(0, Item(index, 0, 0, ()))

        for position in range(n + 1):
            cursor = 0
            while cursor < len(chart[position]):
                item = chart[position][cursor]
                cursor += 1
                rule = self.grammar.rules[item.rule_index]
                if item.dot == len(rule.rhs):
                    structural_key = (
                        rule.lhs,
                        item.start,
                        position,
                        tuple(c.id for c in item.children),
                    )
                    if structural_key in completed_keys[position]:
                        continue
                    sign = Sign(
                        cat=rule.lhs,
                        start=item.start,
                        end=position,
                        children=item.children,
                        features=aggregate_features(rule.lhs, item.children, rule.name),
                        rule_name=rule.name,
                        confidence=min([c.confidence for c in item.children], default=1.0),
                    )
                    completed_keys[position].add(structural_key)
                    completed[position].append(sign)
                    # Completer: parents waiting at the start of this span.
                    for parent in list(chart[item.start]):
                        parent_rule = self.grammar.rules[parent.rule_index]
                        if (
                            parent.dot < len(parent_rule.rhs)
                            and parent_rule.rhs[parent.dot] == rule.lhs
                        ):
                            add(
                                position,
                                Item(
                                    parent.rule_index,
                                    parent.dot + 1,
                                    parent.start,
                                    parent.children + (sign,),
                                ),
                            )
                    if rule.lhs == "S" and item.start == 0 and position == n:
                        roots.append(sign)
                    continue

                symbol = rule.rhs[item.dot]
                if symbol in NONTERMINALS:
                    # Predictor.
                    for next_rule in self._rules_by_lhs.get(symbol, []):
                        add(position, Item(self._rule_index[id(next_rule)], 0, position, ()))
                    # If a completion for this symbol already exists ending at
                    # this position (important for left recursion), advance now.
                    for sign in list(completed[position]):
                        if sign.cat == symbol and sign.end == position:
                            add(
                                position,
                                Item(
                                    item.rule_index,
                                    item.dot + 1,
                                    item.start,
                                    item.children + (sign,),
                                ),
                            )
                else:
                    # Scanner.  Consuming a terminal moves the item to the
                    # next chart position.
                    if position >= n:
                        continue
                    for sign in lex[position]:
                        if sign.cat == symbol:
                            add(
                                position + 1,
                                Item(
                                    item.rule_index,
                                    item.dot + 1,
                                    item.start,
                                    item.children + (sign,),
                                ),
                            )
        # Deduplicate roots by structural key, preserving best-scoring variants.
        unique: dict[tuple[Any, ...], Sign] = {}
        for root in roots:
            key = (root.cat, tuple(c.id for c in root.children))
            unique.setdefault(key, root)
        return list(unique.values())

    def _score(self, sign: Sign, text: str = "") -> float:
        score = sign.confidence
        unknown = sum(1 for t in sign.tokens() if t.kind == "word" and not self.lexicon.is_known_surface(t.text))
        score -= 0.08 * unknown
        # Prefer analyses with a lexical subject and an explicit verb phrase.
        if any(c.cat == "NP" for c in sign.children):
            score += 0.1
        penalty_rules = {
            "vp-complement-only-np": 0.15,
            "vp-complement-only-adj": 0.2,
            "vp-complement-only-pp": 0.15,
            "vp-complement-only-adv": 0.2,
            "np-bare": 0.05,
            "np-numeral-bare": 0.1,
            "vbar-catenative": 0.25,
            "exclamative-np": 0.35,
            "wh-clause": 0.1,
        }
        for node in sign.walk():
            score -= penalty_rules.get(node.rule_name, 0.0)
        # Prefer a finite clause with a subject.
        clause = next((n for n in sign.walk() if n.cat == "Clause"), None)
        if clause and clause.features.get("finite"):
            score += 0.1
        # Wh-pronouns should not normally be analysed as ordinary declarative
        # subjects ("Who came?" is a subject question).
        for node in sign.walk():
            if node.cat == "NP" and node.rule_name == "np-pronoun":
                child = node.children[0] if node.children else None
                if child and child.cat == "PRON" and child.features.get("wh"):
                    score -= 0.35
            if node.cat == "Clause" and node.rule_name.startswith("wh-"):
                score += 0.2
        # Match sentence punctuation to clause type when the input explicitly
        # marks a question.
        if text.rstrip().endswith("?"):
            clause_type = clause.features.get("clause_type") if clause else None
            if clause_type == "interrogative":
                score += 0.15
            else:
                score -= 0.2
        return score

    def _shallow(self, text: str, tokens: list[Token], notes: list[str]) -> ParseResult:
        """Conservative fallback used when no full parse is found."""
        signs: list[Sign] = []
        for index, token in enumerate(tokens):
            cats = token_categories(token, self.lexicon)
            if cats:
                cat, match = cats[0]
                signs.append(
                    Sign(
                        cat=cat,
                        start=index,
                        end=index + 1,
                        token=token,
                        entry=match.entry if match else None,
                        form=match.form if match else None,
                        text=token.text,
                        features=dict(match.entry.features) if match else {},
                        confidence=match.confidence if match else 0.2,
                    )
                )
        root = None
        if signs:
            # Build a transparent flat structure so callers can still inspect
            # tokens without pretending a full grammatical analysis succeeded.
            root = Sign(
                cat="S",
                start=0,
                end=len(signs),
                children=tuple(signs),
                features={"clause_type": "unknown", "shallow": True},
                rule_name="shallow-fallback",
                confidence=0.2,
            )
        return ParseResult(
            text=text,
            tokens=tokens,
            root=root,
            alternatives=[],
            shallow=True,
            uncertain=True,
            notes=notes + ["shallow analysis only"],
        )


class _ChartOverflow(RuntimeError):
    pass


# ---------------------------------------------------------------------------
# Tree utilities
# ---------------------------------------------------------------------------

def tree_text(sign: Sign | None) -> str:
    return " ".join(sign.leaves()) if sign else ""


def find_nodes(sign: Sign | None, category: str) -> list[Sign]:
    if sign is None:
        return []
    return sign.find(category)


def first_node(sign: Sign | None, category: str) -> Sign | None:
    nodes = find_nodes(sign, category)
    return nodes[0] if nodes else None


def clause_nodes(sign: Sign | None) -> list[Sign]:
    return find_nodes(sign, "Clause")


def describe_tree(sign: Sign | None) -> str:
    return sign.pretty() if sign else "<no parse>"
