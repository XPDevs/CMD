"""Response planning for the British English language engine."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class ResponsePlan:
    action: str
    content_plan: list[dict[str, Any]] = field(default_factory=list)
    strategy: str = ""
    confidence: float = 0.5
    features: dict[str, Any] = field(default_factory=dict)


class Planner:
    def plan(self, intent, meaning=None, reasoning=None, context=None) -> ResponsePlan:
        if intent is None:
            return ResponsePlan(action="clarify", strategy="fallback", confidence=0.3)
        if intent.name == "wh_question":
            return ResponsePlan(action="answer_question", strategy="informative", content_plan=[{"type": "answer", "based_on": "context_or_parse"}], confidence=0.7)
        if intent.name == "yes_no_question":
            return ResponsePlan(action="answer_yes_no", strategy="confirm_or_deny", content_plan=[{"type": "yes_no"}], confidence=0.7)
        if intent.name == "command":
            return ResponsePlan(action="acknowledge_command", strategy="cooperative", content_plan=[{"type": "acknowledgement"}], confidence=0.7)
        if intent.name == "request":
            return ResponsePlan(action="consider_request", strategy="polite", content_plan=[{"type": "consideration"}], confidence=0.7)
        if intent.name == "social":
            return ResponsePlan(action="respond_socially", strategy="polite", content_plan=[{"type": "social"}], confidence=0.7)
        return ResponsePlan(action="respond", strategy="informative", content_plan=[{"type": "statement"}], confidence=0.6)
