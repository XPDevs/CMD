"""CLI for the British English language engine."""

from __future__ import annotations

import argparse
import json
import sys

from .engine import Engine


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="British English language engine")
    parser.add_argument("text", nargs="*", help="Text to process (if omitted, start interactive session)")
    parser.add_argument("--json", action="store_true", help="Output full analysis as JSON")
    parser.add_argument("--parse-only", action="store_true", help="Only show parse tree")
    parser.add_argument("--show-reasoning", action="store_true", help="Show an auditable trace of parsing, evidence, rules and response selection")
    args = parser.parse_args(argv)

    engine = Engine()

    if args.text:
        text = " ".join(args.text)
        result = engine.process(text)
        if args.json:
            data = {
                "input": result.input,
                "response": result.response,
                "intent": result.intent.to_dict() if result.intent else None,
                "parse": result.parse.root.pretty() if result.parse and result.parse.root else None,
                "shallow": result.parse.shallow if result.parse else None,
                "notes": result.parse.notes if result.parse else [],
                "validation": result.validation.to_dict() if result.validation else None,
                "generated_validation": result.generated_validation.to_dict() if result.generated_validation else None,
                "context": result.context_summary,
                "reasoning_trace": [step.to_dict() for step in result.reasoning_trace],
            }
            print(json.dumps(data, indent=2))
            return 0
        if args.parse_only:
            if result.parse and result.parse.root:
                print(result.parse.root.pretty())
            else:
                print(result.parse.notes if result.parse else "no parse")
            return 0
        if args.show_reasoning:
            _print_trace(result.reasoning_trace)
            print("\n--- Final answer ---")
        print(result.response)
        return 0

    print(f"{engine.knowledge_base.identity.get('name', 'British English language engine')} by {engine.knowledge_base.identity.get('creator', 'XPDevs')} (rule-based)")
    print("Loads lexical, grammar, concept and dialogue data files. Type 'quit' or 'exit' to leave.")
    print("Type /think on to show the decision/evidence trace, /think off to hide it. This trace explains observable processing; it is not private free-form chain-of-thought.\n")
    show_reasoning = False
    while True:
        try:
            text = input("> ").strip()
        except EOFError:
            break
        except KeyboardInterrupt:
            break
        if not text:
            continue
        if text.lower() in {"quit", "exit", "q"}:
            break
        if text.lower() in {"/think on", "/reasoning on", "/trace on"}:
            show_reasoning = True
            print("Decision trace enabled.\n")
            continue
        if text.lower() in {"/think off", "/reasoning off", "/trace off"}:
            show_reasoning = False
            print("Decision trace disabled.\n")
            continue
        result = engine.process(text)
        if show_reasoning:
            _print_trace(result.reasoning_trace)
            print("\n--- Final answer ---")
        print(result.response)
        print()
    print("Goodbye.")
    return 0


def _print_trace(trace):
    print("\n--- Genesis reasoning trace (observable steps, rules and evidence) ---")
    for index, step in enumerate(trace, 1):
        confidence = "" if step.confidence is None else f" [confidence={step.confidence:.2f}]"
        print(f"{index}. {step.stage}: {step.result}{confidence}")
        if step.evidence:
            print(f"   Evidence: {step.evidence}")
    print("--- End reasoning trace ---")


if __name__ == "__main__":
    raise SystemExit(main())
