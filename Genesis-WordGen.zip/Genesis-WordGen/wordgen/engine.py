"""End-to-end engine orchestration."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .lexicon import Lexicon
from .grammar import Grammar, Parser
from .semantics import SemanticEngine
from .context import DialogueState, Utterance
from .intent import IntentClassifier
from .reasoning import Reasoner
from .planner import Planner
from .realiser import Realiser
from .validator import Validator
from .knowledge import KnowledgeBase
from .trace import TraceStep, build_trace


@dataclass
class EngineResult:
    input: str
    parse: Any = None
    meaning: Any = None
    intent: Any = None
    reasoning: Any = None
    plan: Any = None
    response: str = ""
    realisation: Any = None
    validation: Any = None
    generated_validation: Any = None
    context_summary: dict[str, Any] = field(default_factory=dict)
    reasoning_trace: list[TraceStep] = field(default_factory=list)


class Engine:
    def __init__(self, lexicon: Lexicon | None = None, grammar: Grammar | None = None):
        self.lexicon = lexicon or Lexicon()
        self.grammar = grammar or Grammar.default()
        self.parser = Parser(self.grammar, self.lexicon)
        self.semantics = SemanticEngine(self.lexicon)
        self.intent = IntentClassifier()
        self.reasoning = Reasoner()
        self.planner = Planner()
        self.knowledge_base = KnowledgeBase()
        self.realiser = Realiser(self.lexicon, self.knowledge_base)
        self.validator = Validator(self.lexicon, self.grammar)
        self.context = DialogueState()

    def process(self, text: str) -> EngineResult:
        parse = self.parser.parse(text)
        meaning = self.semantics.interpret(parse, text)
        intent = self.intent.classify(parse, text)
        # Learn explicit, extractable facts from the current user turn before
        # response planning so the reply can acknowledge information even when
        # the full syntactic parser falls back to shallow analysis. Extraction
        # is idempotent; DialogueState.add() also records the utterance history.
        self.context.knowledge.learn(text)
        reasoning = self.reasoning.reason(meaning, intent, self.context)
        plan = self.planner.plan(intent, meaning, reasoning, self.context)
        realisation = self.realiser.realise(plan, self.context, meaning, intent)
        response = realisation.text
        validation = self.validator.validate_parse(parse)
        generated_validation = self.validator.validate_generated(response)
        trace = build_trace(
            text=text, parse=parse, meaning=meaning, intent=intent,
            reasoning=reasoning, plan=plan, realisation=realisation,
            generated_validation=generated_validation,
            knowledge_stats=self.knowledge_base.stats(),
            dialogue_summary={**self.context.summary(), "knowledge_base": self.knowledge_base.stats()},
            knowledge_trace=getattr(self.knowledge_base, "last_query_trace", []),
        )
        user_utt = Utterance(text=text, role="user", parse=parse, meaning=meaning, intent=intent)
        self.context.add(user_utt)
        resp_utt = Utterance(text=response, role="assistant", intent=intent)
        self.context.add(resp_utt)
        return EngineResult(
            input=text,
            parse=parse,
            meaning=meaning,
            intent=intent,
            reasoning=reasoning,
            plan=plan,
            response=response,
            realisation=realisation,
            validation=validation,
            generated_validation=generated_validation,
            context_summary={**self.context.summary(), "knowledge_base": self.knowledge_base.stats()},
            reasoning_trace=trace,
        )

    def generate(self, text: str) -> str:
        result = self.process(text)
        return result.response
