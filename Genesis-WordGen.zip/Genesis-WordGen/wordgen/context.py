"""Context management for multi-turn interaction."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .dialogue_knowledge import DialogueKnowledge


@dataclass
class Utterance:
    text: str
    role: str
    parse: Any = None
    meaning: Any = None
    intent: Any = None


@dataclass
class DialogueState:
    history: list[Utterance] = field(default_factory=list)
    user_facts: list[Any] = field(default_factory=list)
    entities: dict[str, dict[str, Any]] = field(default_factory=dict)
    topics: list[str] = field(default_factory=list)
    focus: str | None = None
    last_subject: str | None = None
    last_predicate: str | None = None
    last_object: str | None = None
    turn_count: int = 0
    session_id: str = ""
    knowledge: DialogueKnowledge = field(default_factory=DialogueKnowledge)

    def add(self, utterance: Utterance) -> None:
        self.history.append(utterance)
        self.turn_count += 1
        if utterance.role == "user":
            self.knowledge.learn(utterance.text)
        if utterance.meaning and utterance.role == "user":
            for p in getattr(utterance.meaning, "propositions", []):
                self.user_facts.append(p)
                if p.arguments.get("agent"):
                    self.last_subject = p.arguments["agent"]
                if p.predicate:
                    self.last_predicate = p.predicate
                if p.arguments.get("patient") or p.arguments.get("location") or p.arguments.get("attribute"):
                    self.last_object = p.arguments.get("patient") or p.arguments.get("location") or p.arguments.get("attribute")
                for k, v in getattr(p, "arguments", {}).items():
                    self.entities[v] = {"role": k}

    def recent(self, n: int = 5) -> list[Utterance]:
        return self.history[-n:]

    def summary(self) -> dict[str, Any]:
        return {
            "turn_count": self.turn_count,
            "last_subject": self.last_subject,
            "last_predicate": self.last_predicate,
            "last_object": self.last_object,
            "entities": list(self.entities.keys()),
            "topics": self.topics,
            "known_user_propositions": len(self.user_facts),
            "explicit_dialogue_facts": len(self.knowledge.facts),
            "focus_entity": self.knowledge.focus_entity,
            "dialogue_facts": self.knowledge.snapshot(),
        }
