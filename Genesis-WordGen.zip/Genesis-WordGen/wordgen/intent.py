"""Intent recognition for the British English language engine."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any
from pathlib import Path
import json

from .grammar import clause_nodes


@dataclass
class Intent:
    name: str
    confidence: float
    slots: dict[str, Any] = field(default_factory=dict)
    arguments: list[str] = field(default_factory=list)
    features: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "confidence": self.confidence,
            "slots": dict(self.slots),
            "arguments": list(self.arguments),
            "features": dict(self.features),
        }


class IntentClassifier:
    def __init__(self, data_path: str | Path | None = None):
        root = Path(__file__).resolve().parents[1]
        self.data_path = Path(data_path) if data_path else root / "genesis-dialogue-lexicon.jsonl"
        self.cue_groups: dict[str, list[str]] = {}
        if self.data_path.exists():
            for line in self.data_path.read_text(encoding="utf-8").splitlines():
                try:
                    record = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if record.get("type") == "intent_cues" and record.get("key"):
                    self.cue_groups[str(record["key"])] = [str(item).casefold() for item in record.get("forms", [])]

    def classify(self, parse, text: str = "") -> Intent:
        root = getattr(parse, "root", None)
        if root is None:
            return Intent("unknown", 0.2, {"text": text})
        clauses = clause_nodes(root)
        clause = clauses[0] if clauses else root
        ctype = clause.features.get("clause_type", "")
        rule = clause.rule_name
        tokens = [t.text.lower() for t in getattr(parse, "tokens", [])]
        if root.rule_name == "imperative" or ctype == "imperative" or (rule == "imperative"):
            return Intent("command", 0.8, {"tokens": tokens}, features={"rule": rule})
        if ctype == "interrogative" or any(t.endswith("?") for t in [text]) or rule.startswith("wh-") or rule.startswith("yes-no"):
            wh_words = self.cue_groups.get("wh_words", [])
            if any(w in tokens for w in wh_words):
                return Intent("wh_question", 0.85, {"wh_word": next((w for w in wh_words if w in tokens), None), "tokens": tokens}, features={"rule": rule})
            return Intent("yes_no_question", 0.85, {"tokens": tokens}, features={"rule": rule})
        if any(w in tokens for w in self.cue_groups.get("request", [])):
            return Intent("request", 0.8, {"tokens": tokens})
        if any(w in tokens for w in self.cue_groups.get("social", [])):
            return Intent("social", 0.7, {"tokens": tokens})
        if any(w in tokens for w in self.cue_groups.get("opinion", [])):
            return Intent("assertion_opinion", 0.7, {"tokens": tokens})
        return Intent("statement", 0.7, {"tokens": tokens}, features={"rule": rule})
