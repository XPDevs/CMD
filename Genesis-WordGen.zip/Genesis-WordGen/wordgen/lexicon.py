"""Lexical engine built from the project's existing ``british-words.txt``.

The word file is a plain surface-form inventory.  It supplies the recognised
word stock; grammatical categories and morphological behaviour are derived by
the rules in this module and in :mod:`wordgen.morphology`.  No separate word
database is created.

Unknown surface forms are handled provisionally rather than being declared
invalid.  Entries added at runtime live in memory only and never rewrite the
project's knowledge file.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterator

from . import morphology

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_WORDS = ROOT / "british-words.txt"

VALID_POS = {
    "noun", "verb", "adjective", "adverb", "determiner", "pronoun",
    "preposition", "conjunction", "auxiliary", "modal", "number",
    "proper_noun", "interjection",
}


class LexiconError(ValueError):
    pass


@dataclass
class LexicalEntry:
    lemma: str
    pos: str
    forms: dict[str, str] = field(default_factory=dict)
    features: dict[str, Any] = field(default_factory=dict)
    valency: list[str] = field(default_factory=list)
    complements: list[str] = field(default_factory=list)
    senses: list[dict[str, str]] = field(default_factory=list)
    semantic_class: list[str] = field(default_factory=list)
    synonyms: list[str] = field(default_factory=list)
    antonyms: list[str] = field(default_factory=list)
    derivations: list[str] = field(default_factory=list)
    collocations: list[str] = field(default_factory=list)
    register: str = "neutral"
    domain: str = "general"
    usage: str | None = None
    spelling_variant: str | None = None
    source: str = "british-words.txt"
    confidence: float = 0.5
    status: str = "heuristic"

    @property
    def gloss(self) -> str | None:
        if not self.senses:
            return None
        return str(self.senses[0].get("gloss", "")) or None

    def has_class(self, name: str) -> bool:
        return name in self.semantic_class

    def to_dict(self) -> dict[str, Any]:
        return {
            "lemma": self.lemma,
            "pos": self.pos,
            "forms": dict(self.forms),
            "features": dict(self.features),
            "valency": list(self.valency),
            "complements": list(self.complements),
            "senses": list(self.senses),
            "semantic_class": list(self.semantic_class),
            "synonyms": list(self.synonyms),
            "antonyms": list(self.antonyms),
            "derivations": list(self.derivations),
            "collocations": list(self.collocations),
            "register": self.register,
            "domain": self.domain,
            "usage": self.usage,
            "spelling_variant": self.spelling_variant,
            "source": self.source,
            "confidence": self.confidence,
            "status": self.status,
        }


@dataclass(frozen=True)
class LexicalMatch:
    entry: LexicalEntry
    surface: str
    form: str
    confidence: float
    provenance: str

    @property
    def pos(self) -> str:
        return self.entry.pos


# ---------------------------------------------------------------------------
# Closed-class grammatical vocabulary
# ---------------------------------------------------------------------------

_DET = {
    "the": {"definiteness": "definite", "number": "any"},
    "a": {"definiteness": "indefinite", "number": "singular"},
    "an": {"definiteness": "indefinite", "number": "singular"},
    "this": {"definiteness": "demonstrative", "number": "singular"},
    "that": {"definiteness": "demonstrative", "number": "singular"},
    "these": {"definiteness": "demonstrative", "number": "plural"},
    "those": {"definiteness": "demonstrative", "number": "plural"},
    "my": {"definiteness": "possessive", "person": 1},
    "your": {"definiteness": "possessive", "person": 2},
    "his": {"definiteness": "possessive", "person": 3, "gender": "masculine"},
    "her": {"definiteness": "possessive", "person": 3, "gender": "feminine"},
    "its": {"definiteness": "possessive", "person": 3},
    "our": {"definiteness": "possessive", "person": 1, "number": "plural"},
    "their": {"definiteness": "possessive", "person": 3, "number": "plural"},
    "some": {"quantification": "existential"},
    "any": {"quantification": "non-specific"},
    "no": {"quantification": "negative"},
    "every": {"quantification": "universal", "number": "singular"},
    "each": {"quantification": "distributive", "number": "singular"},
    "all": {"quantification": "universal"},
    "both": {"quantification": "dual", "number": "plural"},
    "either": {"quantification": "alternative", "number": "singular"},
    "neither": {"quantification": "negative", "number": "singular"},
    "much": {"quantification": "mass", "number": "singular"},
    "many": {"quantification": "count", "number": "plural"},
    "few": {"quantification": "count", "number": "plural"},
    "little": {"quantification": "mass", "number": "singular"},
    "several": {"quantification": "plural", "number": "plural"},
    "enough": {"quantification": "sufficiency"},
    "another": {"quantification": "additional", "number": "singular"},
    "such": {"quantification": "quality"},
    "which": {"wh": True},
    "whose": {"wh": True},
    "what": {"wh": True},
}

_PRONOUNS = {
    "I": {"person": 1, "number": "singular", "case": "nominative", "gender": "any"},
    "you": {"person": 2, "number": "any", "case": "nominative", "gender": "any"},
    "he": {"person": 3, "number": "singular", "case": "nominative", "gender": "masculine"},
    "she": {"person": 3, "number": "singular", "case": "nominative", "gender": "feminine"},
    "it": {"person": 3, "number": "singular", "case": "nominative", "gender": "neuter"},
    "we": {"person": 1, "number": "plural", "case": "nominative", "gender": "any"},
    "they": {"person": 3, "number": "plural", "case": "nominative", "gender": "any"},
    "me": {"person": 1, "number": "singular", "case": "accusative", "gender": "any"},
    "him": {"person": 3, "number": "singular", "case": "accusative", "gender": "masculine"},
    "us": {"person": 1, "number": "plural", "case": "accusative", "gender": "any"},
    "them": {"person": 3, "number": "plural", "case": "accusative", "gender": "any"},
    "myself": {"person": 1, "number": "singular", "case": "reflexive"},
    "yourself": {"person": 2, "number": "singular", "case": "reflexive"},
    "himself": {"person": 3, "number": "singular", "case": "reflexive", "gender": "masculine"},
    "herself": {"person": 3, "number": "singular", "case": "reflexive", "gender": "feminine"},
    "itself": {"person": 3, "number": "singular", "case": "reflexive"},
    "ourselves": {"person": 1, "number": "plural", "case": "reflexive"},
    "yourselves": {"person": 2, "number": "plural", "case": "reflexive"},
    "themselves": {"person": 3, "number": "plural", "case": "reflexive"},
    "who": {"wh": True, "person": 3, "case": "nominative", "gender": "any"},
    "whom": {"wh": True, "person": 3, "case": "accusative", "gender": "any"},
    "which": {"wh": True, "person": 3, "gender": "neuter"},
    "that": {"wh": True, "person": 3, "gender": "any"},
    "what": {"wh": True, "person": 3, "number": "singular", "gender": "neuter"},
    "whose": {"wh": True, "person": 3},
    "someone": {"person": 3, "number": "singular", "indefinite": True},
    "somebody": {"person": 3, "number": "singular", "indefinite": True},
    "something": {"person": 3, "number": "singular", "indefinite": True, "gender": "neuter"},
    "anyone": {"person": 3, "number": "singular", "indefinite": True},
    "anybody": {"person": 3, "number": "singular", "indefinite": True},
    "anything": {"person": 3, "number": "singular", "indefinite": True, "gender": "neuter"},
    "everyone": {"person": 3, "number": "singular", "indefinite": True},
    "everybody": {"person": 3, "number": "singular", "indefinite": True},
    "everything": {"person": 3, "number": "singular", "indefinite": True, "gender": "neuter"},
    "nobody": {"person": 3, "number": "singular", "indefinite": True, "negative": True},
    "nothing": {"person": 3, "number": "singular", "indefinite": True, "negative": True},
    "none": {"person": 3, "negative": True},
}

_PRONOUN_FORMS = {
    "I": {"nominative": "I", "accusative": "me", "possessive_det": "my", "possessive_pron": "mine", "reflexive": "myself"},
    "you": {"nominative": "you", "accusative": "you", "possessive_det": "your", "possessive_pron": "yours", "reflexive": "you"},
    "he": {"nominative": "he", "accusative": "him", "possessive_det": "his", "possessive_pron": "his", "reflexive": "himself"},
    "she": {"nominative": "she", "accusative": "her", "possessive_det": "her", "possessive_pron": "hers", "reflexive": "herself"},
    "it": {"nominative": "it", "accusative": "it", "possessive_det": "its", "possessive_pron": "its", "reflexive": "itself"},
    "we": {"nominative": "we", "accusative": "us", "possessive_det": "our", "possessive_pron": "ours", "reflexive": "ourselves"},
    "they": {"nominative": "they", "accusative": "them", "possessive_det": "their", "possessive_pron": "theirs", "reflexive": "themselves"},
    "me": {"nominative": "I", "accusative": "me", "possessive_det": "my", "possessive_pron": "mine", "reflexive": "myself"},
    "him": {"nominative": "he", "accusative": "him", "possessive_det": "his", "possessive_pron": "his", "reflexive": "himself"},
    "us": {"nominative": "we", "accusative": "us", "possessive_det": "our", "possessive_pron": "ours", "reflexive": "ourselves"},
    "them": {"nominative": "they", "accusative": "them", "possessive_det": "their", "possessive_pron": "theirs", "reflexive": "themselves"},
    "myself": {"nominative": "I", "accusative": "me", "possessive_det": "my", "possessive_pron": "mine", "reflexive": "myself"},
    "yourself": {"nominative": "you", "accusative": "you", "possessive_det": "your", "possessive_pron": "yours", "reflexive": "yourself"},
    "himself": {"nominative": "he", "accusative": "him", "possessive_det": "his", "possessive_pron": "his", "reflexive": "himself"},
    "herself": {"nominative": "she", "accusative": "her", "possessive_det": "her", "possessive_pron": "hers", "reflexive": "herself"},
    "itself": {"nominative": "it", "accusative": "it", "possessive_det": "its", "possessive_pron": "its", "reflexive": "itself"},
    "ourselves": {"nominative": "we", "accusative": "us", "possessive_det": "our", "possessive_pron": "ours", "reflexive": "ourselves"},
    "yourselves": {"nominative": "you", "accusative": "you", "possessive_det": "your", "possessive_pron": "yours", "reflexive": "yourselves"},
    "themselves": {"nominative": "they", "accusative": "them", "possessive_det": "their", "possessive_pron": "theirs", "reflexive": "themselves"},
    "who": {"nominative": "who", "accusative": "whom", "possessive_det": "whose", "possessive_pron": "whose", "reflexive": "who"},
    "whom": {"nominative": "who", "accusative": "whom", "possessive_det": "whose", "possessive_pron": "whose", "reflexive": "who"},
    "which": {"nominative": "which", "accusative": "which", "possessive_det": "whose", "possessive_pron": "whose", "reflexive": "which"},
    "that": {"nominative": "that", "accusative": "that", "possessive_det": "whose", "possessive_pron": "whose", "reflexive": "that"},
    "what": {"nominative": "what", "accusative": "what", "possessive_det": "whose", "possessive_pron": "whose", "reflexive": "what"},
    "whose": {"nominative": "whose", "accusative": "whose", "possessive_det": "whose", "possessive_pron": "whose", "reflexive": "whose"},
    "someone": {"nominative": "someone", "accusative": "someone", "reflexive": "themselves"},
    "somebody": {"nominative": "somebody", "accusative": "somebody", "reflexive": "themselves"},
    "something": {"nominative": "something", "accusative": "something", "reflexive": "itself"},
    "anyone": {"nominative": "anyone", "accusative": "anyone", "reflexive": "themselves"},
    "anybody": {"nominative": "anybody", "accusative": "anybody", "reflexive": "themselves"},
    "anything": {"nominative": "anything", "accusative": "anything", "reflexive": "itself"},
    "everyone": {"nominative": "everyone", "accusative": "everyone", "reflexive": "themselves"},
    "everybody": {"nominative": "everybody", "accusative": "everybody", "reflexive": "themselves"},
    "everything": {"nominative": "everything", "accusative": "everything", "reflexive": "itself"},
    "nobody": {"nominative": "nobody", "accusative": "nobody", "reflexive": "themselves"},
    "nothing": {"nominative": "nothing", "accusative": "nothing", "reflexive": "itself"},
    "none": {"nominative": "none", "accusative": "none", "reflexive": "themselves"},
}

_AUX = {
    "be": {"auxiliary_type": "primary", "irregular": True},
    "have": {"auxiliary_type": "primary", "irregular": True},
    "do": {"auxiliary_type": "primary", "irregular": True},
}

_MODALS = {
    "can": {"modal_type": "ability"},
    "could": {"modal_type": "ability-past"},
    "may": {"modal_type": "permission"},
    "might": {"modal_type": "possibility"},
    "must": {"modal_type": "obligation"},
    "shall": {"modal_type": "future"},
    "should": {"modal_type": "obligation"},
    "will": {"modal_type": "future"},
    "would": {"modal_type": "conditional"},
    "ought": {"modal_type": "obligation", "requires_to": True},
}

_PREPOSITIONS = [
    "in", "on", "at", "by", "with", "from", "to", "of", "for", "about",
    "under", "over", "through", "between", "among", "during", "after",
    "before", "since", "until", "without", "within", "into", "onto", "upon",
    "across", "along", "around", "behind", "below", "beneath", "beside",
    "beyond", "near", "off", "out", "past", "towards", "toward", "up",
    "down", "against", "despite", "except", "like", "as", "than",
]

_CONJUNCTIONS = {
    "and": "coordinating", "or": "coordinating", "nor": "coordinating",
    "but": "coordinating", "yet": "coordinating", "so": "coordinating",
    "for": "coordinating", "if": "subordinating", "unless": "subordinating",
    "although": "subordinating", "though": "subordinating",
    "while": "subordinating", "when": "subordinating",
    "whenever": "subordinating", "where": "subordinating",
    "whereas": "subordinating", "because": "subordinating",
    "since": "subordinating", "until": "subordinating",
    "before": "subordinating", "after": "subordinating",
    "whether": "subordinating", "that": "subordinating",
}

_NUMBERS = {
    "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6,
    "seven": 7, "eight": 8, "nine": 9, "ten": 10, "hundred": 100,
    "thousand": 1000,
}

_INTERJECTIONS = {
    "hello", "hi", "goodbye", "please", "thanks", "sorry", "yes", "no",
}

# ---------------------------------------------------------------------------
# Core open-class grammatical properties
# ---------------------------------------------------------------------------
# Membership is still checked against british-words.txt.  These tables only
# describe *how* familiar entries behave (valency, semantic class, degree).

_CORE_NOUNS = {
    "dog": ("animal", "countable"), "cat": ("animal", "countable"),
    "otter": ("animal", "countable"), "bird": ("animal", "countable"),
    "horse": ("animal", "countable"), "fish": ("animal", "countable"),
    "person": ("person", "countable"), "man": ("person", "countable"),
    "woman": ("person", "countable"), "child": ("person", "countable"),
    "boy": ("person", "countable"), "girl": ("person", "countable"),
    "student": ("person", "countable"), "teacher": ("person", "countable"),
    "doctor": ("person", "countable"), "friend": ("person", "countable"),
    "neighbour": ("person", "countable"), "writer": ("person", "countable"),
    "reader": ("person", "countable"), "speaker": ("person", "countable"),
    "listener": ("person", "countable"), "engineer": ("person", "countable"),
    "city": ("place", "countable"), "town": ("place", "countable"),
    "village": ("place", "countable"), "country": ("place", "countable"),
    "house": ("place", "countable"), "home": ("place", "countable"),
    "school": ("place", "countable"), "university": ("place", "countable"),
    "library": ("place", "countable"), "hospital": ("place", "countable"),
    "office": ("place", "countable"), "shop": ("place", "countable"),
    "market": ("place", "countable"), "garden": ("place", "countable"),
    "park": ("place", "countable"), "room": ("place", "countable"),
    "road": ("place", "countable"), "street": ("place", "countable"),
    "river": ("place", "countable"), "mountain": ("place", "countable"),
    "sea": ("place", "countable"), "sky": ("place", "uncountable"),
    "tree": ("object", "countable"), "flower": ("object", "countable"),
    "book": ("object", "countable"), "letter": ("object", "countable"),
    "word": ("linguistic_unit", "countable"), "sentence": ("linguistic_unit", "countable"),
    "phrase": ("linguistic_unit", "countable"), "clause": ("linguistic_unit", "countable"),
    "language": ("language", "countable"), "grammar": ("language", "uncountable"),
    "question": ("communication", "countable"), "answer": ("communication", "countable"),
    "idea": ("abstract", "countable"), "problem": ("abstract", "countable"),
    "reason": ("abstract", "countable"), "example": ("abstract", "countable"),
    "story": ("communication", "countable"), "song": ("object", "countable"),
    "film": ("object", "countable"), "music": ("abstract", "uncountable"),
    "food": ("substance", "uncountable"), "water": ("substance", "uncountable"),
    "tea": ("substance", "uncountable"), "coffee": ("substance", "uncountable"),
    "bread": ("substance", "uncountable"), "apple": ("object", "countable"),
    "car": ("object", "countable"), "train": ("object", "countable"),
    "bus": ("object", "countable"), "plane": ("object", "countable"),
    "boat": ("object", "countable"), "computer": ("object", "countable"),
    "machine": ("object", "countable"), "tool": ("object", "countable"),
    "table": ("object", "countable"), "chair": ("object", "countable"),
    "door": ("object", "countable"), "window": ("object", "countable"),
    "day": ("time", "countable"), "week": ("time", "countable"),
    "month": ("time", "countable"), "year": ("time", "countable"),
    "morning": ("time", "countable"), "evening": ("time", "countable"),
    "night": ("time", "countable"), "time": ("time", "uncountable"),
    "moment": ("time", "countable"), "place": ("place", "countable"),
    "thing": ("abstract", "countable"), "fact": ("abstract", "countable"),
    "truth": ("abstract", "countable"), "information": ("abstract", "uncountable"),
    "knowledge": ("abstract", "uncountable"), "meaning": ("language", "countable"),
    "structure": ("abstract", "countable"), "rule": ("abstract", "countable"),
    "subject": ("grammar", "countable"), "object": ("grammar", "countable"),
    "verb": ("grammar", "countable"), "noun": ("grammar", "countable"),
    "adjective": ("grammar", "countable"), "adverb": ("grammar", "countable"),
    "preposition": ("grammar", "countable"), "pronoun": ("grammar", "countable"),
    "determiner": ("grammar", "countable"), "conjunction": ("grammar", "countable"),
    "tense": ("grammar", "countable"), "aspect": ("grammar", "countable"),
    "voice": ("grammar", "countable"), "mood": ("grammar", "countable"),
    "negation": ("grammar", "uncountable"), "agreement": ("grammar", "uncountable"),
    "auxiliary": ("grammar", "countable"), "modal": ("grammar", "countable"),
    "agent": ("semantic_role", "countable"), "patient": ("semantic_role", "countable"),
    "theme": ("semantic_role", "countable"), "recipient": ("semantic_role", "countable"),
    "experiencer": ("semantic_role", "countable"), "location": ("semantic_role", "countable"),
    "instrument": ("semantic_role", "countable"), "reference": ("language", "uncountable"),
    "ambiguity": ("language", "uncountable"), "context": ("language", "countable"),
    "discourse": ("language", "uncountable"), "punctuation": ("writing", "uncountable"),
    "capitalisation": ("writing", "uncountable"), "spelling": ("writing", "uncountable"),
    "standard": ("abstract", "countable"), "variety": ("language", "countable"),
    "register": ("language", "countable"), "error": ("abstract", "countable"),
    "correction": ("abstract", "countable"), "analysis": ("abstract", "countable"),
    "generation": ("abstract", "uncountable"), "engine": ("object", "countable"),
    "algorithm": ("abstract", "countable"), "representation": ("abstract", "countable"),
    "feature": ("abstract", "countable"), "category": ("abstract", "countable"),
    "function": ("abstract", "countable"), "relationship": ("abstract", "countable"),
    "inference": ("abstract", "countable"), "evidence": ("abstract", "uncountable"),
    "confidence": ("abstract", "uncountable"), "source": ("abstract", "countable"),
    "licence": ("abstract", "countable"), "limitation": ("abstract", "countable"),
    "colour": ("property", "countable"), "favour": ("abstract", "countable"),
    "centre": ("place", "countable"), "theatre": ("place", "countable"),
    "defence": ("abstract", "countable"), "traveller": ("person", "countable"),
    "knife": ("object", "countable"), "leaf": ("object", "countable"),
    "life": ("abstract", "countable"), "wife": ("person", "countable"),
    "wolf": ("animal", "countable"), "shelf": ("object", "countable"),
    "potato": ("food", "countable"), "tomato": ("food", "countable"),
    "hero": ("person", "countable"), "analysis_result": ("abstract", "countable"),
    "comparison": ("abstract", "countable"), "condition": ("abstract", "countable"),
    "instruction": ("communication", "countable"), "request": ("communication", "countable"),
    "explanation": ("communication", "countable"), "description": ("communication", "countable"),
    "reply": ("communication", "countable"), "session": ("time", "countable"),
    "turn": ("discourse", "countable"), "option": ("abstract", "countable"),
    "test": ("abstract", "countable"), "result": ("abstract", "countable"),
    "work": ("activity", "uncountable"), "sun": ("object", "countable"),
    "moon": ("object", "countable"), "star": ("object", "countable"),
    "baby": ("person", "countable"), "family": ("group", "countable"),
    "group": ("group", "countable"), "team": ("group", "countable"),
    "company": ("group", "countable"), "government": ("group", "countable"),
    "world": ("place", "countable"), "ground": ("place", "uncountable"),
    "air": ("substance", "uncountable"), "light": ("substance", "uncountable"),
    "sound": ("substance", "countable"), "name": ("language", "countable"),
    "number": ("number", "countable"), "part": ("abstract", "countable"),
    "end": ("time", "countable"), "start": ("time", "countable"),
    "kind": ("abstract", "countable"), "type": ("abstract", "countable"),
    "case": ("abstract", "countable"), "point": ("abstract", "countable"),
    "line": ("object", "countable"), "page": ("object", "countable"),
    "hand": ("body", "countable"), "head": ("body", "countable"),
    "eye": ("body", "countable"), "face": ("body", "countable"),
    "voice": ("sound", "countable"), "language_engine": ("object", "countable"),
    "tea": ("substance", "uncountable"), "coffee": ("substance", "uncountable"),
    "performance": ("abstract", "countable"), "accuracy": ("abstract", "uncountable"),
}

_CORE_VERBS = {
    # lemma: (valency flags, complements, semantic classes)
    "be": ({"copular"}, {"np", "adj", "pp", "adv"}, {"state"}),
    "have": ({"transitive"}, {"np"}, {"possession"}),
    "do": ({"transitive", "intransitive"}, {"np"}, {"action"}),
    "go": ({"intransitive"}, {"pp", "adv"}, {"motion"}),
    "come": ({"intransitive"}, {"pp", "adv"}, {"motion"}),
    "see": ({"transitive", "intransitive"}, {"np"}, {"perception"}),
    "look": ({"intransitive"}, {"pp", "adv", "adj"}, {"perception"}),
    "watch": ({"transitive", "intransitive"}, {"np"}, {"perception"}),
    "hear": ({"transitive", "intransitive"}, {"np"}, {"perception"}),
    "listen": ({"intransitive"}, {"pp"}, {"perception"}),
    "speak": ({"intransitive", "transitive"}, {"np", "pp"}, {"communication"}),
    "talk": ({"intransitive"}, {"pp"}, {"communication"}),
    "say": ({"transitive"}, {"np", "clause"}, {"communication"}),
    "tell": ({"ditransitive", "transitive"}, {"np", "np", "clause"}, {"communication"}),
    "ask": ({"ditransitive", "transitive"}, {"np", "np", "clause"}, {"communication"}),
    "answer": ({"transitive", "intransitive"}, {"np", "clause"}, {"communication"}),
    "think": ({"intransitive", "transitive", "clausal"}, {"np", "clause", "pp"}, {"cognition"}),
    "know": ({"transitive", "clausal"}, {"np", "clause"}, {"cognition"}),
    "believe": ({"transitive", "clausal"}, {"np", "clause"}, {"cognition"}),
    "understand": ({"transitive", "clausal"}, {"np", "clause"}, {"cognition"}),
    "learn": ({"transitive", "intransitive"}, {"np", "clause", "pp"}, {"cognition"}),
    "teach": ({"ditransitive", "transitive"}, {"np", "np", "clause"}, {"education"}),
    "read": ({"transitive", "intransitive"}, {"np"}, {"communication"}),
    "write": ({"transitive", "intransitive"}, {"np", "pp"}, {"communication"}),
    "study": ({"transitive", "intransitive"}, {"np", "pp"}, {"education"}),
    "work": ({"intransitive"}, {"pp", "adv"}, {"action"}),
    "play": ({"transitive", "intransitive"}, {"np", "pp"}, {"action"}),
    "live": ({"intransitive"}, {"pp", "adv"}, {"state"}),
    "love": ({"transitive"}, {"np"}, {"emotion"}),
    "like": ({"transitive"}, {"np", "clause"}, {"emotion"}),
    "want": ({"transitive", "clausal"}, {"np", "clause"}, {"desire"}),
    "need": ({"transitive", "clausal"}, {"np", "clause"}, {"necessity"}),
    "make": ({"transitive", "ditransitive"}, {"np", "np", "adj"}, {"creation"}),
    "create": ({"transitive"}, {"np"}, {"creation"}),
    "build": ({"transitive", "intransitive"}, {"np", "pp"}, {"creation"}),
    "break": ({"transitive", "intransitive"}, {"np"}, {"change"}),
    "fix": ({"transitive"}, {"np"}, {"change"}),
    "open": ({"transitive", "intransitive"}, {"np"}, {"change"}),
    "close": ({"transitive", "intransitive"}, {"np"}, {"change"}),
    "give": ({"ditransitive", "transitive"}, {"np", "np", "pp"}, {"transfer"}),
    "take": ({"transitive"}, {"np", "pp"}, {"transfer"}),
    "get": ({"transitive", "intransitive"}, {"np", "adj", "pp"}, {"change"}),
    "put": ({"transitive"}, {"np", "pp"}, {"placement"}),
    "bring": ({"transitive", "ditransitive"}, {"np", "np", "pp"}, {"transfer"}),
    "send": ({"transitive", "ditransitive"}, {"np", "np", "pp"}, {"transfer"}),
    "receive": ({"transitive"}, {"np", "pp"}, {"transfer"}),
    "buy": ({"transitive", "ditransitive"}, {"np", "np", "pp"}, {"commerce"}),
    "sell": ({"transitive", "ditransitive"}, {"np", "np", "pp"}, {"commerce"}),
    "eat": ({"transitive", "intransitive"}, {"np"}, {"consumption"}),
    "drink": ({"transitive", "intransitive"}, {"np"}, {"consumption"}),
    "sleep": ({"intransitive"}, {"pp", "adv"}, {"state"}),
    "wake": ({"intransitive", "transitive"}, {"np", "pp"}, {"state"}),
    "walk": ({"intransitive", "transitive"}, {"np", "pp", "adv"}, {"motion"}),
    "run": ({"intransitive", "transitive"}, {"np", "pp", "adv"}, {"motion"}),
    "sit": ({"intransitive"}, {"pp", "adv"}, {"posture"}),
    "stand": ({"intransitive", "transitive"}, {"np", "pp"}, {"posture"}),
    "wait": ({"intransitive"}, {"pp", "adv"}, {"state"}),
    "help": ({"transitive", "ditransitive"}, {"np", "np", "pp", "clause"}, {"assistance"}),
    "try": ({"transitive", "clausal"}, {"np", "clause"}, {"attempt"}),
    "use": ({"transitive"}, {"np", "pp"}, {"instrument"}),
    "find": ({"transitive"}, {"np", "np", "adj", "pp"}, {"perception"}),
    "lose": ({"transitive"}, {"np"}, {"change"}),
    "keep": ({"transitive", "ditransitive"}, {"np", "np", "adj"}, {"possession"}),
    "change": ({"transitive", "intransitive"}, {"np", "pp", "adj"}, {"change"}),
    "become": ({"copular"}, {"np", "adj"}, {"change"}),
    "seem": ({"copular"}, {"adj", "np", "clause"}, {"appearance"}),
    "appear": ({"intransitive", "copular"}, {"pp", "adj", "np"}, {"appearance"}),
    "feel": ({"transitive", "copular"}, {"np", "adj", "clause"}, {"perception"}),
    "remember": ({"transitive", "clausal"}, {"np", "clause"}, {"cognition"}),
    "forget": ({"transitive", "clausal"}, {"np", "clause"}, {"cognition"}),
    "explain": ({"transitive", "ditransitive"}, {"np", "np", "clause", "pp"}, {"communication"}),
    "describe": ({"transitive"}, {"np", "clause"}, {"communication"}),
    "compare": ({"transitive"}, {"np", "np", "pp"}, {"cognition"}),
    "correct": ({"transitive"}, {"np"}, {"change"}),
    "analyse": ({"transitive"}, {"np"}, {"cognition"}),
    "construct": ({"transitive"}, {"np", "pp"}, {"creation"}),
    "generate": ({"transitive"}, {"np", "pp"}, {"creation"}),
    "form": ({"transitive", "intransitive"}, {"np", "pp"}, {"creation"}),
    "contain": ({"transitive"}, {"np"}, {"composition"}),
    "include": ({"transitive"}, {"np"}, {"composition"}),
    "follow": ({"transitive", "intransitive"}, {"np", "pp"}, {"order"}),
    "precede": ({"transitive"}, {"np"}, {"order"}),
    "depend": ({"intransitive"}, {"pp"}, {"relation"}),
    "mean": ({"transitive", "clausal"}, {"np", "clause"}, {"meaning"}),
    "refer": ({"intransitive"}, {"pp"}, {"meaning"}),
    "show": ({"transitive", "ditransitive"}, {"np", "np", "clause"}, {"communication"}),
    "prove": ({"transitive", "clausal"}, {"np", "clause"}, {"reasoning"}),
    "suggest": ({"transitive", "clausal"}, {"np", "clause"}, {"communication"}),
    "require": ({"transitive", "clausal"}, {"np", "clause"}, {"necessity"}),
    "allow": ({"transitive", "ditransitive"}, {"np", "np", "clause"}, {"permission"}),
    "permit": ({"transitive", "ditransitive"}, {"np", "np", "clause"}, {"permission"}),
    "enable": ({"transitive"}, {"np", "clause"}, {"causation"}),
    "cause": ({"transitive"}, {"np", "clause"}, {"causation"}),
    "happen": ({"intransitive"}, {"pp", "adv"}, {"event"}),
    "occur": ({"intransitive"}, {"pp", "adv"}, {"event"}),
    "exist": ({"intransitive"}, {"pp"}, {"state"}),
    "remain": ({"intransitive", "copular"}, {"pp", "adj", "np"}, {"state"}),
    "stay": ({"intransitive", "copular"}, {"pp", "adj", "np"}, {"state"}),
    "start": ({"transitive", "intransitive"}, {"np", "clause", "pp"}, {"change"}),
    "begin": ({"transitive", "intransitive"}, {"np", "clause", "pp"}, {"change"}),
    "end": ({"transitive", "intransitive"}, {"np", "pp"}, {"change"}),
    "finish": ({"transitive", "intransitive"}, {"np", "pp"}, {"change"}),
    "continue": ({"transitive", "intransitive"}, {"np", "clause", "pp"}, {"change"}),
    "stop": ({"transitive", "intransitive"}, {"np", "clause", "pp"}, {"change"}),
    "meet": ({"transitive", "intransitive"}, {"np", "pp"}, {"social"}),
    "visit": ({"transitive", "intransitive"}, {"np", "pp"}, {"social"}),
    "travel": ({"intransitive"}, {"pp", "adv"}, {"motion"}),
    "arrive": ({"intransitive"}, {"pp", "adv"}, {"motion"}),
    "leave": ({"transitive", "intransitive"}, {"np", "pp"}, {"motion"}),
    "return": ({"intransitive", "transitive"}, {"np", "pp"}, {"motion"}),
    "call": ({"transitive", "ditransitive"}, {"np", "np", "clause"}, {"communication"}),
    "name": ({"transitive", "ditransitive"}, {"np", "np"}, {"naming"}),
    "choose": ({"transitive", "clausal"}, {"np", "clause"}, {"decision"}),
    "decide": ({"transitive", "clausal"}, {"np", "clause"}, {"decision"}),
    "agree": ({"intransitive", "clausal"}, {"pp", "clause"}, {"agreement"}),
    "disagree": ({"intransitive", "clausal"}, {"pp", "clause"}, {"agreement"}),
    "promise": ({"transitive", "ditransitive", "clausal"}, {"np", "np", "clause"}, {"commitment"}),
    "hope": ({"transitive", "clausal"}, {"clause", "pp"}, {"desire"}),
    "wish": ({"transitive", "clausal"}, {"np", "clause"}, {"desire"}),
    "expect": ({"transitive", "clausal"}, {"np", "clause"}, {"cognition"}),
    "imagine": ({"transitive", "clausal"}, {"np", "clause"}, {"cognition"}),
    "consider": ({"transitive", "clausal"}, {"np", "clause"}, {"cognition"}),
    "regard": ({"transitive"}, {"np", "pp"}, {"cognition"}),
    "treat": ({"transitive"}, {"np", "pp"}, {"action"}),
    "classify": ({"transitive"}, {"np", "pp"}, {"cognition"}),
    "identify": ({"transitive"}, {"np", "pp"}, {"cognition"}),
    "distinguish": ({"transitive"}, {"np", "np", "pp"}, {"cognition"}),
    "mention": ({"transitive", "clausal"}, {"np", "clause"}, {"communication"}),
    "discuss": ({"transitive"}, {"np", "clause"}, {"communication"}),
    "share": ({"transitive", "ditransitive"}, {"np", "np", "pp"}, {"transfer"}),
    "join": ({"transitive", "intransitive"}, {"np", "pp"}, {"connection"}),
    "separate": ({"transitive", "intransitive"}, {"np", "pp"}, {"connection"}),
    "connect": ({"transitive"}, {"np", "pp"}, {"connection"}),
    "relate": ({"transitive"}, {"np", "pp"}, {"connection"}),
    "improve": ({"transitive", "intransitive"}, {"np", "pp"}, {"change"}),
    "increase": ({"transitive", "intransitive"}, {"np", "pp"}, {"change"}),
    "decrease": ({"transitive", "intransitive"}, {"np", "pp"}, {"change"}),
    "grow": ({"intransitive", "transitive"}, {"np", "pp"}, {"change"}),
    "reduce": ({"transitive", "intransitive"}, {"np", "pp"}, {"change"}),
    "avoid": ({"transitive"}, {"np", "clause"}, {"action"}),
    "prevent": ({"transitive"}, {"np", "np", "clause"}, {"causation"}),
    "protect": ({"transitive"}, {"np", "pp"}, {"action"}),
    "support": ({"transitive"}, {"np", "clause"}, {"assistance"}),
    "oppose": ({"transitive"}, {"np", "clause"}, {"action"}),
    "accept": ({"transitive", "clausal"}, {"np", "clause"}, {"agreement"}),
    "refuse": ({"transitive", "clausal"}, {"np", "clause"}, {"agreement"}),
    "offer": ({"transitive", "ditransitive"}, {"np", "np", "clause"}, {"transfer"}),
    "request": ({"transitive", "clausal"}, {"np", "clause"}, {"communication"}),
    "demand": ({"transitive", "clausal"}, {"np", "clause"}, {"communication"}),
    "order": ({"transitive", "ditransitive", "clausal"}, {"np", "np", "clause"}, {"communication"}),
    "chase": ({"transitive", "intransitive"}, {"np"}, {"motion"}),
    "bark": ({"intransitive"}, {"pp", "adv"}, {"sound"}),
    "laugh": ({"intransitive"}, {"pp"}, {"emotion"}),
    "smile": ({"intransitive"}, {"pp"}, {"emotion"}),
    "rain": ({"intransitive"}, {"pp"}, {"weather"}),
    "snow": ({"intransitive"}, {"pp"}, {"weather"}),
    "shine": ({"intransitive"}, {"pp"}, {"weather"}),
    "paint": ({"transitive", "intransitive"}, {"np"}, {"creation"}),
    "polish": ({"transitive", "intransitive"}, {"np"}, {"change"}),
    "carry": ({"transitive"}, {"np", "pp"}, {"transfer"}),
    "push": ({"transitive", "intransitive"}, {"np", "pp"}, {"motion"}),
    "pull": ({"transitive", "intransitive"}, {"np", "pp"}, {"motion"}),
    "throw": ({"transitive", "ditransitive"}, {"np", "np", "pp"}, {"motion"}),
    "catch": ({"transitive"}, {"np"}, {"motion"}),
    "cut": ({"transitive", "intransitive"}, {"np", "pp"}, {"change"}),
    "wash": ({"transitive", "intransitive"}, {"np"}, {"change"}),
    "clean": ({"transitive", "intransitive"}, {"np"}, {"change"}),
    "cook": ({"transitive", "intransitive"}, {"np"}, {"creation"}),
    "sing": ({"transitive", "intransitive"}, {"np"}, {"music"}),
    "dance": ({"intransitive", "transitive"}, {"np", "pp"}, {"music"}),
    "draw": ({"transitive", "intransitive"}, {"np"}, {"creation"}),
    "count": ({"transitive", "intransitive"}, {"np"}, {"number"}),
    "measure": ({"transitive", "intransitive"}, {"np", "pp"}, {"measurement"}),
    "check": ({"transitive", "clausal"}, {"np", "clause"}, {"evaluation"}),
    "repair": ({"transitive"}, {"np"}, {"change"}),
    "repeat": ({"transitive", "clausal"}, {"np", "clause"}, {"communication"}),
    "rephrase": ({"transitive"}, {"np"}, {"communication"}),
    "translate": ({"transitive"}, {"np", "pp"}, {"communication"}),
    "summarise": ({"transitive"}, {"np"}, {"communication"}),
    "emphasise": ({"transitive"}, {"np", "clause"}, {"communication"}),
    "recognise": ({"transitive", "clausal"}, {"np", "clause"}, {"cognition"}),
    "realise": ({"transitive", "clausal"}, {"np", "clause"}, {"cognition"}),
    "organise": ({"transitive"}, {"np"}, {"action"}),
    "criticise": ({"transitive"}, {"np"}, {"communication"}),
    "generalise": ({"intransitive", "transitive"}, {"np", "pp"}, {"reasoning"}),
    "characterise": ({"transitive"}, {"np", "pp"}, {"description"}),
    "justify": ({"transitive", "clausal"}, {"np", "clause"}, {"reasoning"}),
    "validate": ({"transitive"}, {"np"}, {"evaluation"}),
    "parse": ({"transitive"}, {"np"}, {"analysis"}),
    "tokenise": ({"transitive"}, {"np"}, {"analysis"}),
    "inflect": ({"transitive", "intransitive"}, {"np"}, {"language"}),
    "conjugate": ({"transitive"}, {"np"}, {"language"}),
    "decline": ({"transitive", "intransitive"}, {"np", "clause"}, {"language"}),
}

_CORE_ADJECTIVES = {
    "good": ("evaluation", "bad"), "bad": ("evaluation", "good"),
    "big": ("size", "small"), "small": ("size", "big"),
    "large": ("size", "small"), "little": ("size", "big"),
    "long": ("length", "short"), "short": ("length", "long"),
    "old": ("age", "new"), "new": ("age", "old"),
    "young": ("age", "old"), "high": ("height", "low"),
    "low": ("height", "high"), "hot": ("temperature", "cold"),
    "cold": ("temperature", "hot"), "warm": ("temperature", "cool"),
    "cool": ("temperature", "warm"), "fast": ("speed", "slow"),
    "slow": ("speed", "fast"), "easy": ("difficulty", "difficult"),
    "hard": ("difficulty", "easy"), "difficult": ("difficulty", "easy"),
    "simple": ("complexity", "complex"), "complex": ("complexity", "simple"),
    "important": ("importance", ""), "useful": ("utility", "useless"),
    "possible": ("possibility", "impossible"), "impossible": ("possibility", "possible"),
    "necessary": ("necessity", ""), "true": ("truth", "false"),
    "false": ("truth", "true"), "correct": ("correctness", "incorrect"),
    "incorrect": ("correctness", "correct"), "grammatical": ("grammar", "ungrammatical"),
    "ungrammatical": ("grammar", "grammatical"), "valid": ("validity", "invalid"),
    "invalid": ("validity", "valid"), "British": ("variety", ""),
    "English": ("language", ""), "clear": ("clarity", "unclear"),
    "unclear": ("clarity", "clear"), "certain": ("certainty", "uncertain"),
    "uncertain": ("certainty", "certain"), "happy": ("emotion", "sad"),
    "sad": ("emotion", "happy"), "strong": ("strength", "weak"),
    "weak": ("strength", "strong"), "rich": ("wealth", "poor"),
    "poor": ("wealth", "rich"), "beautiful": ("beauty", "ugly"),
    "ugly": ("beauty", "beautiful"), "interesting": ("interest", "boring"),
    "boring": ("interest", "interesting"), "common": ("frequency", "rare"),
    "rare": ("frequency", "common"), "similar": ("similarity", "different"),
    "different": ("similarity", "similar"), "same": ("similarity", "different"),
    "whole": ("completeness", ""), "full": ("quantity", "empty"),
    "empty": ("quantity", "full"), "open": ("state", "closed"),
    "closed": ("state", "open"), "free": ("freedom", ""),
    "available": ("availability", "unavailable"), "ready": ("readiness", ""),
    "able": ("ability", "unable"), "unable": ("ability", "able"),
    "aware": ("cognition", "unaware"), "sure": ("certainty", "unsure"),
    "likely": ("probability", "unlikely"), "unlikely": ("probability", "likely"),
    "active": ("voice", "passive"), "passive": ("voice", "active"),
    "declarative": ("clause_type", ""), "interrogative": ("clause_type", ""),
    "imperative": ("clause_type", ""), "exclamative": ("clause_type", ""),
    "finite": ("finiteness", "non-finite"), "singular": ("number", "plural"),
    "plural": ("number", "singular"), "positive": ("polarity", "negative"),
    "negative": ("polarity", "positive"),
}

_CORE_ADVERBS = {
    "not": "negation", "never": "negation", "always": "frequency",
    "often": "frequency", "sometimes": "frequency", "usually": "frequency",
    "rarely": "frequency", "already": "time", "still": "time", "just": "time",
    "soon": "time", "now": "time", "then": "time", "here": "place",
    "there": "place", "very": "degree", "quite": "degree", "rather": "degree",
    "too": "degree", "also": "addition", "only": "focus", "even": "focus",
    "well": "manner", "badly": "manner", "quickly": "manner", "slowly": "manner",
    "carefully": "manner", "clearly": "manner", "probably": "probability",
    "possibly": "probability", "certainly": "certainty", "perhaps": "probability",
    "almost": "degree", "nearly": "degree", "hardly": "degree",
    "together": "manner", "again": "frequency", "once": "frequency",
    "twice": "frequency", "yesterday": "time", "today": "time",
    "tomorrow": "time", "therefore": "reasoning", "however": "contrast",
    "indeed": "emphasis", "away": "place", "back": "place", "home": "place",
    "outside": "place", "inside": "place", "upstairs": "place",
    "downstairs": "place", "abroad": "place", "everywhere": "place",
    "somewhere": "place", "nowhere": "place",
}

_CORE_PROPER = {
    "Britain": "place", "England": "place", "London": "place",
    "Europe": "place", "English": "language", "British": "variety",
    "Monday": "time", "Tuesday": "time", "Wednesday": "time",
    "Thursday": "time", "Friday": "time", "Saturday": "time",
    "Sunday": "time", "January": "time", "February": "time",
    "March": "time", "April": "time",
}


def _entry(
    lemma: str,
    pos: str,
    *,
    forms: dict[str, str] | None = None,
    features: dict[str, Any] | None = None,
    valency: list[str] | None = None,
    complements: list[str] | None = None,
    semantic_class: list[str] | None = None,
    antonyms: list[str] | None = None,
    source: str = "british-words.txt:rules",
    confidence: float = 0.7,
    status: str = "heuristic",
) -> LexicalEntry:
    return LexicalEntry(
        lemma=lemma,
        pos=pos,
        forms=dict(forms or {}),
        features=dict(features or {}),
        valency=list(valency or []),
        complements=list(complements or []),
        semantic_class=list(semantic_class or []),
        antonyms=list(antonyms or []),
        source=source,
        confidence=confidence,
        status=status,
    )


class Lexicon:
    """Surface inventory plus rule-derived grammatical properties."""

    def __init__(self, path: str | Path = DEFAULT_WORDS) -> None:
        self.path = Path(path)
        self.inventory: set[str] = set()
        self.entries: list[LexicalEntry] = []
        self._by_lemma_pos: dict[tuple[str, str], LexicalEntry] = {}
        self._surface_index: dict[str, list[LexicalMatch]] = {}
        self._heuristic_cache: dict[str, list[LexicalEntry]] = {}
        self._unknown_cache: dict[str, list[LexicalEntry]] = {}
        self.issues: list[str] = []
        self.metadata = {
            "source": str(self.path.name),
            "kind": "surface-form inventory with rule-derived grammar",
            "limitations": "No part-of-speech labels are present in the source file.",
        }
        self.load()

    # -- loading ---------------------------------------------------------
    def load(self) -> None:
        if not self.path.exists():
            raise LexiconError(f"word inventory not found: {self.path}")
        with self.path.open(encoding="utf-8", errors="replace") as handle:
            for number, line in enumerate(handle, 1):
                word = line.strip()
                if not word or " " in word:
                    continue
                self.inventory.add(word.lower())
        if not self.inventory:
            raise LexiconError(f"word inventory is empty: {self.path}")
        self._load_closed_class()
        self._load_core_content()

    def _add(self, entry: LexicalEntry, *, surface_forms: dict[str, str] | None = None) -> None:
        self._complete_forms(entry)
        key = (entry.lemma.lower(), entry.pos)
        if key in self._by_lemma_pos:
            # Merge features rather than discarding the later entry.
            existing = self._by_lemma_pos[key]
            existing.features.update(entry.features)
            existing.forms.update(entry.forms)
            return
        self.entries.append(entry)
        self._by_lemma_pos[key] = entry
        forms = surface_forms or entry.forms
        for form_key, surface in forms.items():
            if not surface:
                continue
            if not self._recognised(surface):
                continue
            match = LexicalMatch(
                entry=entry,
                surface=surface,
                form=form_key,
                confidence=entry.confidence,
                provenance=entry.source,
            )
            self._surface_index.setdefault(surface.lower(), []).append(match)
            british = morphology.to_british(surface)
            if british.lower() != surface.lower() and self._recognised(british):
                self._surface_index.setdefault(british.lower(), []).append(match)

    def _recognised(self, surface: str) -> bool:
        return surface.lower() in self.inventory

    def _complete_forms(self, entry: LexicalEntry) -> None:
        lemma, pos, forms = entry.lemma, entry.pos, entry.forms
        if pos == "noun":
            forms.setdefault("singular", lemma)
            if entry.features.get("countability") == "uncountable":
                forms.setdefault("plural", lemma)
            else:
                forms.setdefault("plural", morphology.pluralise(lemma))
            forms.setdefault("possessive", morphology.possessive(lemma))
            forms.setdefault("plural_possessive", morphology.possessive(forms["plural"]))
        elif pos in {"verb", "auxiliary"}:
            forms.setdefault("base", lemma)
            if lemma.lower() == "be":
                forms.update({"first": "am", "second": "are", "third": "is",
                              "plural": "are", "past_singular": "was",
                              "past_plural": "were", "past": "was",
                              "participle": "been", "gerund": "being"})
            elif lemma.lower() == "have":
                forms.update({"third": "has", "past": "had", "participle": "had", "gerund": "having"})
            elif lemma.lower() == "do":
                forms.update({"third": "does", "past": "did", "participle": "done", "gerund": "doing"})
            else:
                forms.setdefault("third", morphology.third_person(lemma))
                forms.setdefault("past", morphology.past_tense(lemma))
                forms.setdefault("participle", morphology.past_participle(lemma))
                forms.setdefault("gerund", morphology.present_participle(lemma))
        elif pos == "modal":
            forms.setdefault("base", lemma)
            forms.setdefault("third", lemma)
        elif pos == "adjective":
            forms.setdefault("positive", lemma)
            if entry.features.get("gradability", "gradable") == "gradable":
                forms.setdefault("comparative", morphology.comparative(lemma))
                forms.setdefault("superlative", morphology.superlative(lemma))
                forms.setdefault("adverb", morphology.adverb_from_adjective(lemma))
        elif pos == "adverb":
            forms.setdefault("positive", lemma)
            forms.setdefault("comparative", morphology.comparative(lemma))
            forms.setdefault("superlative", morphology.superlative(lemma))
        elif pos == "proper_noun":
            forms.setdefault("singular", lemma)
            forms.setdefault("plural", morphology.pluralise(lemma))
            forms.setdefault("possessive", morphology.possessive(lemma))
        else:
            forms.setdefault("base", lemma)

    def _load_closed_class(self) -> None:
        for surface, features in _DET.items():
            self._add(_entry(surface, "determiner", features=features,
                             semantic_class=["function_word"], confidence=1.0,
                             status="verified_grammar"), surface_forms={"base": surface})
        seen_pronouns: set[tuple[str, str]] = set()
        for lemma, features in _PRONOUNS.items():
            forms = _PRONOUN_FORMS.get(lemma, {"nominative": lemma})
            for form_key, surface in forms.items():
                if (surface.lower(), lemma.lower()) in seen_pronouns:
                    continue
                seen_pronouns.add((surface.lower(), lemma.lower()))
            self._add(_entry(lemma, "pronoun", forms=forms, features=features,
                             semantic_class=["function_word", "reference"], confidence=1.0,
                             status="verified_grammar"))
        for lemma, features in _AUX.items():
            self._add(_entry(lemma, "auxiliary", features=features,
                             valency=["copular"] if lemma == "be" else ["transitive"],
                             complements=["np", "adj", "pp", "adv"] if lemma == "be" else ["np"],
                             semantic_class=["function_word", "auxiliary"],
                             confidence=1.0, status="verified_grammar"))
            # Auxiliaries also behave as lexical verbs in some constructions.
            self._add(_entry(lemma, "verb", features=dict(features, lexical_auxiliary=True),
                             valency=["copular"] if lemma == "be" else ["transitive", "intransitive"],
                             complements=["np", "adj", "pp", "adv"] if lemma == "be" else ["np"],
                             semantic_class=["state" if lemma == "be" else "action"],
                             confidence=1.0, status="verified_grammar"))
        for lemma, features in _MODALS.items():
            self._add(_entry(lemma, "modal", features=features,
                             semantic_class=["function_word", "modality"],
                             confidence=1.0, status="verified_grammar"))
        for lemma in _PREPOSITIONS:
            self._add(_entry(lemma, "preposition", features={"relation": "grammatical"},
                             semantic_class=["function_word", "relation"],
                             confidence=1.0, status="verified_grammar"))
        for lemma, kind in _CONJUNCTIONS.items():
            self._add(_entry(lemma, "conjunction",
                             features={"conjunction_type": kind},
                             semantic_class=["function_word", "connective"],
                             confidence=1.0, status="verified_grammar"))
        for lemma in ("not", "never"):
            self._add(_entry(lemma, "adverb", features={"negation": True},
                             semantic_class=["function_word", "negation"],
                             confidence=1.0, status="verified_grammar"))
        for lemma, value in _NUMBERS.items():
            self._add(_entry(lemma, "number", features={"value": value},
                             semantic_class=["number"], confidence=1.0,
                             status="verified_grammar"))
        for lemma in _INTERJECTIONS:
            self._add(_entry(lemma, "interjection", semantic_class=["discourse"],
                             confidence=1.0, status="verified_grammar"))
        for lemma, gloss in {
            "where": "in or to what place", "when": "at what time",
            "why": "for what reason", "how": "in what way or to what degree",
            "there": "in or to that place",
        }.items():
            self._add(_entry(lemma, "adverb", features={"wh": lemma != "there"},
                             semantic_class=["question"], confidence=0.95,
                             status="editorial"))
        for lemma in ("what", "whose"):
            self._add(_entry(lemma, "pronoun",
                             forms={"nominative": lemma, "accusative": lemma,
                                    "possessive_det": "whose", "possessive_pron": "whose",
                                    "reflexive": lemma},
                             features={"wh": True, "person": 3, "number": "singular"},
                             semantic_class=["question", "reference"],
                             confidence=0.95, status="editorial"))

    def _load_core_content(self) -> None:
        for lemma, (semcls, countability) in _CORE_NOUNS.items():
            self._add(_entry(lemma, "noun", features={"countability": countability},
                             semantic_class=[semcls], confidence=0.8, status="editorial"))
        for lemma, (valency, complements, classes) in _CORE_VERBS.items():
            self._add(_entry(lemma, "verb", valency=sorted(valency),
                             complements=sorted(complements),
                             semantic_class=sorted(classes), confidence=0.85,
                             status="editorial"))
        for lemma, (semcls, antonym) in _CORE_ADJECTIVES.items():
            self._add(_entry(lemma, "adjective",
                             features={"gradability": "gradable"},
                             semantic_class=[semcls],
                             antonyms=[antonym] if antonym else [],
                             confidence=0.8, status="editorial"))
        for lemma, semcls in _CORE_ADVERBS.items():
            self._add(_entry(lemma, "adverb", semantic_class=[semcls],
                             confidence=0.8, status="editorial"))
        for lemma, semcls in _CORE_PROPER.items():
            self._add(_entry(lemma, "proper_noun", features={"proper": True},
                             semantic_class=[semcls], confidence=0.85,
                             status="editorial"))

    # -- lookup ----------------------------------------------------------
    def matches(self, surface: str, *, pos: str | None = None, include_unknown: bool = False) -> list[LexicalMatch]:
        key = surface.lower()
        candidates = list(self._surface_index.get(key, []))
        if not candidates and key in self.inventory:
            candidates = self._heuristic_matches(surface)
        if not candidates:
            british = morphology.to_british(surface).lower()
            if british != key and british in self.inventory:
                candidates = list(self._surface_index.get(british, [])) or self._heuristic_matches(british)
        if pos is not None:
            candidates = [m for m in candidates if m.pos == pos]
        if not candidates and include_unknown:
            for entry in self.guess(surface):
                if pos is not None and entry.pos != pos:
                    continue
                candidates.append(LexicalMatch(entry, surface, "base", entry.confidence,
                                               "unknown-word-handler"))
        return candidates

    def _heuristic_matches(self, surface: str) -> list[LexicalMatch]:
        entries = self._heuristic_entries(surface)
        return [LexicalMatch(e, surface, e.features.get("form", "base"), e.confidence,
                             e.source) for e in entries]

    def _heuristic_entries(self, surface: str) -> list[LexicalEntry]:
        key = surface.lower()
        if key in self._heuristic_cache:
            return self._heuristic_cache[key]
        if key not in self.inventory:
            return self.guess(surface)
        entries: list[LexicalEntry] = []

        def add(pos: str, lemma: str | None = None, form: str = "base",
                features: dict[str, Any] | None = None, confidence: float = 0.45) -> None:
            if pos not in VALID_POS:
                return
            entry = _entry(lemma or key, pos, features=dict(features or {}),
                           source="british-words.txt:heuristic",
                           confidence=confidence, status="heuristic")
            entry.forms[form] = surface
            entry.features["form"] = form
            entries.append(entry)

        capitalised = surface[:1].isupper() and key not in {"i"}
        if capitalised:
            add("proper_noun", surface, "singular", confidence=0.5)
        # Suffix evidence.  These are tendencies, not certainties; the parser
        # keeps alternatives rather than pretending one tag is definitive.
        if key.endswith("ly") and len(key) > 3:
            add("adverb", key, "positive", confidence=0.55)
            add("adjective", key, "positive", confidence=0.3)
        if key.endswith("ing") and len(key) > 4:
            lemma = key[:-3]
            add("verb", lemma, "gerund", {"form": "gerund"}, 0.55)
            add("noun", lemma, "base", {"countability": "countable"}, 0.35)
        if key.endswith("ed") and len(key) > 3:
            lemma = key[:-2] if not key.endswith("eed") else key
            add("verb", lemma, "past", {"form": "past"}, 0.55)
            add("adjective", lemma, "positive", {}, 0.3)
        if key.endswith("s") and not key.endswith(("ss", "us", "is")):
            lemma = morphology.singularise(key)
            add("noun", lemma, "plural", {"countability": "countable", "form": "plural"}, 0.55)
            add("verb", lemma, "third", {"form": "third"}, 0.35)
        if key.endswith("er") and len(key) > 3:
            add("noun", key, "base", {"countability": "countable"}, 0.4)
            add("adjective", key[:-2], "comparative", {"form": "comparative"}, 0.35)
        if key.endswith("est") and len(key) > 4:
            add("adjective", key[:-3], "superlative", {"form": "superlative"}, 0.4)
        if re.search(r"(ous|ful|less|able|ible|ive|al|ic|ish|ary)$", key) and len(key) > 3:
            add("adjective", key, "positive", confidence=0.5)
        if re.search(r"(ise|ize|ify|ate|en)$", key) and len(key) > 3:
            add("verb", key, "base", confidence=0.5)
        if not entries:
            add("noun", key, "singular", {"countability": "countable"}, 0.5)
            add("verb", key, "base", {}, 0.3)
        # Remove duplicate (pos, form) readings.
        seen: set[tuple[str, str]] = set()
        unique: list[LexicalEntry] = []
        for entry in entries:
            marker = (entry.pos, entry.features.get("form", "base"))
            if marker in seen:
                continue
            seen.add(marker)
            unique.append(entry)
        self._heuristic_cache[key] = unique[:4]
        return self._heuristic_cache[key]

    def guess(self, surface: str) -> list[LexicalEntry]:
        key = surface.lower()
        if key in self._unknown_cache:
            return self._unknown_cache[key]
        entries: list[LexicalEntry] = []

        def add(pos: str, confidence: float) -> None:
            entry = _entry(key, pos, features={"unknown": True},
                           source="unknown-word-handler", confidence=confidence,
                           status="unverified")
            entries.append(entry)

        if surface[:1].isupper() and key != "i":
            add("proper_noun", 0.2)
        else:
            add("noun", 0.2)
        if re.search(r"(ise|ize|ify|ate|en)$", key):
            add("verb", 0.18)
        if re.search(r"(ous|ful|less|able|ible|ive|al|ic|ish|ary|y)$", key) and len(key) > 3:
            add("adjective", 0.15)
        if key.endswith("ly"):
            add("adverb", 0.18)
        if re.search(r"(ing|ed)$", key):
            add("verb", 0.15)
        self._unknown_cache[key] = entries[:3]
        return self._unknown_cache[key]

    def lookup_lemma(self, lemma: str, pos: str | None = None) -> LexicalEntry | None:
        key = lemma.lower()
        if pos is not None:
            return self._by_lemma_pos.get((key, pos))
        for (lemma_key, _), entry in self._by_lemma_pos.items():
            if lemma_key == key:
                return entry
        if key in self.inventory:
            entries = self._heuristic_entries(lemma)
            return entries[0] if entries else None
        return None

    def entries_for_lemma(self, lemma: str) -> list[LexicalEntry]:
        key = lemma.lower()
        result = [e for e in self.entries if e.lemma.lower() == key]
        if not result and key in self.inventory:
            result = list(self._heuristic_entries(lemma))
        return result

    def by_pos(self, pos: str) -> list[LexicalEntry]:
        return [e for e in self.entries if e.pos == pos]

    def is_known_surface(self, surface: str) -> bool:
        key = surface.lower()
        return key in self.inventory or morphology.to_british(surface).lower() in self.inventory

    def is_known_inventory(self, surface: str) -> bool:
        return surface.lower() in self.inventory

    def semantic_classes(self, lemma: str) -> set[str]:
        classes: set[str] = set()
        for entry in self.entries_for_lemma(lemma):
            classes.update(entry.semantic_class)
        return classes

    def add_entry(self, data: dict[str, Any] | LexicalEntry) -> LexicalEntry:
        """Add an entry to the running lexicon (memory only)."""
        if isinstance(data, LexicalEntry):
            entry = data
        else:
            if "lemma" not in data or "pos" not in data:
                raise LexiconError("entry needs at least lemma and pos")
            if data["pos"] not in VALID_POS:
                raise LexiconError(f"unknown part of speech: {data['pos']}")
            entry = _entry(str(data["lemma"]), str(data["pos"]),
                           forms=data.get("forms"),
                           features=data.get("features"),
                           valency=data.get("valency"),
                           complements=data.get("complements"),
                           semantic_class=data.get("semantic_class"),
                           antonyms=data.get("antonyms"),
                           confidence=float(data.get("confidence", 0.6)),
                           status=str(data.get("status", "editorial")))
        self._add(entry)
        return entry

    def validate(self) -> list[str]:
        return list(self.issues)

    def describe(self, lemma: str) -> list[LexicalEntry]:
        return self.entries_for_lemma(lemma)

    def __len__(self) -> int:
        return len(self.entries)

    def __iter__(self) -> Iterator[LexicalEntry]:
        return iter(self.entries)
