"""Tokenisation and light written-form analysis.

Tokenisation is not understanding.  This module only separates words,
punctuation, contractions, possessives and quoted material so later stages can
analyse them.
"""

from __future__ import annotations

import re
from dataclasses import dataclass


@dataclass(frozen=True)
class Token:
    text: str
    kind: str  # word, number, punctuation, quote
    start: int
    end: int
    normalized: str
    contraction: bool = False
    possessive: bool = False

    def __str__(self) -> str:
        return self.text


TOKEN_RE = re.compile(
    r"[A-Za-zÀ-ÖØ-öø-ÿ]+(?:[’'\-][A-Za-zÀ-ÖØ-öø-ÿ]+)*"
    r"|\d+(?:[.,]\d+)*"
    r"|[^\s]",
    re.UNICODE,
)

WORD_RE = re.compile(r"^[A-Za-zÀ-ÖØ-öø-ÿ]", re.UNICODE)

QUOTE_CHARS = {'"', "'", "“", "”", "‘", "’", "«", "»"}
OPEN_QUOTES = {'"', "“", "‘", "«"}
CLOSE_QUOTES = {'"', "”", "’", "»"}

# Contractions are expanded into their grammatical parts.  This is a finite
# lexical list of conventional written contractions, not a prompt-response
# mapping.
CONTRACTIONS: dict[str, tuple[str, ...]] = {
    "i'm": ("I", "am"),
    "i've": ("I", "have"),
    "i'll": ("I", "will"),
    "i'd": ("I", "would"),
    "you're": ("you", "are"),
    "you've": ("you", "have"),
    "you'll": ("you", "will"),
    "you'd": ("you", "would"),
    "he's": ("he", "is"),
    "she's": ("she", "is"),
    "it's": ("it", "is"),
    "that's": ("that", "is"),
    "what's": ("what", "is"),
    "who's": ("who", "is"),
    "where's": ("where", "is"),
    "when's": ("when", "is"),
    "why's": ("why", "is"),
    "how's": ("how", "is"),
    "there's": ("there", "is"),
    "here's": ("here", "is"),
    "let's": ("let", "us"),
    "we're": ("we", "are"),
    "we've": ("we", "have"),
    "we'll": ("we", "will"),
    "we'd": ("we", "would"),
    "they're": ("they", "are"),
    "they've": ("they", "have"),
    "they'll": ("they", "will"),
    "they'd": ("they", "would"),
    "isn't": ("is", "not"),
    "aren't": ("are", "not"),
    "wasn't": ("was", "not"),
    "weren't": ("were", "not"),
    "don't": ("do", "not"),
    "doesn't": ("does", "not"),
    "didn't": ("did", "not"),
    "can't": ("can", "not"),
    "cannot": ("can", "not"),
    "couldn't": ("could", "not"),
    "won't": ("will", "not"),
    "wouldn't": ("would", "not"),
    "shan't": ("shall", "not"),
    "shouldn't": ("should", "not"),
    "mustn't": ("must", "not"),
    "needn't": ("need", "not"),
    "haven't": ("have", "not"),
    "hasn't": ("has", "not"),
    "hadn't": ("had", "not"),
    "ain't": ("be", "not"),
}

NEGATED_WORDS = {"not", "never", "nobody", "nothing", "none", "neither", "nor"}


def normalise_text(text: str) -> str:
    """Normalise curly quotation marks and spacing without changing wording."""
    return (
        text.replace("’", "'")
        .replace("‘", "'")
        .replace("“", '"')
        .replace("”", '"')
        .replace("\u00a0", " ")
    )


def tokenise(text: str) -> list[Token]:
    """Split *text* into tokens, expanding contractions and possessives."""
    text = normalise_text(text)
    tokens: list[Token] = []
    for match in TOKEN_RE.finditer(text):
        raw = match.group(0)
        start, end = match.start(), match.end()
        if raw[0].isdigit():
            tokens.append(Token(raw, "number", start, end, raw))
            continue
        if not WORD_RE.match(raw):
            kind = "quote" if raw in QUOTE_CHARS else "punctuation"
            tokens.append(Token(raw, kind, start, end, raw))
            continue
        lower = raw.lower()
        if lower in CONTRACTIONS:
            pieces = CONTRACTIONS[lower]
            offset = start
            for piece in pieces:
                tokens.append(
                    Token(piece, "word", offset, offset + len(piece), piece.lower(), contraction=True)
                )
                offset += len(piece)
            continue
        # Possessive 's is separated so that noun phrases can be parsed
        # compositionally.  Pronoun contractions were handled above.
        if len(raw) > 2 and (lower.endswith("'s") or lower.endswith("s'")):
            base = raw[:-2] if lower.endswith("'s") else raw[:-1]
            if base:
                tokens.append(Token(base, "word", start, start + len(base), base.lower()))
                poss_text = "'s" if lower.endswith("'s") else "'"
                tokens.append(
                    Token(
                        poss_text,
                        "punctuation",
                        start + len(base),
                        end,
                        poss_text,
                        possessive=True,
                    )
                )
                continue
        tokens.append(Token(raw, "word", start, end, lower))
    return tokens


def split_sentences(text: str) -> list[str]:
    """Split written text at sentence boundaries.

    A boundary is a terminal mark followed by whitespace or the end of the
    text, and not an obvious abbreviation or a decimal point.  The split is a
    written-form heuristic; syntactic analysis remains the authority.
    """
    text = normalise_text(text).strip()
    if not text:
        return []
    abbreviations = {
        "mr.", "mrs.", "ms.", "dr.", "prof.", "st.", "e.g.", "i.e.", "etc.", "vs.", "no.",
    }
    sentences: list[str] = []
    start = 0
    i = 0
    while i < len(text):
        ch = text[i]
        if ch in ".?!":
            j = i + 1
            while j < len(text) and text[j] in "\"'”’)]":
                j += 1
            if j >= len(text) or text[j].isspace():
                candidate = text[start : i + 1]
                previous = re.search(r"([A-Za-z.]+)$", candidate)
                word = previous.group(1).lower() if previous else ""
                if not (ch == "." and (word in abbreviations or len(word) == 1)):
                    sentences.append(candidate.strip())
                    start = j
                    i = j
                    continue
        i += 1
    tail = text[start:].strip()
    if tail:
        sentences.append(tail)
    return sentences


def words(tokens: list[Token]) -> list[str]:
    return [t.text for t in tokens if t.kind in {"word", "number"}]


def lower_words(tokens: list[Token]) -> list[str]:
    return [t.normalized for t in tokens if t.kind in {"word", "number"}]


def strip_terminal_punctuation(text: str) -> str:
    return re.sub(r"[.!?]+[\"'”’)]*$", "", text.strip()).strip()


def extract_quoted(text: str) -> list[str]:
    """Return quoted spans, preserving their contents but not the quotes."""
    text = normalise_text(text)
    spans: list[str] = []
    for open_q, close_q in (('"', '"'), ("'", "'")):
        pattern = re.compile(re.escape(open_q) + r"(.+?)" + re.escape(close_q), re.DOTALL)
        for match in pattern.finditer(text):
            value = match.group(1).strip()
            if value and value not in spans:
                spans.append(value)
    return spans


def sentence_after_marker(text: str, markers: tuple[str, ...]) -> str | None:
    """Extract the material after a marker such as ``sentence:``."""
    lower = normalise_text(text)
    for marker in markers:
        match = re.search(re.escape(marker) + r"\s*(.+)$", lower, re.IGNORECASE | re.DOTALL)
        if match:
            return match.group(1).strip()
    return None


def classify_punctuation(token: Token) -> str:
    if token.possessive:
        return "POSS"
    return {
        ",": "COMMA",
        ";": "SEMICOLON",
        ":": "COLON",
        ".": "PERIOD",
        "!": "BANG",
        "?": "QUESTION",
        "-": "DASH",
        "—": "DASH",
        "(": "LPAREN",
        ")": "RPAREN",
        '"': "QUOTE",
        "'": "QUOTE",
    }.get(token.text, "PUNCT")
