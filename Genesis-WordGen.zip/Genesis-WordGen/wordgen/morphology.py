"""Rule-based English morphology with explicit irregular exceptions.

The module never applies a spelling rule blindly.  Each public function either
returns a defensible form or raises :class:`MorphologyError`.  Irregular forms
are stored in explicit tables because they are lexical facts, not productive
rules.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Iterable


class MorphologyError(ValueError):
    """Raised when a form cannot be produced under the stated conditions."""


# ---------------------------------------------------------------------------
# Irregular lexical facts
# ---------------------------------------------------------------------------

IRREGULAR_PLURALS: dict[str, str] = {
    "person": "people",
    "man": "men",
    "woman": "women",
    "child": "children",
    "foot": "feet",
    "tooth": "teeth",
    "goose": "geese",
    "mouse": "mice",
    "louse": "lice",
    "ox": "oxen",
    "die": "dice",
    "criterion": "criteria",
    "phenomenon": "phenomena",
    "analysis": "analyses",
    "basis": "bases",
    "crisis": "crises",
    "thesis": "theses",
    "hypothesis": "hypotheses",
    "diagnosis": "diagnoses",
    "synopsis": "synopses",
    "datum": "data",
    "medium": "media",
    "memorandum": "memoranda",
    "curriculum": "curricula",
    "cactus": "cacti",
    "fungus": "fungi",
    "nucleus": "nuclei",
    "radius": "radii",
    "stimulus": "stimuli",
    "syllabus": "syllabi",
    "alumnus": "alumni",
    "index": "indices",
    "matrix": "matrices",
    "vertex": "vertices",
    "appendix": "appendices",
    "axis": "axes",
    "sheep": "sheep",
    "deer": "deer",
    "fish": "fish",
    "series": "series",
    "species": "species",
    "aircraft": "aircraft",
    "spacecraft": "spacecraft",
    "means": "means",
    "offspring": "offspring",
    "salmon": "salmon",
    "trout": "trout",
}

# Words ending in -f/-fe that take -ves.  The default for other -f words is -s.
F_TO_VES = {
    "leaf",
    "life",
    "knife",
    "wife",
    "wolf",
    "shelf",
    "half",
    "calf",
    "loaf",
    "thief",
    "scarf",
    "elf",
    "self",
    "sheaf",
    "hoof",
}

# -o words that take -oes.  Other -o words normally take -s.
O_TO_OES = {
    "potato",
    "tomato",
    "hero",
    "echo",
    "veto",
    "torpedo",
    "embargo",
    "mosquito",
    "volcano",
}

# base: (third person, past, past participle, present participle)
IRREGULAR_VERBS: dict[str, tuple[str, str, str, str]] = {
    "be": ("is", "was", "been", "being"),
    "have": ("has", "had", "had", "having"),
    "do": ("does", "did", "done", "doing"),
    "go": ("goes", "went", "gone", "going"),
    "see": ("sees", "saw", "seen", "seeing"),
    "hear": ("hears", "heard", "heard", "hearing"),
    "speak": ("speaks", "spoke", "spoken", "speaking"),
    "say": ("says", "said", "said", "saying"),
    "tell": ("tells", "told", "told", "telling"),
    "think": ("thinks", "thought", "thought", "thinking"),
    "know": ("knows", "knew", "known", "knowing"),
    "understand": ("understands", "understood", "understood", "understanding"),
    "learn": ("learns", "learnt", "learnt", "learning"),
    "teach": ("teaches", "taught", "taught", "teaching"),
    "read": ("reads", "read", "read", "reading"),
    "write": ("writes", "wrote", "written", "writing"),
    "build": ("builds", "built", "built", "building"),
    "break": ("breaks", "broke", "broken", "breaking"),
    "give": ("gives", "gave", "given", "giving"),
    "take": ("takes", "took", "taken", "taking"),
    "get": ("gets", "got", "got", "getting"),
    "put": ("puts", "put", "put", "putting"),
    "bring": ("brings", "brought", "brought", "bringing"),
    "send": ("sends", "sent", "sent", "sending"),
    "buy": ("buys", "bought", "bought", "buying"),
    "sell": ("sells", "sold", "sold", "selling"),
    "eat": ("eats", "ate", "eaten", "eating"),
    "drink": ("drinks", "drank", "drunk", "drinking"),
    "sleep": ("sleeps", "slept", "slept", "sleeping"),
    "wake": ("wakes", "woke", "woken", "waking"),
    "run": ("runs", "ran", "run", "running"),
    "sit": ("sits", "sat", "sat", "sitting"),
    "stand": ("stands", "stood", "stood", "standing"),
    "find": ("finds", "found", "found", "finding"),
    "lose": ("loses", "lost", "lost", "losing"),
    "keep": ("keeps", "kept", "kept", "keeping"),
    "become": ("becomes", "became", "become", "becoming"),
    "feel": ("feels", "felt", "felt", "feeling"),
    "forget": ("forgets", "forgot", "forgotten", "forgetting"),
    "mean": ("means", "meant", "meant", "meaning"),
    "show": ("shows", "showed", "shown", "showing"),
    "prove": ("proves", "proved", "proven", "proving"),
    "begin": ("begins", "began", "begun", "beginning"),
    "meet": ("meets", "met", "met", "meeting"),
    "leave": ("leaves", "left", "left", "leaving"),
    "choose": ("chooses", "chose", "chosen", "choosing"),
    "grow": ("grows", "grew", "grown", "growing"),
    "throw": ("throws", "threw", "thrown", "throwing"),
    "catch": ("catches", "caught", "caught", "catching"),
    "cut": ("cuts", "cut", "cut", "cutting"),
    "sing": ("sings", "sang", "sung", "singing"),
    "draw": ("draws", "drew", "drawn", "drawing"),
    "come": ("comes", "came", "come", "coming"),
    "fly": ("flies", "flew", "flown", "flying"),
    "drive": ("drives", "drove", "driven", "driving"),
    "ride": ("rides", "rode", "ridden", "riding"),
    "swim": ("swims", "swam", "swum", "swimming"),
    "fall": ("falls", "fell", "fallen", "falling"),
    "rise": ("rises", "rose", "risen", "rising"),
    "wear": ("wears", "wore", "worn", "wearing"),
    "win": ("wins", "won", "won", "winning"),
    "lend": ("lends", "lent", "lent", "lending"),
    "spend": ("spends", "spent", "spent", "spending"),
    "fight": ("fights", "fought", "fought", "fighting"),
    "seek": ("seeks", "sought", "sought", "seeking"),
    "shoot": ("shoots", "shot", "shot", "shooting"),
    "lead": ("leads", "led", "led", "leading"),
    "feed": ("feeds", "fed", "fed", "feeding"),
    "hold": ("holds", "held", "held", "holding"),
    "strike": ("strikes", "struck", "struck", "striking"),
    "shake": ("shakes", "shook", "shaken", "shaking"),
    "bite": ("bites", "bit", "bitten", "biting"),
    "hide": ("hides", "hid", "hidden", "hiding"),
    "hit": ("hits", "hit", "hit", "hitting"),
    "let": ("lets", "let", "let", "letting"),
    "set": ("sets", "set", "set", "setting"),
    "cost": ("costs", "cost", "cost", "costing"),
    "hurt": ("hurts", "hurt", "hurt", "hurting"),
    "quit": ("quits", "quit", "quit", "quitting"),
    "shut": ("shuts", "shut", "shut", "shutting"),
    "split": ("splits", "split", "split", "splitting"),
    "spread": ("spreads", "spread", "spread", "spreading"),
    "burst": ("bursts", "burst", "burst", "bursting"),
}

IRREGULAR_ADJECTIVES: dict[str, tuple[str, str]] = {
    "good": ("better", "best"),
    "bad": ("worse", "worst"),
    "far": ("further", "furthest"),
    "little": ("less", "least"),
    "many": ("more", "most"),
    "much": ("more", "most"),
    "old": ("older", "oldest"),
    "well": ("better", "best"),
}

IRREGULAR_ADVERBS: dict[str, tuple[str, str]] = {
    "well": ("better", "best"),
    "badly": ("worse", "worst"),
    "far": ("further", "furthest"),
    "little": ("less", "least"),
    "much": ("more", "most"),
}

# Spelling correspondences used when British spelling is requested.  These are
# conventional correspondences, not a claim that every occurrence is a simple
# mechanical substitution in every context.
AMERICAN_TO_BRITISH: dict[str, str] = {
    "color": "colour",
    "colors": "colours",
    "colored": "coloured",
    "coloring": "colouring",
    "favor": "favour",
    "favors": "favours",
    "favored": "favoured",
    "favorite": "favourite",
    "favorites": "favourites",
    "honor": "honour",
    "honors": "honours",
    "honored": "honoured",
    "labor": "labour",
    "labors": "labours",
    "neighbor": "neighbour",
    "neighbors": "neighbours",
    "behavior": "behaviour",
    "behaviors": "behaviours",
    "harbor": "harbour",
    "rumor": "rumour",
    "humor": "humour",
    "vapor": "vapour",
    "center": "centre",
    "centers": "centres",
    "centered": "centred",
    "theater": "theatre",
    "theaters": "theatres",
    "meter": "metre",
    "meters": "metres",
    "liter": "litre",
    "liters": "litres",
    "defense": "defence",
    "offense": "offence",
    "license": "licence",
    "practice": "practice",
    "traveler": "traveller",
    "travelers": "travellers",
    "traveling": "travelling",
    "traveled": "travelled",
    "canceled": "cancelled",
    "canceling": "cancelling",
    "modeling": "modelling",
    "modeled": "modelled",
    "labeled": "labelled",
    "labeling": "labelling",
    "signaling": "signalling",
    "signaled": "signalled",
    "organize": "organise",
    "organized": "organised",
    "organizing": "organising",
    "organization": "organisation",
    "realize": "realise",
    "realized": "realised",
    "realizing": "realising",
    "recognize": "recognise",
    "recognized": "recognised",
    "recognizing": "recognising",
    "analyze": "analyse",
    "analyzed": "analysed",
    "analyzing": "analysing",
    "criticize": "criticise",
    "criticized": "criticised",
    "criticizing": "criticising",
    "summarize": "summarise",
    "summarized": "summarised",
    "summarizing": "summarising",
    "emphasize": "emphasise",
    "emphasized": "emphasised",
    "emphasizing": "emphasising",
    "generalize": "generalise",
    "generalized": "generalised",
    "generalizing": "generalising",
    "characterize": "characterise",
    "characterized": "characterised",
    "program": "programme",
    "programs": "programmes",
    "catalog": "catalogue",
    "catalogs": "catalogues",
    "dialog": "dialogue",
    "dialogs": "dialogues",
    "gray": "grey",
    "plow": "plough",
    "skeptic": "sceptic",
    "skeptical": "sceptical",
    "jewelry": "jewellery",
    "aluminum": "aluminium",
    "toward": "towards",
    "learned": "learnt",
    "spelled": "spelt",
    "burned": "burnt",
    "dreamed": "dreamt",
    "leaned": "leant",
    "dreamed": "dreamt",
    "smelled": "smelt",
    "spoiled": "spoilt",
    "traveled": "travelled",
}

VOWELS = "aeiou"


def _is_vowel(ch: str) -> bool:
    return ch.lower() in VOWELS


def _cvc(word: str) -> bool:
    """Return True for a word ending consonant-vowel-consonant (one syllable).

    The doubling rule is deliberately conservative: it applies to short words
    such as *stop*, *plan* and *run*, not to polysyllabic words whose stress is
    unknown.  Lexical entries can override the result with an explicit form.
    """
    if len(word) < 3:
        return False
    a, b, c = word[-3].lower(), word[-2].lower(), word[-1].lower()
    if a in VOWELS or b not in VOWELS or c in VOWELS:
        return False
    if c in "wxy":
        return False
    return True


def _syllable_count(word: str) -> int:
    groups = re.findall(r"[aeiouy]+", word.lower())
    count = len(groups)
    if word.lower().endswith("e") and count > 1:
        count -= 1
    return max(1, count)


def pluralise(noun: str, *, number: str = "plural") -> str:
    """Return the plural of *noun*.

    ``number='singular'`` is accepted for convenience and returns the word
    unchanged.  Uncountable nouns are not silently pluralised by callers; this
    function only applies the morphological rule.
    """
    if number == "singular":
        return noun
    lower = noun.lower()
    if lower in IRREGULAR_PLURALS:
        return _match_case(noun, IRREGULAR_PLURALS[lower])
    if lower.endswith("s") and not lower.endswith(("ss", "us", "is")):
        # Some words already look plural (news, series handled above); leave
        # them unchanged rather than producing an odd double plural.
        if lower in {"news", "means"}:
            return noun
    if re.search(r"(s|x|z|ch|sh)$", lower):
        return noun + "es"
    if lower.endswith("y") and len(lower) > 1 and not _is_vowel(lower[-2]):
        return noun[:-1] + "ies"
    if lower.endswith(("f", "fe")):
        if lower in F_TO_VES:
            if lower.endswith("fe"):
                return noun[:-2] + "ves"
            return noun[:-1] + "ves"
    if lower.endswith("o") and lower in O_TO_OES:
        return noun + "es"
    return noun + "s"


def singularise(noun: str) -> str:
    """Return a best-effort singular form, used for lexical lookup."""
    lower = noun.lower()
    for singular, plural in IRREGULAR_PLURALS.items():
        if lower == plural.lower():
            return _match_case(noun, singular)
    if lower.endswith("ies") and len(lower) > 3:
        return noun[:-3] + "y"
    if lower.endswith("ves"):
        for singular in F_TO_VES:
            if pluralise(singular).lower() == lower:
                return _match_case(noun, singular)
        return noun[:-3] + "f"
    if lower.endswith("oes") and lower[:-2] in O_TO_OES:
        return noun[:-2]
    if lower.endswith("es") and re.search(r"(s|x|z|ch|sh)es$", lower):
        return noun[:-2]
    if lower.endswith("s") and not lower.endswith("ss"):
        return noun[:-1]
    return noun


def third_person(verb: str) -> str:
    lower = verb.lower()
    if lower in IRREGULAR_VERBS:
        return _match_case(verb, IRREGULAR_VERBS[lower][0])
    if lower.endswith(("s", "x", "z", "ch", "sh", "o")):
        return verb + "es"
    if lower.endswith("y") and len(lower) > 1 and not _is_vowel(lower[-2]):
        return verb[:-1] + "ies"
    return verb + "s"


def past_tense(verb: str) -> str:
    lower = verb.lower()
    if lower in IRREGULAR_VERBS:
        return _match_case(verb, IRREGULAR_VERBS[lower][1])
    return _regular_ed(verb)


def past_participle(verb: str) -> str:
    lower = verb.lower()
    if lower in IRREGULAR_VERBS:
        return _match_case(verb, IRREGULAR_VERBS[lower][2])
    return _regular_ed(verb)


def present_participle(verb: str) -> str:
    lower = verb.lower()
    if lower in IRREGULAR_VERBS:
        return _match_case(verb, IRREGULAR_VERBS[lower][3])
    if lower.endswith("ie"):
        return verb[:-2] + "ying"
    if lower.endswith("e") and not lower.endswith(("ee", "ye", "oe")):
        return verb[:-1] + "ing"
    if _cvc(verb) and _syllable_count(verb) == 1:
        return verb + verb[-1] + "ing"
    return verb + "ing"


def _regular_ed(verb: str) -> str:
    lower = verb.lower()
    if lower.endswith("e"):
        return verb + "d"
    if lower.endswith("y") and len(lower) > 1 and not _is_vowel(lower[-2]):
        return verb[:-1] + "ied"
    if _cvc(verb) and _syllable_count(verb) == 1:
        return verb + verb[-1] + "ed"
    return verb + "ed"


def comparative(adjective: str) -> str:
    lower = adjective.lower()
    if lower in IRREGULAR_ADJECTIVES:
        return _match_case(adjective, IRREGULAR_ADJECTIVES[lower][0])
    if lower.endswith("y") and len(lower) > 1 and not _is_vowel(lower[-2]):
        return adjective[:-1] + "ier"
    if lower.endswith("e"):
        return adjective + "r"
    if _cvc(adjective) and _syllable_count(adjective) == 1:
        return adjective + adjective[-1] + "er"
    return adjective + "er"


def superlative(adjective: str) -> str:
    lower = adjective.lower()
    if lower in IRREGULAR_ADJECTIVES:
        return _match_case(adjective, IRREGULAR_ADJECTIVES[lower][1])
    if lower.endswith("y") and len(lower) > 1 and not _is_vowel(lower[-2]):
        return adjective[:-1] + "iest"
    if lower.endswith("e"):
        return adjective + "st"
    if _cvc(adjective) and _syllable_count(adjective) == 1:
        return adjective + adjective[-1] + "est"
    return adjective + "est"


def adverb_from_adjective(adjective: str) -> str:
    lower = adjective.lower()
    irregular = {
        "good": "well",
        "fast": "fast",
        "hard": "hard",
        "late": "late",
        "early": "early",
        "friendly": "in a friendly way",
        "likely": "probably",
        "public": "publicly",
    }
    if lower in irregular:
        return _match_case(adjective, irregular[lower])
    if lower.endswith("y") and len(lower) > 1 and not _is_vowel(lower[-2]):
        return adjective[:-1] + "ily"
    if lower.endswith("le") and len(lower) > 2:
        return adjective[:-1] + "y"
    if lower.endswith("ic"):
        return adjective + "ally"
    return adjective + "ly"


def possessive(noun: str) -> str:
    if noun.lower().endswith("s"):
        return noun + "'"
    return noun + "'s"


def _match_case(original: str, replacement: str) -> str:
    if original.isupper():
        return replacement.upper()
    if original[:1].isupper():
        return replacement[:1].upper() + replacement[1:]
    return replacement


def to_british(word: str) -> str:
    """Convert a recognised American spelling to its usual British form.

    Unknown words are returned unchanged.  The mapping is intentionally
    conservative and lexical, not a blind suffix substitution.
    """
    lower = word.lower()
    replacement = AMERICAN_TO_BRITISH.get(lower)
    if replacement is None:
        # Handle common -ize/-ise and -or/-our families for words not listed.
        if lower.endswith("ize") and lower not in {"size", "prize", "seize"}:
            replacement = lower[:-3] + "ise"
        elif lower.endswith("ized") and lower not in {"sized", "prized", "seized"}:
            replacement = lower[:-4] + "ised"
        elif lower.endswith("izing") and lower not in {"sizing", "prizing", "seizing"}:
            replacement = lower[:-5] + "ising"
        elif lower.endswith("ization"):
            replacement = lower[:-5] + "isation"
        else:
            return word
    return _match_case(word, replacement)


def is_british_spelling(word: str) -> bool:
    """Return False only when *word* is a known American variant."""
    return word.lower() not in AMERICAN_TO_BRITISH


@dataclass(frozen=True)
class Analysis:
    """One possible morphological analysis of a surface form."""

    lemma: str
    form: str
    rule: str
    confidence: float = 1.0


def analyse(surface: str, lemmas: Iterable[str] | None = None) -> list[Analysis]:
    """Analyse *surface* against candidate *lemmas*.

    This is deliberately conservative.  It reports only forms that the rules
    actually generate for a candidate lemma; it does not guess a lemma from a
    suffix alone.
    """
    if lemmas is None:
        return []
    results: list[Analysis] = []
    for lemma in lemmas:
        candidates = {
            "base": lemma,
            "plural": pluralise(lemma),
            "singular": singularise(lemma),
            "third": third_person(lemma),
            "past": past_tense(lemma),
            "participle": past_participle(lemma),
            "gerund": present_participle(lemma),
            "comparative": comparative(lemma),
            "superlative": superlative(lemma),
            "possessive": possessive(lemma),
        }
        for form, value in candidates.items():
            if value.lower() == surface.lower():
                results.append(Analysis(lemma=lemma, form=form, rule=f"regular:{form}"))
    return results


def inflect(lemma: str, form: str, pos: str = "noun") -> str:
    """Produce a named form, applying only rules valid for the part of speech."""
    form = form.lower()
    if form in {"base", "positive", "singular", "nominative"}:
        return lemma
    if pos == "noun":
        if form == "plural":
            return pluralise(lemma)
        if form in {"possessive", "genitive"}:
            return possessive(lemma)
        if form == "plural_possessive":
            return possessive(pluralise(lemma))
    elif pos in {"verb", "auxiliary"}:
        if form in {"third", "third_person", "3sg"}:
            return third_person(lemma)
        if form in {"past", "past_tense"}:
            return past_tense(lemma)
        if form in {"participle", "past_participle", "pp"}:
            return past_participle(lemma)
        if form in {"gerund", "present_participle", "ing"}:
            return present_participle(lemma)
        if form in {"present_participle"}:
            return present_participle(lemma)
    elif pos in {"adjective", "adverb"}:
        if form == "comparative":
            if pos == "adverb" and lemma.lower() in IRREGULAR_ADVERBS:
                return _match_case(lemma, IRREGULAR_ADVERBS[lemma.lower()][0])
            return comparative(lemma)
        if form == "superlative":
            if pos == "adverb" and lemma.lower() in IRREGULAR_ADVERBS:
                return _match_case(lemma, IRREGULAR_ADVERBS[lemma.lower()][1])
            return superlative(lemma)
        if form == "adverb" and pos == "adjective":
            return adverb_from_adjective(lemma)
    raise MorphologyError(f"cannot inflect {lemma!r} as {pos} form {form!r}")


class Morphology:
    """Static interface to morphological operations."""

    @staticmethod
    def pluralise(word: str) -> str:
        return pluralise(word)

    @staticmethod
    def singularise(word: str) -> str:
        return singularise(word)

    @staticmethod
    def third_person(word: str) -> str:
        return third_person(word)

    @staticmethod
    def past_tense(word: str) -> str:
        return past_tense(word)

    @staticmethod
    def past_participle(word: str) -> str:
        return past_participle(word)

    @staticmethod
    def present_participle(word: str) -> str:
        return present_participle(word)

    @staticmethod
    def comparative(word: str) -> str:
        return comparative(word)

    @staticmethod
    def superlative(word: str) -> str:
        return superlative(word)

    @staticmethod
    def adverb_from_adjective(word: str) -> str:
        return adverb_from_adjective(word)

    @staticmethod
    def possessive(word: str) -> str:
        return possessive(word)

    @staticmethod
    def to_british(word: str) -> str:
        return to_british(word)

    @staticmethod
    def inflect(lemma: str, pos: str, form: str = "base") -> str:
        return inflect(lemma, pos, form)
