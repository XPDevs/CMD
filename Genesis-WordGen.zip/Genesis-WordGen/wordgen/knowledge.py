"""File-backed concept knowledge and symbolic query answering.

All factual descriptions and project identity values are loaded from
``genesis-knowledge.jsonl``. The Python code contains general parsing and
inference procedures, not a bank of prompt-to-response pairs.
"""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_KNOWLEDGE = ROOT / "genesis-knowledge.jsonl"
DEFAULT_DIALOGUE = ROOT / "genesis-dialogue.jsonl"
DEFAULT_DIALOGUE_LEXICON = ROOT / "genesis-dialogue-lexicon.jsonl"


def normalise(text: str) -> str:
    text = text.casefold().replace("’", "'").replace("–", "-")
    return re.sub(r"[^a-z0-9.+%'-]+", " ", text).strip()


def singularise(word: str) -> str:
    irregular = {"people": "person", "children": "child", "men": "man", "women": "woman", "mice": "mouse", "geese": "goose", "teeth": "tooth", "feet": "foot", "data": "data"}
    w = word.casefold()
    if w in irregular:
        return irregular[w]
    if len(w) > 4 and w.endswith("ies"):
        return w[:-3] + "y"
    if len(w) > 4 and w.endswith(("ches", "shes", "xes", "zes")):
        return w[:-2]
    if len(w) > 3 and w.endswith("s") and not w.endswith(("ss", "us", "is")):
        return w[:-1]
    return w


class _SafeFormat(dict):
    def __missing__(self, key):
        return "{" + key + "}"


class KnowledgeBase:
    def __init__(self, path: str | Path = DEFAULT_KNOWLEDGE):
        self.path = Path(path)
        self.records: list[dict[str, Any]] = []
        self.concepts: dict[str, dict[str, Any]] = {}
        self.aliases: dict[str, str] = {}
        self.identity: dict[str, str] = {}
        self.capabilities: list[dict[str, str]] = []
        self.issues: list[str] = []
        self.last_query_trace: list[str] = []
        self.responses: dict[str, list[str]] = {}
        self.response_cues: dict[str, list[str]] = {}
        self.intent_cues: dict[str, list[str]] = {}
        self._load()
        self._load_responses()

    def _load(self) -> None:
        if not self.path.exists():
            self.issues.append(f"Knowledge file not found: {self.path}")
            return
        for line_no, line in enumerate(self.path.read_text(encoding="utf-8").splitlines(), 1):
            if not line.strip():
                continue
            try:
                rec = json.loads(line)
            except json.JSONDecodeError as exc:
                self.issues.append(f"Line {line_no}: invalid JSON ({exc.msg})")
                continue
            kind = rec.get("type")
            self.records.append(rec)
            if kind == "concept" and rec.get("term") and rec.get("definition"):
                key = normalise(rec["term"])
                self.concepts[key] = rec
                self.aliases[key] = key
                for alias in rec.get("aliases", []):
                    self.aliases[normalise(alias)] = key
            elif kind == "identity" and rec.get("key"):
                self.identity[str(rec["key"])] = str(rec.get("value", ""))
            elif kind == "capability":
                self.capabilities.append(rec)
        if not self.concepts:
            self.issues.append("No valid concept records were loaded")


    def _load_responses(self) -> None:
        """Load conversational wording and cues from editable data files."""
        for source in (DEFAULT_DIALOGUE, DEFAULT_DIALOGUE_LEXICON):
            if not source.exists():
                self.issues.append(f"Dialogue knowledge file not found: {source}")
                continue
            for line_no, line in enumerate(source.read_text(encoding="utf-8").splitlines(), 1):
                if not line.strip():
                    continue
                try:
                    record = json.loads(line)
                except json.JSONDecodeError as exc:
                    self.issues.append(f"{source.name} line {line_no}: invalid JSON ({exc.msg})")
                    continue
                if record.get("type") == "response_policy" and record.get("key"):
                    templates = record.get("templates", [])
                    if isinstance(templates, str):
                        templates = [templates]
                    clean = [str(item) for item in templates if str(item).strip()]
                    if clean:
                        self.responses[str(record["key"])] = clean
                elif record.get("type") in {"response_cues", "intent_cues"} and record.get("key"):
                    target = self.response_cues if record.get("type") == "response_cues" else self.intent_cues
                    target[str(record["key"])] = [str(item).casefold() for item in record.get("forms", []) if str(item).strip()]

    def cues(self, key: str, *, intent: bool = False) -> list[str]:
        return list((self.intent_cues if intent else self.response_cues).get(key, []))

    def reply(self, key: str, **values: Any) -> str:
        """Render a response policy loaded from the dialogue data file."""
        templates = self.responses.get(key) or self.responses.get("unknown_query")
        if not templates:
            raise RuntimeError("No response policies were loaded; check genesis-dialogue.jsonl")
        template = templates[0]
        try:
            return template.format_map(_SafeFormat(values))
        except (ValueError, KeyError):
            return template

    def search(self, query: str, limit: int = 5) -> list[dict[str, Any]]:
        """Rank concepts by token overlap; returns only existing loaded records."""
        query_tokens = {t for t in normalise(query).split() if len(t) > 1}
        if not query_tokens:
            return []
        ranked: list[tuple[float, dict[str, Any]]] = []
        for record in self.concepts.values():
            fields = [record.get("term", ""), record.get("definition", ""), record.get("domain", "")]
            fields.extend(record.get("aliases", []))
            fields.extend(record.get("is_a", []))
            fields.extend((record.get("properties") or {}).keys())
            tokens = {t for t in normalise(" ".join(map(str, fields))).split() if len(t) > 1}
            overlap = query_tokens & tokens
            if not overlap:
                continue
            exact = 2.0 if normalise(record.get("term", "")) in normalise(query) else 0.0
            score = exact + len(overlap) / max(1, len(query_tokens)) + len(overlap) / max(1, len(tokens))
            ranked.append((score, record))
        ranked.sort(key=lambda pair: (pair[0], len(pair[1].get("term", ""))), reverse=True)
        return [record for score, record in ranked[:max(0, limit)] if score > 0]

    def resolve(self, phrase: str) -> dict[str, Any] | None:
        key = normalise(phrase)
        key = re.sub(r"^(?:the|a|an|some|any)\s+", "", key)
        if key in self.aliases:
            return self.concepts.get(self.aliases[key])
        # Try inflection normalisation without reducing multiword concepts.
        if key.endswith("s"):
            alt = normalise(singularise(key))
            if alt in self.aliases:
                return self.concepts.get(self.aliases[alt])
        # Match a concept phrase inside a longer noun phrase, preferring the
        # longest concept to avoid resolving "operating system" as "system".
        candidates = sorted(self.aliases, key=len, reverse=True)
        for alias in candidates:
            if re.search(r"(?<![a-z0-9])" + re.escape(alias) + r"(?![a-z0-9])", key):
                return self.concepts.get(self.aliases[alias])
        return None

    def definition(self, phrase: str) -> dict[str, Any] | None:
        return self.resolve(phrase)

    def classification_path(self, child: str | dict[str, Any], parent: str | dict[str, Any]) -> list[str] | None:
        """Return an evidence path through loaded is-a edges, if one exists."""
        child_rec = child if isinstance(child, dict) else self.resolve(child)
        parent_rec = parent if isinstance(parent, dict) else self.resolve(parent)
        if not child_rec or not parent_rec:
            return None
        target = normalise(parent_rec["term"])
        start = normalise(child_rec["term"])
        queue: list[tuple[str, list[str]]] = [(start, [child_rec["term"]])]
        visited: set[str] = set()
        while queue:
            current, path = queue.pop(0)
            if current == target:
                return path
            if current in visited:
                continue
            visited.add(current)
            record = self.resolve(current)
            if not record:
                continue
            for parent_name in record.get("is_a", []):
                parent_record = self.resolve(parent_name)
                canonical = normalise(parent_record["term"] if parent_record else parent_name)
                label = parent_record["term"] if parent_record else str(parent_name)
                if canonical not in visited:
                    queue.append((canonical, path + [label]))
        return None

    def is_a(self, child: str | dict[str, Any], parent: str | dict[str, Any]) -> bool | None:
        path = self.classification_path(child, parent)
        if path:
            return True
        child_rec = child if isinstance(child, dict) else self.resolve(child)
        parent_rec = parent if isinstance(parent, dict) else self.resolve(parent)
        if not child_rec or not parent_rec:
            return None
        # Missing paths are not proof of negation because the knowledge base
        # may be incomplete. Only positive inheritance is inferred.
        return None

    def answer(self, text: str, dialogue=None) -> str | None:
        """Answer from loaded records and keep an auditable retrieval trace."""
        self.last_query_trace = [f"Normalised query: {normalise(text)}"]
        result = self._answer_impl(text, dialogue)
        uncertain = result is None or any(marker in result.casefold() for marker in (
            "do not have a definition", "cannot establish", "does not provide enough",
            "not established by the knowledge", "not found enough supported information",
        ))
        if uncertain:
            self.last_query_trace.append("No supported knowledge record established the requested answer; an uncertainty response was selected.")
        else:
            self.last_query_trace.append("A supported knowledge/query procedure produced a response.")
            # Record the most relevant concept record when a query mentions it.
            mentioned = []
            query_norm = normalise(text)
            for alias, canonical in self.aliases.items():
                if alias and re.search(r"(?<![a-z0-9])" + re.escape(alias) + r"(?![a-z0-9])", query_norm):
                    rec = self.concepts.get(canonical)
                    if rec and rec not in mentioned:
                        mentioned.append(rec)
            if mentioned:
                mentioned.sort(key=lambda rec: len(normalise(rec.get("term", ""))), reverse=True)
                rec = mentioned[0]
                self.last_query_trace.append(
                    f"Knowledge evidence: {rec.get('term')} (domain={rec.get('domain', 'unspecified')}; source={rec.get('source', 'unspecified')}; confidence={rec.get('confidence', 'unspecified')}).")
        return result

    def _answer_impl(self, text: str, dialogue=None) -> str | None:
        """Answer queries only where loaded knowledge or dialogue facts support it."""
        q = text.strip().rstrip("?.! ")
        n = normalise(q)
        if not n:
            return None

        # Identity and capabilities are sourced from data records, not embedded
        # in the engine's realiser.
        creator_question = re.match(r"^who (?:made|created|developed) (.+)$", n)
        if creator_question:
            target = creator_question.group(1).strip()
            target_record = self.resolve(target)
            target_is_engine = (normalise(target) in {normalise(self.identity.get("name", "")), "you", "this system", "this program", "this engine"}
                                or bool(target_record and target_record.get("domain") == "identity"))
            if target_is_engine:
                return self.reply("creator", name=self.identity.get("name", "This system"), creator=self.identity.get("creator", "an unspecified developer"))

        if re.search(r"\b(who|what)\s+(?:are|is)\s+(?:you|this system|this program|this engine)\b|\bwhat(?:'s| is) your name\b|\bwho made you\b|\bwho created you\b|\bwho developed you\b|\bwho is your creator\b", n):
            name = self.identity.get("name", "the language engine")
            creator = self.identity.get("creator", "not specified")
            approach = self.identity.get("approach", "a rule-based language engine")
            if re.search(r"\b(who made|who created|who developed|creator)\b", n):
                return self.reply("creator", name=name, creator=creator)
            return self.reply("identity", name=name, creator=creator, approach=approach)

        if re.search(r"\bwhat can you do\b|\bwhat are you able to do\b|\bwhat capabilities do you have\b|\bhow can you help\b", n):
            if self.capabilities:
                descriptions = [str(c.get("description", "")).strip().rstrip(".") for c in self.capabilities if c.get("description")]
                if descriptions:
                    capability_text = "I can " + descriptions[0].rstrip(".") + "."
                    capability_text += "".join(" I can also " + item.rstrip(".") + "." for item in descriptions[1:])
                else:
                    capability_text = "My available capabilities are not described in the loaded knowledge file."
                return self.reply("capabilities", name=self.identity.get("name", "this system"), creator=self.identity.get("creator", "the project team"), capability_text=capability_text)
            return None

        # A general arithmetic capability that does not rely on memorised sums.
        arithmetic = re.match(r"^(?:what is|calculate|compute)\s+(-?\d+(?:\.\d+)?)\s*(\+|plus|addition|minus|−|-|\*|times|multiplied by|/|divided by|over)\s*(-?\d+(?:\.\d+)?)$", n)
        if arithmetic:
            a, op, b = float(arithmetic.group(1)), arithmetic.group(2), float(arithmetic.group(3))
            if op in {"+", "plus", "addition"}: result = a + b
            elif op in {"minus", "−", "-"}: result = a - b
            elif op in {"*", "times", "multiplied by"}: result = a * b
            elif op in {"/", "divided by", "over"}:
                if b == 0: return self.reply("division_by_zero")
                result = a / b
            else: return None
            rendered = str(int(result)) if result.is_integer() else f"{result:.10g}"
            return self.reply("arithmetic_result", result=rendered)


        # Compare two concepts using their loaded definitions and relation graph.
        diff = re.match(r"^(?:what is the difference between|compare) (.+?) and (.+)$", n)
        if diff:
            left = self.resolve(diff.group(1))
            right = self.resolve(diff.group(2))
            if left and right:
                left_term = left["term"] if left["term"].isupper() else left["term"].capitalize()
                right_term = right["term"] if right["term"].isupper() else right["term"].capitalize()
                return self.reply("difference", left=left_term, left_definition=left["definition"], right=right_term, right_definition=right["definition"])

        # Definition / meaning requests share one retrieval procedure.
        phrase = None
        patterns = [
            r"^(?:what is|what are|what's|define|explain|describe)\s+(?:(?:a|an|the)\s+)?(.+)$",
            r"^(?:what does)\s+(.+?)\s+mean$",
            r"^(?:tell me about)\s+(.+)$",
        ]
        for pat in patterns:
            m = re.match(pat, n)
            if m:
                phrase = m.group(1).strip()
                break
        if phrase:
            # Trim common trailing conversational material but retain concept names.
            phrase = re.sub(r"\b(?:please|in simple terms|in british english)\b", "", phrase).strip()
            rec = self.resolve(phrase)
            if rec:
                term = rec["term"]
                if term and not term.isupper():
                    term = term[0].upper() + term[1:]
                parents = rec.get("is_a", [])
                classification = f" It is classified as {parents[0]} in this knowledge base." if parents else ""
                props = rec.get("properties") or {}
                details = "; ".join(f"{k.replace('_', ' ')}: {v}" for k, v in props.items())
                property_text = f" Recorded details: {details}." if details else ""
                return self.reply("concept_definition", term=term, definition=rec["definition"], classification=classification, properties=property_text)
            return self.reply("unknown_definition", phrase=phrase)

        # Taxonomic questions use explicit parent relations and transitive closure.
        m = re.match(r"^(?:is|are)\s+(?:a|an|the)?\s*(.+?)\s+(?:a|an|the)\s+(.+)$", n)
        if m:
            left, right = m.group(1).strip(), m.group(2).strip()
            # Ignore common question auxiliaries that can appear in unusual forms.
            child, parent = self.resolve(left), self.resolve(right)
            if child and parent:
                relation = self.is_a(child, parent)
                if relation is True:
                    path = self.classification_path(child, parent) or [child["term"], parent["term"]]
                    self.last_query_trace.append("Taxonomic inference path: " + " -> ".join(path))
                    return self.reply("taxonomy_yes", child=child["term"], parent=parent["term"])
                if relation is False:
                    return self.reply("taxonomy_uncertain", child=child["term"], parent=parent["term"])
            return self.reply("classification_unknown")

        # General comparison / property query against explicitly stored concept data.
        m = re.match(r"^(?:what|which)\s+(.+?)\s+(?:does|do)\s+(.+?)\s+have$", n)
        if m:
            prop, entity = m.group(1), m.group(2)
            rec = self.resolve(entity)
            if rec:
                props = rec.get("properties", {})
                matches = [(k, v) for k, v in props.items() if prop in normalise(k) or normalise(k) in prop]
                if matches:
                    return " ".join(self.reply("relation_property", term=rec["term"], property=k.replace("_", " "), value=v) for k, v in matches)

        # Retrieve a relevant concept when the user asks for an explanation,
        # asks what the system knows, or gives a broad topic query.
        broad = re.match(r"^(?:what do you know about|give me information about|information about|explain|describe|tell me about|what is|what are|define) (.+)$", n)
        if broad:
            target = re.sub(r"^(?:a|an|the)\s+", "", broad.group(1).strip())
            rec = self.resolve(target)
            if rec:
                display_term = rec["term"] if rec["term"].isupper() else rec["term"][0].upper() + rec["term"][1:]
                return self.reply("concept_definition", term=display_term, definition=rec["definition"], classification=(f" It is classified as {rec['is_a'][0]} in this knowledge base." if rec.get("is_a") else ""), properties=(" Recorded details: " + "; ".join(f"{k.replace('_', ' ')}: {v}" for k, v in rec.get("properties", {}).items()) + "." if rec.get("properties") else ""))

        # A broad search can return related stored concepts without claiming
        # that they are a direct answer. Results remain grounded in the file.
        if any(word in n.split() for word in ("related", "topics", "examples", "concepts")):
            found = self.search(n, limit=5)
            if found:
                results = "; ".join(f"{item['term']}: {item['definition']}" for item in found)
                return self.reply("search_results", results=results)
        return None

    def stats(self) -> dict[str, int]:
        return {"records": len(self.records), "concepts": len(self.concepts), "identity_records": len(self.identity), "capabilities": len(self.capabilities), "response_policies": len(self.responses), "response_cue_groups": len(self.response_cues), "intent_cue_groups": len(self.intent_cues)}
