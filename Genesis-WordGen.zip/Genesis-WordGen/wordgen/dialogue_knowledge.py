"""Small, general-purpose dialogue fact extraction and retrieval.

This is a symbolic component, not a language model. It extracts a deliberately
limited set of explicit facts from arbitrary text using reusable linguistic
patterns. It stores provenance and does not infer facts from unsupported guesses.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
import re
from typing import Iterable
import json
from pathlib import Path


# Measurement units are vocabulary, not prompt/response pairs. The same rules
# apply to any property phrase (RAM, storage, weight, distance, duration, etc.).
_UNIT_ALIASES = {
    "b": "B", "byte": "B", "bytes": "B",
    "kb": "KB", "kilobyte": "KB", "kilobytes": "KB",
    "mb": "MB", "megabyte": "MB", "megabytes": "MB",
    "gb": "GB", "gigabyte": "GB", "gigabytes": "GB",
    "tb": "TB", "terabyte": "TB", "terabytes": "TB",
    "hz": "Hz", "khz": "kHz", "mhz": "MHz", "ghz": "GHz",
    "mm": "mm", "cm": "cm", "m": "m", "km": "km",
    "mg": "mg", "g": "g", "kg": "kg",
    "ml": "ml", "l": "l", "litre": "litres", "litres": "litres",
    "second": "seconds", "seconds": "seconds", "minute": "minutes", "minutes": "minutes",
    "hour": "hours", "hours": "hours", "year": "years", "years": "years",
    "%": "%", "percent": "%",
}

_ARTICLES = re.compile(r"^(?:the|a|an|my|your|his|her|its|our|their|this|that)\s+", re.I)
_ROOT = Path(__file__).resolve().parents[1]
_RELATION_DATA = _ROOT / "genesis-dialogue-lexicon.jsonl"

@dataclass
class DialogueFact:
    subject: str
    relation: str
    value: str
    property: str = ""
    unit: str = ""
    source_text: str = ""
    confidence: float = 0.85

    def to_dict(self):
        return asdict(self)


def _clean_entity(value: str) -> str:
    value = re.sub(r"[.!?,;:]+$", "", value.strip())
    value = _ARTICLES.sub("", value)
    return re.sub(r"\s+", " ", value).strip()


def _normalise(value: str) -> str:
    return re.sub(r"[^a-z0-9%]+", " ", value.lower()).strip()


class DialogueKnowledge:
    """Extract and retrieve explicit facts across dialogue turns."""

    def __init__(self):
        self.facts: list[DialogueFact] = []
        self.focus_entity: str | None = None
        self.relation_forms: dict[str, list[str]] = {}
        self.query_forms: dict[str, list[str]] = {}
        self.relation_labels: dict[str, str] = {}
        self._load_relation_data()

    def _load_relation_data(self) -> None:
        """Load relation vocabulary and question cues from editable data files."""
        if not _RELATION_DATA.exists():
            return
        for line in _RELATION_DATA.read_text(encoding="utf-8").splitlines():
            try:
                record = json.loads(line)
            except json.JSONDecodeError:
                continue
            target = self.relation_forms if record.get("type") == "relation_lexeme" else self.query_forms if record.get("type") == "query_relation" else None
            if target is not None and record.get("relation"):
                target.setdefault(str(record["relation"]), []).extend(str(x).lower() for x in record.get("forms", []) if str(x).strip())
                if record.get("type") == "relation_lexeme" and record.get("display"):
                    self.relation_labels[str(record["relation"])] = str(record["display"])

    def learn(self, text: str) -> list[DialogueFact]:
        added: list[DialogueFact] = []
        # Learn a salient entity from common acquisition/ownership constructions.
        entity_patterns = (
            r"\b(?:i|we|you|they|he|she)\s+(?:have|bought|got|own|use|used|built|made)\s+(?:a|an|the|my|our|their)?\s*([a-z][a-z0-9_-]*(?:\s+[a-z][a-z0-9_-]*){0,2})",
            r"\b(?:my|our|their|his|her)\s+([a-z][a-z0-9_-]*(?:\s+[a-z][a-z0-9_-]*){0,2})\b",
        )
        for pattern in entity_patterns:
            for match in re.finditer(pattern, text, re.I):
                candidate = _clean_entity(match.group(1))
                words = candidate.split()
                stop_words = {"it", "they", "he", "she", "has", "have", "had", "is", "are", "was", "were", "and", "but", "with", "that", "this", "then", "yesterday", "today"}
                while words and words[-1].lower() in stop_words:
                    words.pop()
                while words and words[0].lower() in stop_words:
                    words.pop(0)
                candidate = " ".join(words)
                if candidate and candidate.lower() not in {"it", "them", "him", "her", "one", "some"}:
                    self.focus_entity = candidate
                    break
            if self.focus_entity:
                break

        # General property measurement: entity/pronoun + possession/containment
        # verb + quantity + unit + optional 'of' + property name.
        unit_alt = "|".join(sorted((re.escape(k) for k in _UNIT_ALIASES), key=len, reverse=True))
        measure = re.compile(
            rf"\b(?P<subject>[\w'-]+)\s+(?P<verb>has|have|had|contains|contained|uses|used|weighs|measures|is)\s+"
            rf"(?P<number>\d+(?:\.\d+)?)\s*(?P<unit>{unit_alt})\b\s*(?:of\s+)?(?P<property>[a-z][a-z0-9 -]{{0,35}})?",
            re.I,
        )
        for match in measure.finditer(text):
            subject = match.group("subject")
            if subject.lower() in {"it", "they", "he", "she", "this", "that", "there"}:
                subject = self.focus_entity or subject
            unit_key = match.group("unit").lower()
            unit = _UNIT_ALIASES.get(unit_key, match.group("unit"))
            prop = (match.group("property") or "").strip(" .,!?:;")
            # Trim discourse after the property phrase; retain a concise nominal head.
            prop = re.split(r"\b(?:and|but|because|while|whereas|which|that)\b", prop, maxsplit=1, flags=re.I)[0].strip()
            prop = re.sub(r"\b(?:is|are|was|were|with|without|today|yesterday)$", "", prop, flags=re.I).strip()
            value = f"{match.group('number')} {unit}"
            fact = DialogueFact(_clean_entity(subject), "has_measurement", value, _clean_entity(prop), unit, text)
            if fact.property and not any(self._equivalent(f, fact) for f in self.facts):
                self.facts.append(fact)
                added.append(fact)
                if subject.lower() not in {"it", "they", "he", "she"}:
                    self.focus_entity = _clean_entity(subject)

        # General identity/property statements provide a useful referent when
        # a user introduces an object without a measurement.
        identity = re.compile(r"\b(?:my|our|their|his|her|the|a|an)\s+([a-z][\w -]{0,35}?)\s+(?:is|are|was|were)\s+([a-z][\w -]{0,30}?)(?=[.!?,;]|$)", re.I)
        for match in identity.finditer(text):
            subject = _clean_entity(match.group(1))
            value = _clean_entity(match.group(2))
            if subject and value and len(subject.split()) <= 4:
                fact = DialogueFact(subject, "has_property", value, "property", "", text, .7)
                if not any(self._equivalent(f, fact) for f in self.facts):
                    self.facts.append(fact)
                    added.append(fact)
                self.focus_entity = subject

        # Extract reusable user-centred relations from data-driven verb lists.
        # The vocabulary is externalised in genesis-dialogue-lexicon.jsonl; the
        # same extraction procedure applies to every configured relation.
        relation_candidates = []
        for relation, forms in self.relation_forms.items():
            for form in forms:
                relation_candidates.append((form, relation))
        relation_candidates.sort(key=lambda item: len(item[0]), reverse=True)
        if relation_candidates:
            alternatives = "|".join(re.escape(form) for form, _ in relation_candidates)
            relation_map = {form: relation for form, relation in relation_candidates}
            pattern = re.compile(r"\b(?:i|my|we)\s+(?P<verb>" + alternatives + r")\s+(?P<value>[^.!?;,]+)", re.I)
            for match in pattern.finditer(text):
                verb = match.group("verb").lower()
                relation = relation_map.get(verb)
                value = _clean_entity(match.group("value"))
                value = re.sub(r"^(?:a|an|the|to)\s+", "", value, flags=re.I).strip()
                value = re.sub(r"\s+(?:yesterday|today|last night|this morning)$", "", value, flags=re.I).strip()
                if not relation or not value or len(value) > 100:
                    continue
                if relation == "has_property" and value.lower() in {"called", "named"}:
                    continue
                fact = DialogueFact("you", relation, value, relation, "", text, .78)
                if not any(self._equivalent(f, fact) for f in self.facts):
                    self.facts.append(fact)
                    added.append(fact)
                if relation in {"bought", "owns", "uses", "studies", "works_at", "lives_in"}:
                    self.focus_entity = value
        return added

    @staticmethod
    def _equivalent(a: DialogueFact, b: DialogueFact) -> bool:
        return (_normalise(a.subject) == _normalise(b.subject)
                and _normalise(a.relation) == _normalise(b.relation)
                and _normalise(a.value) == _normalise(b.value)
                and _normalise(a.property) == _normalise(b.property))

    def find_property(self, property_text: str = "", entity: str | None = None) -> DialogueFact | None:
        wanted = _normalise(property_text)
        entity_key = _normalise(entity or self.focus_entity or "")
        for fact in reversed(self.facts):
            property_key = _normalise(fact.property)
            subject_key = _normalise(fact.subject)
            property_match = not wanted or wanted in property_key or property_key in wanted
            entity_match = not entity_key or subject_key == entity_key or subject_key in entity_key or entity_key in subject_key
            if property_match and entity_match:
                return fact
        # If the property is explicit, allow the latest matching fact even when
        # the question omits the entity pronoun's antecedent.
        if wanted:
            for fact in reversed(self.facts):
                p = _normalise(fact.property)
                if wanted in p or p in wanted:
                    return fact
        return None

    def find_relation(self, relation: str) -> DialogueFact | None:
        for fact in reversed(self.facts):
            if fact.relation == relation:
                return fact
        return None

    def answer_relation(self, question: str) -> DialogueFact | None:
        """Match a follow-up question to a stored relation using loaded cue data."""
        q = _normalise(question)
        # Location and workplace questions are relation queries, not word lookup.
        if re.search(r"\bwhere\b", q):
            for relation in ("lives_in", "works_at"):
                fact = self.find_relation(relation)
                if fact:
                    return fact
        for relation, forms in self.query_forms.items():
            if any(re.search(r"\b" + re.escape(form) + r"\b", q) for form in forms):
                fact = self.find_relation(relation)
                if fact:
                    return fact
        # If a short follow-up asks for the most recent item without naming a
        # relation, only return a fact when there is a single plausible one.
        if re.fullmatch(r"(?:what|which) (?:is|was) (?:it|that)|what about it", q):
            candidates = [f for f in self.facts if f.relation not in {"has_measurement", "has_property"}]
            if len(candidates) == 1:
                return candidates[0]
        return None

    def snapshot(self) -> list[dict]:
        return [f.to_dict() for f in self.facts]
