"""Rule-based reasoning for the British English language engine."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class Inference:
    conclusion: str
    premises: list[str] = field(default_factory=list)
    rule: str = ""
    confidence: float = 0.5


@dataclass
class ReasoningResult:
    inferences: list[Inference] = field(default_factory=list)
    explanations: list[str] = field(default_factory=list)
    confidence: float = 0.5


class Reasoner:
    def reason(self, meaning, intent, context=None) -> ReasoningResult:
        result = ReasoningResult()
        if meaning is None:
            return result
        for prop in getattr(meaning, "propositions", []):
            if prop.modality:
                result.inferences.append(Inference(f"modal:{prop.modality} applies to {prop.predicate}", [f"predicate {prop.predicate}"], "modal-rule", 0.6))
            if prop.voice == "passive":
                result.inferences.append(Inference(f"passive construction for {prop.predicate}", [f"aux chain {prop.features.get('aux_chain')}"], "passive-rule", 0.6))
            if prop.polarity is False:
                result.inferences.append(Inference(f"negation affects {prop.predicate}", ["negation present"], "negation-rule", 0.6))
        if intent and intent.name == "wh_question":
            result.explanations.append("A wh-question seeks information about the questioned constituent.")
        if intent and intent.name == "yes_no_question":
            result.explanations.append("A yes/no question seeks confirmation or denial of the proposition.")
        result.confidence = min((i.confidence for i in result.inferences), default=0.4) if result.inferences else 0.4
        return result
