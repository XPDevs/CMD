import unittest
import io
from contextlib import redirect_stdout
from wordgen.engine import Engine
from wordgen.cli import main as cli_main


class EngineTests(unittest.TestCase):
    def setUp(self):
        self.engine = Engine()

    def test_process(self):
        result = self.engine.process("The dog chased the cat.")
        self.assertTrue(result.response)
        self.assertIsNotNone(result.parse)
        self.assertIsNotNone(result.intent)

    def test_multiturn_context(self):
        self.engine.process("The dog chased the cat.")
        result = self.engine.process("Who came?")
        self.assertTrue(result.context_summary["turn_count"] >= 2)

    def test_generalisation(self):
        # Should handle sentences not seen before using rules + inventory
        result = self.engine.process("The teacher read a book to the student.")
        self.assertIsNotNone(result.parse)
        self.assertTrue(result.response)


    def test_wh_question_uses_relevant_user_fact(self):
        self.engine.process("The dog came.")
        result = self.engine.process("Who came?")
        self.assertEqual(result.response, "The dog.")

    def test_wh_question_does_not_reuse_unrelated_fact(self):
        self.engine.process("The dog chased the cat.")
        result = self.engine.process("Who came?")
        self.assertIn("not have enough information", result.response)
        self.assertNotIn("dog chased", result.response.lower())

    def test_personal_preference_is_not_fabricated(self):
        result = self.engine.process("Do you like tea?")
        self.assertIn("do not have personal", result.response.lower())

    def test_command_does_not_claim_execution(self):
        result = self.engine.process("Close the door.")
        self.assertIn("cannot carry it out", result.response.lower())

    def test_generated_response_is_validated(self):
        result = self.engine.process("Hello")
        self.assertIsNotNone(result.generated_validation)
        self.assertTrue(result.generated_validation.valid)


    def test_measurement_fact_is_remembered_and_answered(self):
        first = self.engine.process("I bought a PC. It has 8GB of RAM.")
        self.assertIn("8 GB", first.response)
        answer = self.engine.process("How much RAM does it have?")
        self.assertIn("8 GB", answer.response)
        self.assertIn("RAM", answer.response)
        self.assertTrue(answer.realisation.features.get("grounded"))

    def test_general_measurement_pattern_not_specific_to_ram(self):
        self.engine.process("My laptop has 512 GB of storage.")
        answer = self.engine.process("How much storage?")
        self.assertIn("512 GB", answer.response)
        self.assertIn("storage", answer.response.lower())

    def test_capability_question_is_not_mistaken_for_missing_user_fact(self):
        answer = self.engine.process("What can you do?")
        self.assertIn("Genesis-SPT-7.0", answer.response)
        self.assertIn("analyse many British English sentence structures", answer.response)
        self.assertNotIn("not have enough information", answer.response.lower())

    def test_capability_question_is_not_overridden_by_topic_memory(self):
        self.engine.process("I bought a PC. It has 8GB of RAM.")
        answer = self.engine.process("What can you do?")
        self.assertIn("Genesis-SPT-7.0", answer.response)
        self.assertIn("analyse many British English sentence structures", answer.response)
        self.assertNotIn("8 GB", answer.response)

    def test_measurement_can_be_extracted_from_shallow_input(self):
        first = self.engine.process("i bought a PC it has 8GB ram")
        answer = self.engine.process("how much ram?")
        self.assertIn("8 GB", answer.response)
        self.assertIn("PC", answer.response)


    def test_identity_is_loaded_from_knowledge_file(self):
        answer = self.engine.process("Who are you?")
        self.assertIn("Genesis-SPT-7.0", answer.response)
        self.assertIn("XPDevs", answer.response)
        self.assertIn("genesis-knowledge.jsonl", answer.realisation.features.get("source", ""))

    def test_identity_creator_query_can_name_the_project(self):
        answer = self.engine.process("Who developed Genesis-SPT-7.0?")
        self.assertIn("XPDevs", answer.response)

    def test_concept_definition_comes_from_loaded_knowledge(self):
        answer = self.engine.process("What is a computer?")
        self.assertIn("electronic or mechanical system", answer.response)
        self.assertEqual(answer.realisation.features.get("source"), "genesis-knowledge.jsonl")

    def test_abbreviation_definition_is_not_mistaken_for_article(self):
        answer = self.engine.process("What is AI?")
        self.assertIn("artificial intelligence", answer.response.lower())

    def test_transitive_taxonomy_inference(self):
        answer = self.engine.process("Is a dog a living thing?")
        self.assertIn("Yes", answer.response)
        self.assertIn("living thing", answer.response)
        self.assertTrue(any("Taxonomic inference path" in step.result for step in answer.reasoning_trace))

    def test_arithmetic_is_computed_not_retrieved_as_definition(self):
        answer = self.engine.process("What is 19 plus 23?")
        self.assertEqual(answer.response, "42.")

    def test_unknown_definition_is_not_fabricated(self):
        answer = self.engine.process("What is a zargleflorp?")
        self.assertIn("do not have a definition", answer.response)

    def test_copular_adjective_is_interpreted(self):
        result = self.engine.process("She is happy.")
        self.assertTrue(result.meaning.propositions)
        self.assertEqual(result.meaning.propositions[0].predicate, "be")


    def test_expanded_concept_knowledge_is_file_backed(self):
        result = self.engine.process("What is a compiler?")
        self.assertIn("translates source code", result.response)
        self.assertEqual(result.realisation.features.get("source"), "genesis-knowledge.jsonl")
        self.assertGreaterEqual(self.engine.knowledge_base.stats()["concepts"], 450)

    def test_concept_comparison_uses_loaded_definitions(self):
        result = self.engine.process("What is the difference between RAM and storage?")
        self.assertIn("readily accessible", result.response)
        self.assertIn("retaining data", result.response)

    def test_general_preference_relation_is_remembered(self):
        self.engine.process("I like tea.")
        result = self.engine.process("What do I like?")
        self.assertIn("you like tea", result.response.lower())
        self.assertTrue(result.realisation.features.get("grounded"))

    def test_location_relation_is_remembered(self):
        self.engine.process("I live in Studley.")
        result = self.engine.process("Where do I live?")
        self.assertIn("Studley", result.response)
        self.assertTrue(result.realisation.features.get("grounded"))

    def test_user_fact_summary_uses_current_session(self):
        self.engine.process("I like tea.")
        result = self.engine.process("What do you know about me?")
        self.assertIn("tea", result.response.lower())

    def test_conversation_wording_is_loaded_from_data_file(self):
        self.assertGreaterEqual(self.engine.knowledge_base.stats()["response_policies"], 30)
        self.assertTrue(self.engine.knowledge_base.responses.get("greeting"))

    def test_dialogue_relation_vocabulary_is_loaded_from_data_file(self):
        self.assertIn("likes", self.engine.context.knowledge.relation_forms)
        self.assertIn("lives_in", self.engine.context.knowledge.query_forms)

    def test_unknown_fact_is_not_invented(self):
        result = self.engine.process("What is the current population of Zargleflorp City?")
        self.assertTrue(result.response)
        self.assertNotIn("is exactly", result.response.lower())


    def test_new_relation_is_acknowledged_without_prompt_mapping(self):
        result = self.engine.process("I like tea.")
        self.assertIn("you like tea", result.response.lower())
        self.assertTrue(result.realisation.features.get("grounded"))

    def test_expanded_knowledge_has_six_hundred_plus_concepts(self):
        self.assertGreaterEqual(self.engine.knowledge_base.stats()["concepts"], 600)


    def test_reasoning_trace_explains_observable_steps(self):
        result = self.engine.process("What is a knowledge graph?")
        stages = [step.stage for step in result.reasoning_trace]
        self.assertIn("syntax", stages)
        self.assertIn("intent", stages)
        self.assertIn("response selection", stages)
        self.assertIn("knowledge resources", stages)
        self.assertTrue(any("knowledge graph" in step.result.lower() for step in result.reasoning_trace))

    def test_trace_does_not_claim_unsupported_answer(self):
        result = self.engine.process("What is a zargleflorp?")
        self.assertTrue(any("No supported knowledge record" in step.result for step in result.reasoning_trace))


    def test_cli_shows_reasoning_trace_before_final_answer(self):
        output = io.StringIO()
        with redirect_stdout(output):
            exit_code = cli_main(["--show-reasoning", "What is a knowledge graph?"])
        rendered = output.getvalue()
        self.assertEqual(exit_code, 0)
        self.assertLess(rendered.index("Genesis reasoning trace"), rendered.index("--- Final answer ---"))
        self.assertLess(rendered.index("--- Final answer ---"), rendered.index("relationships between them"))

    def test_new_computing_concept_can_be_retrieved(self):
        result = self.engine.process("What is a knowledge graph?")
        self.assertIn("relationships between them", result.response)


if __name__ == "__main__":
    unittest.main()
