import unittest
from wordgen.tokeniser import tokenise


class TokeniserTests(unittest.TestCase):
    def test_basic(self):
        tokens = tokenise("The dog chased the cat.")
        words = [t.text for t in tokens if t.kind == "word"]
        self.assertEqual(words, ["The", "dog", "chased", "the", "cat"])

    def test_contractions(self):
        tokens = tokenise("Don't go.")
        words = [t.text for t in tokens if t.kind == "word"]
        self.assertIn("do", [w.lower() for w in words])
        self.assertIn("not", [w.lower() for w in words])

    def test_question(self):
        tokens = tokenise("Who came?")
        self.assertTrue(any(t.kind == "punctuation" and t.text == "?" for t in tokens))


if __name__ == "__main__":
    unittest.main()
