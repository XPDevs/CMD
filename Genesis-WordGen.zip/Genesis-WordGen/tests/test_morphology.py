import unittest
from wordgen import morphology


class MorphologyTests(unittest.TestCase):
    def test_plurals(self):
        self.assertEqual(morphology.pluralise("dog"), "dogs")
        self.assertEqual(morphology.pluralise("box"), "boxes")
        self.assertEqual(morphology.pluralise("city"), "cities")
        self.assertEqual(morphology.pluralise("knife"), "knives")
        self.assertEqual(morphology.pluralise("child"), "children")
        self.assertEqual(morphology.pluralise("sheep"), "sheep")

    def test_verbs(self):
        self.assertEqual(morphology.third_person("go"), "goes")
        self.assertEqual(morphology.past_tense("go"), "went")
        self.assertEqual(morphology.past_tense("play"), "played")
        self.assertEqual(morphology.present_participle("run"), "running")

    def test_comparatives(self):
        self.assertEqual(morphology.comparative("big"), "bigger")
        self.assertEqual(morphology.comparative("good"), "better")
        self.assertEqual(morphology.superlative("bad"), "worst")

    def test_british_spelling(self):
        self.assertEqual(morphology.to_british("color"), "colour")
        self.assertEqual(morphology.to_british("behavior"), "behaviour")
        self.assertEqual(morphology.to_british("realize"), "realise")


if __name__ == "__main__":
    unittest.main()
