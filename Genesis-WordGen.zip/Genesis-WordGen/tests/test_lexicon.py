import unittest
from wordgen.lexicon import Lexicon


class LexiconTests(unittest.TestCase):
    def setUp(self):
        self.lexicon = Lexicon()

    def test_uses_british_words_txt(self):
        self.assertIn("dog", self.lexicon.inventory)
        self.assertIn("colour", self.lexicon.inventory)
        self.assertIn("favour", self.lexicon.inventory)

    def test_matches_core_words(self):
        matches = self.lexicon.matches("dog")
        self.assertTrue(any(m.pos == "noun" for m in matches))
        matches = self.lexicon.matches("chased")
        self.assertTrue(any(m.pos == "verb" for m in matches))
        matches = self.lexicon.matches("is")
        self.assertTrue(any(m.pos in {"auxiliary", "verb"} for m in matches))

    def test_british_variants(self):
        matches = self.lexicon.matches("color")
        self.assertTrue(matches)


if __name__ == "__main__":
    unittest.main()
