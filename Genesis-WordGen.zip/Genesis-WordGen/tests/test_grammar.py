import unittest
from wordgen.lexicon import Lexicon
from wordgen.grammar import Grammar, Parser


class GrammarTests(unittest.TestCase):
    def setUp(self):
        self.lexicon = Lexicon()
        self.grammar = Grammar.default()
        self.parser = Parser(self.grammar, self.lexicon)

    def test_declarative(self):
        result = self.parser.parse("The dog chased the cat.")
        self.assertTrue(result.root is not None)
        self.assertFalse(result.shallow)

    def test_copular(self):
        result = self.parser.parse("She is happy.")
        self.assertTrue(result.root is not None)
        self.assertFalse(result.shallow)

    def test_passive(self):
        result = self.parser.parse("The cat was chased by the dog.")
        self.assertTrue(result.root is not None)
        self.assertFalse(result.shallow)

    def test_question(self):
        result = self.parser.parse("Who came?")
        self.assertTrue(result.root is not None)
        self.assertFalse(result.shallow)

    def test_imperative(self):
        result = self.parser.parse("Close the door.")
        self.assertTrue(result.root is not None)
        self.assertFalse(result.shallow)


if __name__ == "__main__":
    unittest.main()
