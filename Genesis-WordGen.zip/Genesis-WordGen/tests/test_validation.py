import unittest
from wordgen.lexicon import Lexicon
from wordgen.grammar import Grammar, Parser
from wordgen.validator import Validator


class ValidationTests(unittest.TestCase):
    def setUp(self):
        self.lexicon = Lexicon()
        self.grammar = Grammar.default()
        self.parser = Parser(self.grammar, self.lexicon)
        self.validator = Validator(self.lexicon, self.grammar)

    def test_validate_parse(self):
        result = self.parser.parse("The dog chased the cat.")
        validation = self.validator.validate_parse(result)
        self.assertTrue(validation.valid)


if __name__ == "__main__":
    unittest.main()
