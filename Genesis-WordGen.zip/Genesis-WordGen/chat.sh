#!/usr/bin/env bash
# Start an interactive British English language-engine session.
set -euo pipefail

cd "$(dirname "$0")"

PYTHON="${PYTHON:-python3}"

if ! command -v "$PYTHON" >/dev/null 2>&1; then
    echo "error: $PYTHON was not found" >&2
    exit 1
fi

exec "$PYTHON" main.py "$@"
