# Genesis-SPT-7.0 by XPDevs

This project contains two distinct language-system paths:

1. **The original WordGen symbolic engine** (`main.py`, `wordgen/`) uses explicit grammar, lexical resources, knowledge files and symbolic procedures.
2. **The new neural conversation prototype** (`neural/`) is a small character-level GRU that learns next-character patterns from dialogue text. It trains from scratch and runs locally with PyTorch.

## Train and run the neural prototype

From this directory, using Linux Mint or another system with Python 3.10+:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r neural/requirements.txt
python neural/download_data.py --max-dialogues 12000
python neural/train.py --steps 5000
python neural/chat.py
```

Short smoke training is available with `python neural/train.py --steps 100`. The default model is small (normally around 200,000 trainable parameters), CPU-only, and detects currently available RAM before choosing a conservative batch size. The model checkpoint is saved under `neural/checkpoints/`.

The downloader obtains DailyDialog from Hugging Face; the corpus is not bundled in this ZIP. Its licence is separate from the project code: read `neural/DATA_LICENSES.md` before redistribution or use. Training and chat do not call a hosted AI service or require an API key.

**Limitations:** A small model trained from scratch is a real neural network, but it is not equivalent to a modern large language model. It can learn spelling, punctuation, and dialogue patterns, but may still produce repetitive or incoherent text and unreliable facts. The identity profile and training examples identify it as **Genesis-SPT-7.0**, created by **XPDevs**, but a tiny neural model cannot be guaranteed to answer identity questions correctly every time.

For the neural-specific details, see [`neural/README.md`](neural/README.md). For the original symbolic engine's transparent processing trace, see [`THINKING_MODE.md`](THINKING_MODE.md).
