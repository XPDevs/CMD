# Genesis-SPT-7.0 knowledge architecture

Genesis-SPT-7.0 is a conventional, rule-based Python language and dialogue engine developed by XPDevs. It does not use a neural language model or external AI API.

## Loaded data files

- `british-words.txt` — the existing large surface-form word inventory. A word appearing here is not automatically a verified definition.
- `how-sentences-are-formed` — the human-readable British English grammar specification.
- `genesis-knowledge.jsonl` — structured concepts, definitions, taxonomic links, properties, identity and capability information.
- `genesis-dialogue.jsonl` — response wording and conversational response policies. These are data records, not Python prompt-to-response branches.
- `genesis-dialogue-lexicon.jsonl` — editable relation vocabulary used for extracting and querying user-stated preferences, purchases, studies, work and location facts.

All files are loaded from the project directory at runtime. The build validates that the required files exist and the tests exercise their loaded content.

## Current knowledge scale

The concept file contains 660 curated concept records across computing, programming, language, mathematics, science, biology, physics, chemistry, society, logic, geography, health and general reasoning. The word inventory is much larger, but those word forms do not each have a verified definition. The project does not claim to be a complete dictionary or encyclopaedia.

Each concept record can include:

- `term`: canonical concept name
- `aliases`: alternative names
- `definition`: explanation grounded in the project's curated data
- `domain`: subject area
- `is_a`: parent concepts used by symbolic category inference
- `properties`: explicit structured properties
- `relations`: reserved for typed relations
- `source`: provenance label
- `confidence`: editorial confidence estimate, not a model probability

## Conversational knowledge

Dialogue facts are extracted from what the user explicitly says and are held in memory for the current session. The system can retrieve certain measurements, preferences, purchases, study topics, work relationships and location statements in follow-up questions. It stores the source utterance and marks recalled facts as grounded in the conversation. It does not independently verify what the user says.

Response wording and the vocabulary of dialogue relations are external data files. Adding a new word, concept, response template or supported relation can often be done by editing a data file without editing the response realiser. New inference capabilities still require algorithms; no general-purpose program can be made entirely without code or rules. The design goal is to avoid hardcoded factual claims and individual prompt-to-response mappings, not to remove the algorithms that interpret language.

## How to add knowledge

Add one JSON object per line to `genesis-knowledge.jsonl`. Give the concept a unique `term`, a definition, domain and only justified relationships. Add alternate forms to `aliases`. If a parent concept is not present or the relationship is not recorded, the engine should not infer it as established fact.

Add a `response_policy` record to `genesis-dialogue.jsonl` to edit conversational wording. Add relation or query vocabulary to `genesis-dialogue-lexicon.jsonl` to extend supported user-fact relations. Keep the file valid JSON Lines.

## Limitations

The system is not equivalent to a modern large language model. It generalises through explicit grammar, lexical patterns, structured knowledge retrieval and symbolic rules. It cannot reliably answer arbitrary factual questions without suitable knowledge or a relevant reasoning procedure. It should prefer an explicit uncertainty response to inventing unsupported facts. Dialogue memory currently lasts only for the active session.
