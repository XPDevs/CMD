"""Main entry point for the British English language engine."""

from wordgen import cli


if __name__ == "__main__":
    raise SystemExit(cli.main())
