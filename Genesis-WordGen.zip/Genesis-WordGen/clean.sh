#!/usr/bin/env bash
# Remove generated caches and build artefacts.  Source and knowledge files are
# never touched.
set -euo pipefail

cd "$(dirname "$0")"

echo "== Cleaning generated files =="

find . -type d -name '__pycache__' -prune -exec rm -rf {} + 2>/dev/null || true
find . -type f \( -name '*.pyc' -o -name '*.pyo' -o -name '*.pyd' \) -delete 2>/dev/null || true
rm -rf .pytest_cache .mypy_cache .ruff_cache build dist htmlcov .coverage runtime
rm -rf wordgen.egg-info

# Keep these deliberately: they are the project's source knowledge.
#   british-words.txt
#   how-sentences-are-formed
#   plan.txt

echo "Clean complete. Source and knowledge files were preserved."
