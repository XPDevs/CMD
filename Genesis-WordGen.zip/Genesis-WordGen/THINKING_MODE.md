# Genesis-SPT-7.0: inspectable reasoning mode

Genesis is a conventional Python rule-based language engine, not a neural language model. Its new **decision trace** displays observable operations performed by the program: parse status, detected intent, extracted propositions, retrieved knowledge records, dialogue facts considered, selected response path, validation result, and loaded knowledge-resource counts.

## Use it

Interactive mode:

- Run `./chat.sh`
- Enter `/think on` to display the reasoning trace first, followed by the final answer.
- Enter `/think off` to hide the trace.

Single query:

- Run `python main.py --show-reasoning "What is a knowledge graph?"` to print the trace first and the final answer afterwards.
- Run `python main.py --json "What is a knowledge graph?"` to include the trace in machine-readable JSON.

## What the trace is—and is not

When enabled, the trace is printed before the final answer. It is intended to be auditable and evidence-oriented. It shows what rules and data sources the program reports using, which facts were retrieved, and whether the answer had support in the loaded knowledge. It is not a dump of private free-form chain-of-thought, and it should not be interpreted as proof that the engine fully understands a sentence. Confidence values are heuristic component scores, not calibrated probabilities.

## Current limits

- The parser and semantic interpreter cover a limited subset of English.
- The knowledge corpus is curated and finite; an absent concept cannot be reliably defined.
- The symbolic reasoner implements only a limited set of inference procedures.
- Passing tests verifies the tested behaviours, not unrestricted conversation.
- A response can still be shallow or awkward even when it is grammatically valid.

The trace is deliberately separate from the response itself so that debugging details do not contaminate ordinary conversation.
