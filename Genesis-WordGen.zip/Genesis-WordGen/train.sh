#!/usr/bin/env bash
# Build, validate and check the British English language engine.
# Sources of linguistic knowledge:
#   - british-words.txt          (the word inventory)
#   - how-sentences-are-formed   (the grammatical specification)
#   - genesis-knowledge.jsonl    (loaded concept and identity knowledge)
#   - genesis-dialogue.jsonl     (data-driven response wording)
#   - genesis-dialogue-lexicon.jsonl (editable dialogue relation vocabulary)
# No generated dictionary or grammar file is required.
set -euo pipefail

cd "$(dirname "$0")"

PYTHON="${PYTHON:-python3}"

if ! command -v "$PYTHON" >/dev/null 2>&1; then
    echo "error: $PYTHON was not found" >&2
    exit 1
fi

echo "== British English language engine: build/check =="
echo "Python: $($PYTHON --version 2>&1)"

for required in british-words.txt how-sentences-are-formed genesis-knowledge.jsonl genesis-dialogue.jsonl genesis-dialogue-lexicon.jsonl wordgen main.py; do
    if [ ! -e "$required" ]; then
        echo "error: required file missing: $required" >&2
        exit 1
    fi
done

echo "[1/4] Compiling Python modules"
"$PYTHON" -m compileall -q wordgen tests main.py

echo "[2/4] Loading and validating lexical and grammatical knowledge"
"$PYTHON" -m wordgen.train

echo "[3/4] Running the test suite"
if [ -d tests ] && find tests -name 'test_*.py' -print -quit | grep -q .; then
    "$PYTHON" -m unittest discover -s tests -q
else
    echo "No tests found yet; skipping test suite."
fi

echo "[4/4] Running an engine smoke test"
"$PYTHON" -m wordgen.train --smoke

echo
echo "Build complete. Start an interactive session with ./chat.sh"
