# Genesis-SPT-7.0 — knowledge and dialogue expansion

## Identity

- Name: Genesis-SPT-7.0
- Developer: XPDevs
- Approach: rule-based Python language and dialogue engine; no neural language model or external AI API.

## Expanded data-driven resources

- Expanded `genesis-knowledge.jsonl` to 660 concept records, plus identity and capability records.
- Added `genesis-dialogue.jsonl` for response templates and conversational wording.
- Added `genesis-dialogue-lexicon.jsonl` for relation vocabulary and question cues.
- Updated startup validation and build reporting to include these files.

## Conversational and reasoning improvements

- Response wording is loaded from a data file instead of being scattered throughout the realiser.
- Added token-overlap concept retrieval to return related loaded concepts where appropriate.
- Expanded the curated concept inventory from 289 to 660 records across computing, AI, programming, language, mathematics, logic, physics, chemistry, biology, astronomy, geography, health, society, economics and environment.
- Added comparison questions based on loaded concept definitions.
- Added user-centred relation extraction for likes/dislikes, wants, purchases, ownership, use, study, work and location.
- Added follow-up retrieval for preferences and location, plus a summary of explicitly extracted session facts.
- Kept measurement recall grounded in the original utterance.
- Added tests for expanded concepts, comparison, data-driven response policies and general relation recall.

## Important distinction

The Python code still contains the general algorithms and grammatical rules needed to interpret input. Those are not individual memorised answers. Facts, definitions, identity, response wording and relation vocabularies are externalised into editable files. The project avoids a table of hardcoded prompt/response pairs, but it is not literally possible to make an executable language engine contain no rules or code.

## Limits

The 101,668-form word inventory is not a 101,668-definition dictionary. The concept records are curated starter knowledge, not a complete reference corpus. The program remains a symbolic system with limited coverage, and session memory is not persisted after exit.

## Inspectable reasoning mode

- Added `wordgen/trace.py` to produce a structured, auditable decision trace from actual engine component outputs.
- Trace stages include parsing, intent, semantic representation, knowledge retrieval, inference notes, dialogue memory, response selection, output validation and loaded resource counts.
- Added evidence metadata for loaded concept records and an explicit taxonomy inference path, for example `dog -> mammal -> animal -> living thing`.
- Unknown concepts are marked as unsupported rather than being reported as grounded knowledge.
- Interactive CLI supports `/think on` and `/think off`; single-turn CLI supports `--show-reasoning`; JSON output includes `reasoning_trace`.
- See `THINKING_MODE.md` for usage and limitations.
- Automated test suite now contains 50 tests.

The displayed trace is an explanation of observable rules, evidence and decisions. It is not private free-form chain-of-thought, and heuristic confidence values are not calibrated probabilities.

- Updated thinking-mode output order: when enabled, Genesis prints its observable reasoning/evidence trace first and then prints the final answer under a separate heading. Added a regression test for this order.

## Small neural conversation prototype

Added `neural/`, a separate character-level GRU trained from scratch with PyTorch. It includes an external identity profile naming Genesis-SPT-7.0 and XPDevs, a DailyDialog download/conversion script, exact duplicate-dialogue filtering, automatic Linux available-RAM detection and conservative batch selection, CPU-only training, checkpoint saving, sampling-based chat, setup notes and dataset licensing notes. It is intentionally separate from the symbolic engine so neither path is misrepresented as the other. See `neural/README.md`.
